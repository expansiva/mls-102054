var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CURRENCY INPUT — BRUTALISM (mls-102054) — Strategy D shell
// =============================================================================
// Herda tudo de GroupEnterMoneyMlCurrencyInputMolecule (mls-102040): render(),
// parsing BigInt, clamp min/max, formatação Intl. Toda a aparência vive no
// .less homônimo, escopado na tag -brutal.
import { customElement } from 'lit/decorators.js';
import { GroupEnterMoneyMlCurrencyInputMolecule } from '/_102040_/l2/molecules/groupentermoney/ml-currency-input.js';
let CurrencyInputBrutal = class CurrencyInputBrutal extends GroupEnterMoneyMlCurrencyInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentermoney--ml-currency-input-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family, monospace);
}
groupentermoney--ml-currency-input-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentermoney--ml-currency-input-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupentermoney--ml-currency-input-brutal .ml-helper {
  color: #666;
  font-family: var(--ml-font-family, monospace);
}
groupentermoney--ml-currency-input-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupentermoney--ml-currency-input-brutal .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
  transition: none;
}
groupentermoney--ml-currency-input-brutal .ml-input-container:focus-within {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupentermoney--ml-currency-input-brutal .ml-input-container:has(input[readonly]) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupentermoney--ml-currency-input-brutal .ml-input-container-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupentermoney--ml-currency-input-brutal .ml-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
}
groupentermoney--ml-currency-input-brutal .ml-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
}
groupentermoney--ml-currency-input-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupentermoney--ml-currency-input-brutal .ml-input-container.ml-disabled {
  border-color: #999999;
  box-shadow: 2px 2px 0 #999999;
}
groupentermoney--ml-currency-input-brutal .ml-loading-overlay {
  background: rgba(255, 255, 255, 0.8);
}
groupentermoney--ml-currency-input-brutal .ml-loading-overlay .ml-text-muted {
  color: #000000;
  font-family: var(--ml-font-family, monospace);
  font-weight: 700;
  text-transform: var(--ml-text-transform, uppercase);
}
`);
    }
};
CurrencyInputBrutal = __decorate([
    customElement('groupentermoney--ml-currency-input-brutal')
], CurrencyInputBrutal);
export { CurrencyInputBrutal };
