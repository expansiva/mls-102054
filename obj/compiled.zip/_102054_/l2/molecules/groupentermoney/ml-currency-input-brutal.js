var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CURRENCY INPUT — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterMoney
// Herda GroupEnterMoneyMlCurrencyInputMolecule (mls-102040): parsing BigInt,
// clamp min/max, formatação Intl, estado (rawValue). Sobrescreve só render().
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { GroupEnterMoneyMlCurrencyInputMolecule } from '/_102040_/l2/molecules/groupentermoney/ml-currency-input.js';
/// **collab_i18n_start**
const message_en = { loading: 'Loading...', placeholder: 'Enter amount', noValue: '—' };
const messages = {
    en: message_en,
    pt: { loading: 'Carregando...', placeholder: 'Digite o valor', noValue: '—' },
};
let CurrencyInputBrutal = class CurrencyInputBrutal extends GroupEnterMoneyMlCurrencyInputMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentermoney--ml-currency-input-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-view {
  color: #000;
  font-weight: 700;
}
groupentermoney--ml-currency-input-brutal .brutal-helper {
  color: #666;
}
groupentermoney--ml-currency-input-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-input {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  outline: none;
  box-shadow: 3px 3px 0 #000;
  transition: none;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-input::placeholder {
  color: #999;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-input:focus {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-input.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-input.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  border-color: #999;
  box-shadow: 2px 2px 0 #999;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-input.is-readonly {
  background: #f5f5f5;
}
groupentermoney--ml-currency-input-brutal .is-loading {
  opacity: 0.4;
  pointer-events: none;
}
groupentermoney--ml-currency-input-brutal .brutal-cur-loading {
  background: rgba(255, 255, 255, 0.8);
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
}
`);
        this.gMsg = messages.en;
        this.gUid = `cur-brutal-${Math.random().toString(36).slice(2, 9)}`;
    }
    get x() {
        return this;
    }
    brutalInputClasses() {
        return [
            'brutal-cur-input w-full px-3 py-2 text-sm',
            this.error ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalContainerClasses() {
        return ['relative', this.loading ? 'is-loading' : ''].filter(Boolean).join(' ');
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return nothing;
        return html `<label id="${this.gUid}-label" class="brutal-cur-label block mb-1 text-sm">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </label>`;
    }
    brutalHelperOrError() {
        const describedId = `${this.gUid}-desc`;
        if (this.error) {
            return html `<p id="${describedId}" class="brutal-error-text mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${describedId}" class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return nothing;
    }
    brutalInput() {
        const describedId = this.error || this.hasSlot('Helper') ? `${this.gUid}-desc` : undefined;
        const placeholder = this.placeholder || this.getSlotAttr('Label', 'placeholder') || this.gMsg.placeholder;
        return html `
      <input
        id="${this.gUid}-input"
        name="${this.name}"
        class="${this.brutalInputClasses()}"
        .value=${this.x.rawValue}
        ?disabled=${this.disabled || this.loading}
        ?readonly=${this.readonly}
        placeholder="${placeholder}"
        maxlength="20"
        aria-labelledby="${this.hasSlot('Label') ? `${this.gUid}-label` : undefined}"
        aria-describedby="${describedId}"
        aria-invalid="${this.error ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        @focus="${(e) => this.x.onFocus(e)}"
        @input="${(e) => this.x.onInput(e)}"
        @blur="${() => this.x.onBlur()}"
      />
    `;
    }
    brutalViewMode() {
        const display = this.value === null ? this.gMsg.noValue : this.x.formatNumber(this.value);
        return html `<span class="brutal-cur-view block w-full text-sm">${unsafeHTML(display)}</span>`;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (this.x.rawValue === '' && this.value !== null) {
            this.x.rawValue = this.x.formatToRaw(this.value);
        }
        return html `
      <div class="${this.brutalContainerClasses()}">
        ${this.brutalLabel()}
        ${this.isEditing ? this.brutalInput() : this.brutalViewMode()}
        ${this.brutalHelperOrError()}
        ${this.loading
            ? html `<div class="brutal-cur-loading absolute inset-0 flex items-center justify-center"><span class="text-sm">${this.gMsg.loading}</span></div>`
            : nothing}
      </div>
    `;
    }
};
CurrencyInputBrutal = __decorate([
    customElement('groupentermoney--ml-currency-input-brutal')
], CurrencyInputBrutal);
export { CurrencyInputBrutal };
