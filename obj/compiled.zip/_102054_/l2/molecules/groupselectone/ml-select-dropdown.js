/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-select-dropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SELECT DROPDOWN MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Mesma molécula/contrato do mls-102040. Lógica intacta (parsing, busca, teclado,
// outside-click, eventos). Aparência (vidro) no .less escopado sob a tag.
// Padrão de POPOVER glass: o dropdown é translúcido com backdrop-filter sobre o
// conteúdo da página. Layout/posicionamento (absolute/z/flex) fica no Tailwind.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noSelection: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        noSelection: '—',
    },
};
let MlSelectDropdownMolecule = class MlSelectDropdownMolecule extends MoleculeAuraElement {
    // ===========================================================================
    // CONSTRUCTOR
    // ===========================================================================
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-select-dropdown {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupselectone--ml-select-dropdown .glass-label {
  font-weight: 600;
  color: rgba(255, 255, 255, 0.92);
}
groupselectone--ml-select-dropdown .glass-required {
  color: #ffb4ab;
}
groupselectone--ml-select-dropdown .glass-placeholder {
  color: rgba(255, 255, 255, 0.55);
}
groupselectone--ml-select-dropdown .glass-chevron {
  color: rgba(255, 255, 255, 0.7);
}
groupselectone--ml-select-dropdown .glass-trigger {
  position: relative;
  color: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  cursor: pointer;
  transition: border-color 250ms ease, box-shadow 250ms ease, background 250ms ease;
}
groupselectone--ml-select-dropdown .glass-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.45);
  pointer-events: none;
}
groupselectone--ml-select-dropdown .glass-trigger.is-open {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.3), 0 4px 16px rgba(0, 0, 0, 0.16);
}
groupselectone--ml-select-dropdown .glass-trigger.is-error {
  border-color: rgba(255, 120, 120, 0.85);
}
groupselectone--ml-select-dropdown .glass-trigger.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupselectone--ml-select-dropdown .glass-trigger.is-readonly {
  cursor: default;
}
groupselectone--ml-select-dropdown .glass-trigger:not(.is-disabled):not(.is-readonly):not(.is-open):hover {
  background: rgba(255, 255, 255, 0.16);
}
groupselectone--ml-select-dropdown .glass-dropdown {
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 14px;
  background: rgba(30, 27, 75, 0.55);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.35);
}
groupselectone--ml-select-dropdown .glass-dropdown-highlight {
  display: none;
}
groupselectone--ml-select-dropdown .glass-search-wrap {
  background: rgba(30, 27, 75, 0.65);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
}
groupselectone--ml-select-dropdown .glass-search {
  background: transparent;
  color: rgba(255, 255, 255, 0.95);
  border: none;
  border-bottom: 1px solid rgba(255, 255, 255, 0.18);
  outline: none;
}
groupselectone--ml-select-dropdown .glass-search::placeholder {
  color: rgba(255, 255, 255, 0.5);
}
groupselectone--ml-select-dropdown .glass-item {
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease;
  background: transparent;
  border: none;
}
groupselectone--ml-select-dropdown .glass-item:not(.is-disabled):not(.is-selected):hover,
groupselectone--ml-select-dropdown .glass-item.is-focused {
  background: rgba(255, 255, 255, 0.12);
}
groupselectone--ml-select-dropdown .glass-item.is-selected {
  background: rgba(99, 102, 241, 0.45);
  color: #fff;
}
groupselectone--ml-select-dropdown .glass-item.is-disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
groupselectone--ml-select-dropdown .glass-group-label {
  color: rgba(255, 255, 255, 0.55);
}
groupselectone--ml-select-dropdown .glass-empty {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-select-dropdown .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupselectone--ml-select-dropdown .glass-error-text {
  color: #ffb4ab;
}
groupselectone--ml-select-dropdown .glass-view-label {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-select-dropdown .glass-view-value {
  color: rgba(255, 255, 255, 0.95);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.placeholder = '';
        this.searchable = false;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.boundHandleOutsideClick = this.handleOutsideClick.bind(this);
        this.boundHandleKeydown = this.handleKeydown.bind(this);
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.boundHandleOutsideClick);
        document.addEventListener('keydown', this.boundHandleKeydown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.boundHandleOutsideClick);
        document.removeEventListener('keydown', this.boundHandleKeydown);
    }
    // ===========================================================================
    // PARSING HELPERS
    // ===========================================================================
    parseItems() {
        const items = [];
        const itemElements = this.getSlots('Item');
        for (const el of itemElements) {
            const value = el.getAttribute('value');
            if (value !== null) {
                items.push({
                    value,
                    label: el.innerHTML.trim(),
                    disabled: el.hasAttribute('disabled'),
                });
            }
        }
        return items;
    }
    parseGroups() {
        const groups = [];
        const groupElements = this.getSlots('Group');
        for (const groupEl of groupElements) {
            const groupLabel = groupEl.getAttribute('label') || '';
            const groupItems = [];
            const itemElements = groupEl.querySelectorAll('Item');
            for (const el of Array.from(itemElements)) {
                const value = el.getAttribute('value');
                if (value !== null) {
                    groupItems.push({
                        value,
                        label: el.innerHTML.trim(),
                        disabled: el.hasAttribute('disabled'),
                        group: groupLabel,
                    });
                }
            }
            if (groupItems.length > 0) {
                groups.push({
                    label: groupLabel,
                    items: groupItems,
                });
            }
        }
        return groups;
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap((g) => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find((item) => item.value === value);
    }
    getFilteredItems() {
        const allItems = this.getAllItems();
        if (!this.searchable || !this.searchQuery.trim()) {
            return allItems;
        }
        const query = this.searchQuery.toLowerCase().trim();
        return allItems.filter((item) => item.label.toLowerCase().includes(query));
    }
    getSelectableItems() {
        return this.getFilteredItems().filter((item) => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.searchQuery = '';
            this.focusedIndex = -1;
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
    }
    handleSelect(item) {
        if (this.disabled || this.readonly || item.disabled)
            return;
        this.value = item.value;
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    handleOutsideClick(e) {
        if (!this.isOpen)
            return;
        const path = e.composedPath();
        if (!path.includes(this)) {
            this.isOpen = false;
            this.searchQuery = '';
            this.focusedIndex = -1;
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        }
    }
    handleKeydown(e) {
        if (!this.isOpen)
            return;
        const selectableItems = this.getSelectableItems();
        switch (e.key) {
            case 'Escape':
                e.preventDefault();
                this.isOpen = false;
                this.searchQuery = '';
                this.focusedIndex = -1;
                break;
            case 'ArrowDown':
                e.preventDefault();
                if (selectableItems.length > 0) {
                    this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                }
                break;
            case 'ArrowUp':
                e.preventDefault();
                if (selectableItems.length > 0) {
                    this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                }
                break;
            case 'Enter':
                e.preventDefault();
                if (this.focusedIndex >= 0 && this.focusedIndex < selectableItems.length) {
                    this.handleSelect(selectableItems[this.focusedIndex]);
                }
                break;
        }
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.focusedIndex = -1;
    }
    // ===========================================================================
    // CSS HELPERS  (aparência = classes glass no .less; layout = Tailwind)
    // ===========================================================================
    getTriggerClasses() {
        return [
            'glass-trigger',
            'w-full flex items-center justify-between gap-2 px-3 py-2 text-sm',
            this.error !== '' ? 'is-error' : '',
            this.isOpen ? 'is-open' : '',
            this.disabled ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getDropdownClasses() {
        return 'glass-dropdown absolute z-50 w-full mt-1 max-h-60 overflow-auto';
    }
    getItemClasses(item, isSelected, isFocused) {
        return [
            'glass-item',
            'w-full px-3 py-2 text-sm text-left',
            isSelected ? 'is-selected' : '',
            isFocused ? 'is-focused' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSearchInputClasses() {
        return 'glass-search w-full px-3 py-2 text-sm';
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'select'}`;
        return html `
      <label id="${labelId}" class="glass-label block text-sm mb-1">
        ${unsafeHTML(labelContent)} ${this.required ? html `<span class="glass-required ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderTriggerContent() {
        const selectedItem = this.findItem(this.value);
        if (this.loading) {
            return html `
        <span class="glass-placeholder flex items-center gap-2">
          <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path
              class="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          ${this.msg.loading}
        </span>
      `;
        }
        if (selectedItem) {
            return html `<span class="truncate">${unsafeHTML(selectedItem.label)}</span>`;
        }
        if (this.hasSlot('Trigger')) {
            return html `<span class="glass-placeholder truncate">${unsafeHTML(this.getSlotContent('Trigger'))}</span>`;
        }
        const placeholderText = this.placeholder || this.msg.placeholder;
        return html `<span class="glass-placeholder truncate">${placeholderText}</span>`;
    }
    renderChevron() {
        const rotateClass = this.isOpen ? 'rotate-180' : '';
        return html `
      <svg class="glass-chevron w-4 h-4 transition-transform ${rotateClass} flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
        <path
          fill-rule="evenodd"
          d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
          clip-rule="evenodd"
        />
      </svg>
    `;
    }
    renderTrigger() {
        const hasError = this.error !== '';
        const labelId = this.hasSlot('Label') ? `label-${this.name || 'select'}` : undefined;
        const errorId = hasError ? `error-${this.name || 'select'}` : undefined;
        return html `
      <button
        type="button"
        role="combobox"
        aria-expanded="${this.isOpen}"
        aria-haspopup="listbox"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        aria-labelledby="${labelId || ''}"
        aria-describedby="${errorId || ''}"
        class="${this.getTriggerClasses()}"
        ?disabled="${this.disabled}"
        @click="${this.handleTriggerClick}"
      >
        ${this.renderTriggerContent()} ${this.renderChevron()}
      </button>
    `;
    }
    renderSearchInput() {
        if (!this.searchable)
            return html ``;
        return html `
      <div class="glass-search-wrap sticky top-0">
        <input
          type="text"
          class="${this.getSearchInputClasses()}"
          placeholder="${this.msg.searchPlaceholder}"
          .value="${this.searchQuery}"
          @input="${this.handleSearchInput}"
          @click="${(e) => e.stopPropagation()}"
        />
      </div>
    `;
    }
    renderItems() {
        const filteredItems = this.getFilteredItems();
        const selectableItems = this.getSelectableItems();
        if (filteredItems.length === 0) {
            return this.renderEmpty();
        }
        const groups = this.parseGroups();
        const standaloneItems = this.parseItems();
        const filteredStandalone = standaloneItems.filter((item) => {
            if (!this.searchable || !this.searchQuery.trim())
                return true;
            return item.label.toLowerCase().includes(this.searchQuery.toLowerCase().trim());
        });
        const filteredGroups = groups
            .map((group) => ({
            ...group,
            items: group.items.filter((item) => {
                if (!this.searchable || !this.searchQuery.trim())
                    return true;
                return item.label.toLowerCase().includes(this.searchQuery.toLowerCase().trim());
            }),
        }))
            .filter((group) => group.items.length > 0);
        return html `
      <div role="listbox" class="py-1">
        ${filteredStandalone.map((item) => {
            const isSelected = item.value === this.value;
            const selectableIndex = selectableItems.findIndex((si) => si.value === item.value);
            const isFocused = selectableIndex === this.focusedIndex;
            return html `
            <button
              type="button"
              role="option"
              aria-selected="${isSelected}"
              aria-disabled="${item.disabled}"
              class="${this.getItemClasses(item, isSelected, isFocused)}"
              @click="${() => this.handleSelect(item)}"
            >
              ${unsafeHTML(item.label)}
            </button>
          `;
        })}
        ${filteredGroups.map((group) => html `
            <div class="pt-2 first:pt-0">
              <div class="glass-group-label px-3 py-1 text-xs font-semibold uppercase tracking-wider">${group.label}</div>
              ${group.items.map((item) => {
            const isSelected = item.value === this.value;
            const selectableIndex = selectableItems.findIndex((si) => si.value === item.value);
            const isFocused = selectableIndex === this.focusedIndex;
            return html `
                  <button
                    type="button"
                    role="option"
                    aria-selected="${isSelected}"
                    aria-disabled="${item.disabled}"
                    class="${this.getItemClasses(item, isSelected, isFocused)}"
                    @click="${() => this.handleSelect(item)}"
                  >
                    ${unsafeHTML(item.label)}
                  </button>
                `;
        })}
            </div>
          `)}
      </div>
    `;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noResults;
        return html `<div class="glass-empty px-3 py-4 text-sm text-center">${unsafeHTML(emptyContent)}</div>`;
    }
    renderDropdown() {
        if (!this.isOpen || this.loading)
            return html ``;
        return html `
      <div class="${this.getDropdownClasses()}">
        <span class="glass-dropdown-highlight" aria-hidden="true"></span>
        ${this.renderSearchInput()} ${this.renderItems()}
      </div>
    `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<p class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
    }
    renderError() {
        if (this.error === '')
            return html ``;
        const errorId = `error-${this.name || 'select'}`;
        return html `<p id="${errorId}" class="glass-error-text mt-1 text-xs">${this.error}</p>`;
    }
    renderFeedback() {
        if (this.error !== '') {
            return this.renderError();
        }
        return this.renderHelper();
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayValue = selectedItem ? selectedItem.label : this.msg.noSelection;
        return html `
      <div class="text-sm">
        ${this.hasSlot('Label')
            ? html `
              <span class="glass-view-label">${unsafeHTML(this.getSlotContent('Label'))}:</span>
              <span class="glass-view-value ml-1">${unsafeHTML(displayValue)}</span>
            `
            : html `<span class="glass-view-value">${unsafeHTML(displayValue)}</span>`}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div class="relative w-full">
        ${this.renderLabel()} ${this.renderTrigger()} ${this.renderDropdown()} ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlSelectDropdownMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "focusedIndex", void 0);
MlSelectDropdownMolecule = __decorate([
    customElement('groupselectone--ml-select-dropdown')
], MlSelectDropdownMolecule);
export { MlSelectDropdownMolecule };
