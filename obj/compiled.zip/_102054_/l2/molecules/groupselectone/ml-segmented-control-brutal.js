var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED CONTROL — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de SegmentedControlMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { SegmentedControlMolecule } from '/_102040_/l2/molecules/groupselectone/ml-segmented-control.js';
let SegmentedControlBrutal = class SegmentedControlBrutal extends SegmentedControlMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-segmented-control-brutal {
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupselectone--ml-segmented-control-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  margin-bottom: 0.375rem;
}
groupselectone--ml-segmented-control-brutal .ml-helper {
  color: #555555;
}
groupselectone--ml-segmented-control-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-segmented-control-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupselectone--ml-segmented-control-brutal .ml-text-muted {
  color: #666666;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: uppercase;
}
groupselectone--ml-segmented-control-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-track {
  border-radius: 0;
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  box-shadow: 3px 3px 0 #000000;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-track-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-track.ml-disabled:not(.cursor-wait) {
  border-color: #999999;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-option {
  flex: 1 1 0;
  border-radius: 0;
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  outline: none;
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-option:hover:not(.ml-segmented-option-active):not(.ml-disabled) {
  background: var(--ml-surface-dim, #f5f5f5);
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 #000000;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-option:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-segmented-control-brutal .ml-segmented-option-active {
  background: #000000;
  color: #ffffff;
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupselectone--ml-segmented-control-brutal .ml-segmented-option.ml-disabled {
  border-color: #999999;
}
`);
    }
};
SegmentedControlBrutal = __decorate([
    customElement('groupselectone--ml-segmented-control-brutal')
], SegmentedControlBrutal);
export { SegmentedControlBrutal };
