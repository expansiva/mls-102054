var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED CONTROL — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Herda SegmentedControlMolecule (mls-102040): parsing, teclado, eventos e estado
// reativo (focusedIndex/parsedItems). Sobrescreve so render() com markup/classes
// brutal (track + segmentos com bordas grossas e sombras offset).
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { SegmentedControlMolecule } from '/_102040_/l2/molecules/groupselectone/ml-segmented-control.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opcao',
        noOptions: 'Nenhuma opcao disponivel',
        loading: 'Carregando...',
    },
};
let SegmentedControlBrutal = class SegmentedControlBrutal extends SegmentedControlMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-segmented-control-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 0.375rem;
}
groupselectone--ml-segmented-control-brutal .brutal-required {
  color: #ef4444;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-track {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  box-shadow: 3px 3px 0 #000;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-track.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-track.is-disabled {
  opacity: 0.4;
  border-color: #999;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-track.is-loading {
  opacity: 0.4;
}
groupselectone--ml-segmented-control-brutal .brutal-seg {
  flex: 1 1 0;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  outline: none;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  box-shadow: 2px 2px 0 #000;
}
groupselectone--ml-segmented-control-brutal .brutal-seg.is-selected {
  background: #000;
  color: #fff;
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupselectone--ml-segmented-control-brutal .brutal-seg:not(.is-selected):not(.is-disabled):hover {
  background: #f5f5f5;
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 #000;
}
groupselectone--ml-segmented-control-brutal .brutal-seg:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectone--ml-segmented-control-brutal .brutal-seg.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupselectone--ml-segmented-control-brutal .brutal-seg.is-readonly {
  cursor: default;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-loading,
groupselectone--ml-segmented-control-brutal .brutal-seg-empty {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupselectone--ml-segmented-control-brutal .brutal-helper {
  color: #555;
}
groupselectone--ml-segmented-control-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupselectone--ml-segmented-control-brutal .brutal-seg-view-value {
  color: #000;
}
`);
        this.bMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalContainerClasses() {
        return [
            'brutal-seg-track',
            'flex w-full p-1 gap-1',
            this.error ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
            this.loading ? 'is-loading' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalSegmentClasses(item, isSelected) {
        return [
            'brutal-seg',
            'px-4 py-2 text-sm font-bold',
            isSelected ? 'is-selected' : '',
            item.disabled ? 'is-disabled' : '',
            this.readonly && !item.disabled ? 'is-readonly' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalLabelClasses() {
        return 'brutal-seg-label block text-xs';
    }
    brutalHelperClasses() {
        return 'brutal-helper mt-1.5 text-xs';
    }
    brutalErrorClasses() {
        return 'brutal-error-text mt-1.5 text-xs';
    }
    brutalViewModeClasses() {
        return 'brutal-seg-view-value text-sm';
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalViewMode() {
        const selectedItem = this.x.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : this.placeholder || this.getSlotContent('Trigger') || this.bMsg.placeholder;
        return html `<div class=${this.brutalViewModeClasses()}>${unsafeHTML(displayText)}</div>`;
    }
    brutalEditMode() {
        const labelId = `label-${this.name || Math.random().toString(36).substr(2, 9)}`;
        const errorId = `error-${this.name || Math.random().toString(36).substr(2, 9)}`;
        const hasError = !!this.error;
        return html `
      <div class="flex flex-col w-full">
        <div class="min-h-[1rem]">${this.brutalLabel(labelId)}</div>
        ${this.loading ? this.brutalLoading() : this.brutalSegments(labelId, errorId, hasError)}
        ${this.brutalFeedback(errorId, hasError)}
      </div>
    `;
    }
    brutalLabel(labelId) {
        if (!this.hasSlot('Label')) {
            return html ``;
        }
        return html `
      <label id=${labelId} class=${this.brutalLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="brutal-required ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    brutalLoading() {
        return html `
      <div class=${this.brutalContainerClasses()}>
        <div class="brutal-seg-loading px-4 py-2 text-sm">${this.bMsg.loading}</div>
      </div>
    `;
    }
    brutalSegments(labelId, errorId, hasError) {
        if (this.x.parsedItems.length === 0) {
            return this.brutalEmpty();
        }
        return html `
      <div
        role="listbox"
        aria-labelledby=${this.hasSlot('Label') ? labelId : ''}
        aria-required=${this.required}
        aria-invalid=${hasError}
        aria-describedby=${hasError ? errorId : ''}
        class=${this.brutalContainerClasses()}
        @focus=${() => this.x.handleFocus()}
        @blur=${() => this.x.handleBlur()}
      >
        ${this.x.parsedItems.map((item, index) => this.brutalSegment(item, index))}
      </div>
    `;
    }
    brutalSegment(item, index) {
        const isSelected = this.value === item.value;
        const tabIndex = this.disabled || this.loading || item.disabled ? -1 : isSelected || (this.value === null && index === 0) ? 0 : -1;
        return html `
      <button
        type="button"
        role="option"
        aria-selected=${isSelected}
        aria-disabled=${item.disabled}
        tabindex=${tabIndex}
        class=${this.brutalSegmentClasses(item, isSelected)}
        @click=${() => this.x.handleSelect(item)}
        @keydown=${(e) => this.x.handleKeyDown(e, index)}
        ?disabled=${this.disabled || this.loading}
      >
        ${unsafeHTML(item.label)}
      </button>
    `;
    }
    brutalEmpty() {
        const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.bMsg.noOptions;
        return html `<div class="brutal-seg-empty px-4 py-2 text-sm">${unsafeHTML(emptyContent)}</div>`;
    }
    brutalFeedback(errorId, hasError) {
        if (hasError) {
            return html `<p id=${errorId} class=${this.brutalErrorClasses()}>${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class=${this.brutalHelperClasses()}>${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        this.x.parseItems();
        if (!this.isEditing) {
            return this.brutalViewMode();
        }
        return this.brutalEditMode();
    }
};
SegmentedControlBrutal = __decorate([
    customElement('groupselectone--ml-segmented-control-brutal')
], SegmentedControlBrutal);
export { SegmentedControlBrutal };
