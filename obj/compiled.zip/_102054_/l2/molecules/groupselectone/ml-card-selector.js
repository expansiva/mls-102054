/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-card-selector.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CARD SELECTOR MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        noValue: '—',
    },
};
let MlCardSelectorMolecule = class MlCardSelectorMolecule extends MoleculeAuraElement {
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-card-selector {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupselectone--ml-card-selector .glass-cs-label {
  color: rgba(255, 255, 255, 0.85);
}
groupselectone--ml-card-selector .glass-cs-req {
  color: #ffb4ab;
}
groupselectone--ml-card-selector .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupselectone--ml-card-selector .glass-error-text {
  color: #ffb4ab;
}
groupselectone--ml-card-selector .glass-cs-chevron {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-card-selector .glass-cs-empty {
  color: rgba(255, 255, 255, 0.55);
}
groupselectone--ml-card-selector .glass-cs-group {
  color: rgba(255, 255, 255, 0.5);
}
groupselectone--ml-card-selector .glass-cs-check {
  color: #c7d2fe;
}
groupselectone--ml-card-selector .glass-cs-view {
  color: #fff;
}
groupselectone--ml-card-selector .glass-cs-view .glass-cs-view-label {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-card-selector .glass-cs-trigger {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  color: #fff;
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupselectone--ml-card-selector .glass-cs-trigger:hover:not(.is-disabled):not(.is-open):not(.is-error) {
  background: rgba(255, 255, 255, 0.12);
}
groupselectone--ml-card-selector .glass-cs-trigger.is-open {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
}
groupselectone--ml-card-selector .glass-cs-trigger.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupselectone--ml-card-selector .glass-cs-trigger.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupselectone--ml-card-selector .glass-cs-trigger.is-readonly {
  cursor: default;
}
groupselectone--ml-card-selector .glass-cs-value {
  color: #fff;
}
groupselectone--ml-card-selector .glass-cs-value.is-placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupselectone--ml-card-selector .glass-cs-panel {
  background: rgba(30, 27, 75, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 14px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
}
groupselectone--ml-card-selector .glass-cs-search-row {
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}
groupselectone--ml-card-selector .glass-cs-search {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  color: #fff;
  outline: none;
}
groupselectone--ml-card-selector .glass-cs-search::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupselectone--ml-card-selector .glass-cs-search:focus {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
}
groupselectone--ml-card-selector .glass-cs-card {
  background: rgba(255, 255, 255, 0.06);
  border: 2px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  color: #fff;
  cursor: pointer;
  transition: border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
}
groupselectone--ml-card-selector .glass-cs-card:hover:not(.is-disabled):not(.is-selected) {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.1);
}
groupselectone--ml-card-selector .glass-cs-card.is-selected {
  border-color: rgba(199, 210, 254, 0.9);
  background: rgba(199, 210, 254, 0.15);
}
groupselectone--ml-card-selector .glass-cs-card.is-focused {
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.4);
}
groupselectone--ml-card-selector .glass-cs-card.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.placeholder = '';
        this.searchable = false;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.boundHandleOutsideClick = this.handleOutsideClick.bind(this);
        this.boundHandleKeydown = this.handleKeydown.bind(this);
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.boundHandleOutsideClick);
        document.addEventListener('keydown', this.boundHandleKeydown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.boundHandleOutsideClick);
        document.removeEventListener('keydown', this.boundHandleKeydown);
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    parseItems() {
        const items = [];
        const itemElements = this.getSlots('Item');
        for (const el of itemElements) {
            const value = el.getAttribute('value') || '';
            const disabled = el.hasAttribute('disabled');
            const label = el.textContent?.trim() || value;
            const content = el.innerHTML;
            items.push({ value, label, disabled, content });
        }
        return items;
    }
    parseGroups() {
        const groups = [];
        const groupElements = this.getSlots('Group');
        for (const groupEl of groupElements) {
            const groupLabel = groupEl.getAttribute('label') || '';
            const groupItems = [];
            const itemElements = groupEl.querySelectorAll('Item');
            for (const el of Array.from(itemElements)) {
                const value = el.getAttribute('value') || '';
                const disabled = el.hasAttribute('disabled');
                const label = el.textContent?.trim() || value;
                const content = el.innerHTML;
                groupItems.push({ value, label, disabled, content, group: groupLabel });
            }
            if (groupItems.length > 0) {
                groups.push({ label: groupLabel, items: groupItems });
            }
        }
        return groups;
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap(g => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    getFilteredItems(items) {
        if (!this.searchable || !this.searchQuery.trim()) {
            return items;
        }
        const query = this.searchQuery.toLowerCase().trim();
        return items.filter(item => item.label.toLowerCase().includes(query) ||
            item.value.toLowerCase().includes(query));
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find(item => item.value === value);
    }
    getSelectableItems() {
        return this.getFilteredItems(this.getAllItems()).filter(item => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleOutsideClick(e) {
        if (!this.isOpen)
            return;
        const path = e.composedPath();
        if (!path.includes(this)) {
            this.closePanel();
        }
    }
    handleKeydown(e) {
        if (!this.isOpen)
            return;
        const selectableItems = this.getSelectableItems();
        if (selectableItems.length === 0)
            return;
        switch (e.key) {
            case 'Escape':
                e.preventDefault();
                this.closePanel();
                break;
            case 'ArrowDown':
                e.preventDefault();
                this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                break;
            case 'ArrowUp':
                e.preventDefault();
                this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                break;
            case 'ArrowLeft':
                e.preventDefault();
                this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                break;
            case 'Enter':
                e.preventDefault();
                if (this.focusedIndex >= 0 && this.focusedIndex < selectableItems.length) {
                    this.handleSelect(selectableItems[this.focusedIndex].value);
                }
                break;
        }
    }
    handleTriggerClick(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        if (this.isOpen) {
            this.closePanel();
        }
        else {
            this.openPanel();
        }
    }
    handleSelect(value) {
        if (this.disabled || this.readonly)
            return;
        this.value = value;
        this.closePanel();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.focusedIndex = 0;
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    openPanel() {
        this.isOpen = true;
        this.searchQuery = '';
        this.focusedIndex = 0;
        this.handleFocus();
    }
    closePanel() {
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.handleBlur();
    }
    // ===========================================================================
    // CSS CLASSES (glass)
    // ===========================================================================
    getTriggerClasses() {
        const hasError = this.error !== '';
        return [
            'glass-cs-trigger w-full min-h-[44px] px-4 py-3 text-sm',
            'flex items-center justify-between gap-2',
            hasError ? 'is-error' : '',
            this.isOpen ? 'is-open' : '',
            this.disabled ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return 'glass-cs-panel absolute z-50 mt-2 w-full max-h-[400px] overflow-auto';
    }
    getCardClasses(item, isSelected, isFocused) {
        return [
            'glass-cs-card p-4',
            isSelected ? 'is-selected' : '',
            isFocused && !isSelected ? 'is-focused' : '',
            item.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getSearchInputClasses() {
        return 'glass-cs-search w-full px-3 py-2 text-sm';
    }
    getGroupLabelClasses() {
        return 'glass-cs-group text-xs font-semibold uppercase tracking-wider mb-2';
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'card-selector'}`;
        return html `
      <label id="${labelId}" class="glass-cs-label block text-sm font-medium mb-1.5">
        ${unsafeHTML(labelContent)}
        ${this.required ? html `<span class="glass-cs-req ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderTrigger() {
        const selectedItem = this.findItem(this.value);
        const placeholderText = this.placeholder || this.getSlotContent('Trigger') || this.msg.placeholder;
        const hasError = this.error !== '';
        const labelId = `label-${this.name || 'card-selector'}`;
        const errorId = `error-${this.name || 'card-selector'}`;
        return html `
      <button
        type="button"
        role="combobox"
        aria-expanded="${this.isOpen}"
        aria-haspopup="listbox"
        aria-labelledby="${this.hasSlot('Label') ? labelId : ''}"
        aria-describedby="${hasError ? errorId : ''}"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        ?disabled="${this.disabled}"
        class="${this.getTriggerClasses()}"
        @click="${this.handleTriggerClick}"
      >
        <span class="glass-cs-value flex-1 text-left ${!selectedItem ? 'is-placeholder' : ''}">
          ${this.loading
            ? html `<span class="flex items-center gap-2">
                <svg class="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                ${this.msg.loading}
              </span>`
            : selectedItem
                ? selectedItem.label
                : unsafeHTML(placeholderText)}
        </span>
        <svg
          class="glass-cs-chevron w-5 h-5 transition-transform ${this.isOpen ? 'rotate-180' : ''}"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>
    `;
    }
    renderSearch() {
        if (!this.searchable)
            return html ``;
        return html `
      <div class="glass-cs-search-row p-3">
        <input
          type="text"
          class="${this.getSearchInputClasses()}"
          placeholder="${this.msg.searchPlaceholder}"
          .value="${this.searchQuery}"
          @input="${this.handleSearchInput}"
        />
      </div>
    `;
    }
    renderCard(item, index) {
        const isSelected = this.value === item.value;
        const selectableItems = this.getSelectableItems();
        const selectableIndex = selectableItems.findIndex(i => i.value === item.value);
        const isFocused = selectableIndex === this.focusedIndex;
        return html `
      <div
        role="option"
        aria-selected="${isSelected}"
        aria-disabled="${item.disabled}"
        class="${this.getCardClasses(item, isSelected, isFocused)}"
        @click="${() => !item.disabled && this.handleSelect(item.value)}"
      >
        <div class="flex items-start gap-3">
          <div class="flex-1">
            ${unsafeHTML(item.content)}
          </div>
          ${isSelected ? html `
            <div class="flex-shrink-0">
              <svg class="glass-cs-check w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
              </svg>
            </div>
          ` : html ``}
        </div>
      </div>
    `;
    }
    renderCardGrid() {
        const standaloneItems = this.getFilteredItems(this.parseItems());
        const groups = this.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some(g => this.getFilteredItems(g.items).length > 0);
        if (!hasItems) {
            return this.renderEmpty();
        }
        let itemIndex = 0;
        return html `
      <div class="p-4">
        ${groups.map(group => {
            const filteredGroupItems = this.getFilteredItems(group.items);
            if (filteredGroupItems.length === 0)
                return html ``;
            return html `
            <div class="mb-4 last:mb-0">
              <div class="${this.getGroupLabelClasses()}">${group.label}</div>
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                ${filteredGroupItems.map(item => {
                const card = this.renderCard(item, itemIndex);
                itemIndex++;
                return card;
            })}
              </div>
            </div>
          `;
        })}
        ${standaloneItems.length > 0 ? html `
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            ${standaloneItems.map(item => {
            const card = this.renderCard(item, itemIndex);
            itemIndex++;
            return card;
        })}
          </div>
        ` : html ``}
      </div>
    `;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.msg.noResults;
        return html `
      <div class="glass-cs-empty p-8 text-center">
        ${unsafeHTML(emptyContent)}
      </div>
    `;
    }
    renderPanel() {
        if (!this.isOpen || this.loading)
            return html ``;
        return html `
      <div role="listbox" class="${this.getPanelClasses()}">
        ${this.renderSearch()}
        ${this.renderCardGrid()}
      </div>
    `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        const helperContent = this.getSlotContent('Helper');
        return html `<p class="glass-helper mt-1.5 text-xs">${unsafeHTML(helperContent)}</p>`;
    }
    renderError() {
        if (!this.error)
            return html ``;
        const errorId = `error-${this.name || 'card-selector'}`;
        return html `<p id="${errorId}" class="glass-error-text mt-1.5 text-xs">${unsafeHTML(this.error)}</p>`;
    }
    renderFeedback() {
        if (this.error) {
            return this.renderError();
        }
        return this.renderHelper();
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayValue = selectedItem
            ? selectedItem.label
            : (this.placeholder || this.msg.noValue);
        return html `
      <div class="glass-cs-view text-sm">
        ${this.hasSlot('Label') ? html `
          <span class="glass-cs-view-label">
            ${unsafeHTML(this.getSlotContent('Label'))}:
          </span>
          <span class="ml-1">${displayValue}</span>
        ` : html `
          <span>${displayValue}</span>
        `}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div class="relative w-full">
        ${this.renderLabel()}
        ${this.renderTrigger()}
        ${this.renderPanel()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlCardSelectorMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlCardSelectorMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlCardSelectorMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlCardSelectorMolecule.prototype, "focusedIndex", void 0);
MlCardSelectorMolecule = __decorate([
    customElement('groupselectone--ml-card-selector')
], MlCardSelectorMolecule);
export { MlCardSelectorMolecule };
