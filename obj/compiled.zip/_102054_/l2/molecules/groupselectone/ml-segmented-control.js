/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-segmented-control.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED CONTROL MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência no .less.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noOptions: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
let SegmentedControlMolecule = class SegmentedControlMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-segmented-control {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupselectone--ml-segmented-control .glass-seg-label {
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 0.375rem;
}
groupselectone--ml-segmented-control .glass-required {
  color: #ffb4ab;
}
groupselectone--ml-segmented-control .glass-seg-track {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: inset 0 1px 1px rgba(255, 255, 255, 0.15);
}
groupselectone--ml-segmented-control .glass-seg-track.is-error {
  box-shadow: 0 0 0 2px rgba(255, 120, 120, 0.7);
}
groupselectone--ml-segmented-control .glass-seg-track.is-disabled {
  opacity: 0.5;
}
groupselectone--ml-segmented-control .glass-seg-track.is-loading {
  opacity: 0.6;
}
groupselectone--ml-segmented-control .glass-seg {
  flex: 1 1 0;
  border-radius: 9px;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: background 200ms ease, color 200ms ease, box-shadow 200ms ease;
  outline: none;
}
groupselectone--ml-segmented-control .glass-seg.is-selected {
  background: rgba(255, 255, 255, 0.22);
  color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.4);
}
groupselectone--ml-segmented-control .glass-seg:not(.is-selected):not(.is-disabled):hover {
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
}
groupselectone--ml-segmented-control .glass-seg:focus-visible {
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.7);
}
groupselectone--ml-segmented-control .glass-seg.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupselectone--ml-segmented-control .glass-seg.is-readonly {
  cursor: default;
}
groupselectone--ml-segmented-control .glass-seg-loading,
groupselectone--ml-segmented-control .glass-seg-empty {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-segmented-control .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupselectone--ml-segmented-control .glass-error-text {
  color: #ffb4ab;
}
groupselectone--ml-segmented-control .glass-seg-view-value {
  color: rgba(255, 255, 255, 0.95);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedIndex = -1;
        this.parsedItems = [];
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseItems();
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            this.requestUpdate();
        }
    }
    // ===========================================================================
    // ITEM PARSING
    // ===========================================================================
    parseItems() {
        const itemElements = this.getSlots('Item');
        this.parsedItems = itemElements.map((el) => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML.trim(),
            disabled: el.hasAttribute('disabled'),
        }));
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.parsedItems.find((item) => item.value === value);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    handleKeyDown(e, index) {
        if (this.disabled || this.loading)
            return;
        const enabledItems = this.parsedItems.filter((item) => !item.disabled);
        const currentEnabledIndex = enabledItems.findIndex((item) => item.value === this.parsedItems[index]?.value);
        switch (e.key) {
            case 'ArrowRight':
            case 'ArrowDown':
                e.preventDefault();
                this.focusNextItem(currentEnabledIndex, enabledItems);
                break;
            case 'ArrowLeft':
            case 'ArrowUp':
                e.preventDefault();
                this.focusPreviousItem(currentEnabledIndex, enabledItems);
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                if (!this.parsedItems[index]?.disabled) {
                    this.handleSelect(this.parsedItems[index]);
                }
                break;
        }
    }
    focusNextItem(currentIndex, enabledItems) {
        if (enabledItems.length === 0)
            return;
        const nextIndex = (currentIndex + 1) % enabledItems.length;
        const nextItem = enabledItems[nextIndex];
        const globalIndex = this.parsedItems.findIndex((item) => item.value === nextItem.value);
        this.focusedIndex = globalIndex;
        this.focusSegment(globalIndex);
    }
    focusPreviousItem(currentIndex, enabledItems) {
        if (enabledItems.length === 0)
            return;
        const prevIndex = currentIndex <= 0 ? enabledItems.length - 1 : currentIndex - 1;
        const prevItem = enabledItems[prevIndex];
        const globalIndex = this.parsedItems.findIndex((item) => item.value === prevItem.value);
        this.focusedIndex = globalIndex;
        this.focusSegment(globalIndex);
    }
    focusSegment(index) {
        const segments = this.querySelectorAll('[role="option"]');
        const segment = segments[index];
        if (segment) {
            segment.focus();
        }
    }
    handleFocus() {
        if (this.disabled || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.focusedIndex = -1;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // RENDER HELPERS  (aparência = classes glass; layout = Tailwind)
    // ===========================================================================
    getContainerClasses() {
        return [
            'glass-seg-track',
            'flex w-full p-1 gap-1',
            this.error ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
            this.loading ? 'is-loading' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSegmentClasses(item, isSelected) {
        return [
            'glass-seg',
            'px-4 py-2 text-sm font-medium',
            isSelected ? 'is-selected' : '',
            item.disabled ? 'is-disabled' : '',
            this.readonly && !item.disabled ? 'is-readonly' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getLabelClasses() {
        return 'glass-seg-label block text-xs';
    }
    getHelperClasses() {
        return 'glass-helper mt-1.5 text-xs';
    }
    getErrorClasses() {
        return 'glass-error-text mt-1.5 text-xs';
    }
    getViewModeClasses() {
        return 'glass-seg-view-value text-sm';
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.parseItems();
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : this.placeholder || this.getSlotContent('Trigger') || this.msg.placeholder;
        return html `<div class=${this.getViewModeClasses()}>${unsafeHTML(displayText)}</div>`;
    }
    renderEditMode() {
        const labelId = `label-${this.name || Math.random().toString(36).substr(2, 9)}`;
        const errorId = `error-${this.name || Math.random().toString(36).substr(2, 9)}`;
        const hasError = !!this.error;
        return html `
      <div class="flex flex-col w-full">
        <div class="min-h-[1rem]">${this.renderLabel(labelId)}</div>
        ${this.loading ? this.renderLoading() : this.renderSegments(labelId, errorId, hasError)}
        ${this.renderFeedback(errorId, hasError)}
      </div>
    `;
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label')) {
            return html ``;
        }
        return html `
      <label id=${labelId} class=${this.getLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="glass-required ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderLoading() {
        return html `
      <div class=${this.getContainerClasses()}>
        <div class="glass-seg-loading px-4 py-2 text-sm">${this.msg.loading}</div>
      </div>
    `;
    }
    renderSegments(labelId, errorId, hasError) {
        if (this.parsedItems.length === 0) {
            return this.renderEmpty();
        }
        return html `
      <div
        role="listbox"
        aria-labelledby=${this.hasSlot('Label') ? labelId : ''}
        aria-required=${this.required}
        aria-invalid=${hasError}
        aria-describedby=${hasError ? errorId : ''}
        class=${this.getContainerClasses()}
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
      >
        ${this.parsedItems.map((item, index) => this.renderSegment(item, index))}
      </div>
    `;
    }
    renderSegment(item, index) {
        const isSelected = this.value === item.value;
        const tabIndex = this.disabled || this.loading || item.disabled ? -1 : isSelected || (this.value === null && index === 0) ? 0 : -1;
        return html `
      <button
        type="button"
        role="option"
        aria-selected=${isSelected}
        aria-disabled=${item.disabled}
        tabindex=${tabIndex}
        class=${this.getSegmentClasses(item, isSelected)}
        @click=${() => this.handleSelect(item)}
        @keydown=${(e) => this.handleKeyDown(e, index)}
        ?disabled=${this.disabled || this.loading}
      >
        ${unsafeHTML(item.label)}
      </button>
    `;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noOptions;
        return html `<div class="glass-seg-empty px-4 py-2 text-sm">${unsafeHTML(emptyContent)}</div>`;
    }
    renderFeedback(errorId, hasError) {
        if (hasError) {
            return html `<p id=${errorId} class=${this.getErrorClasses()}>${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class=${this.getHelperClasses()}>${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], SegmentedControlMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "loading", void 0);
__decorate([
    state()
], SegmentedControlMolecule.prototype, "focusedIndex", void 0);
__decorate([
    state()
], SegmentedControlMolecule.prototype, "parsedItems", void 0);
SegmentedControlMolecule = __decorate([
    customElement('groupselectone--ml-segmented-control')
], SegmentedControlMolecule);
export { SegmentedControlMolecule };
