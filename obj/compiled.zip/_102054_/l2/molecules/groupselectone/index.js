var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
// Registra a(s) molécula(s) do grupo (side-effect import)
import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
import '/_102054_/l2/molecules/groupselectone/ml-radio-group';
import '/_102054_/l2/molecules/groupselectone/ml-segmented-control';
import '/_102054_/l2/molecules/groupselectone/ml-combobox';
import '/_102054_/l2/molecules/groupselectone/ml-card-selector';
let GroupSelectOneIndex = class GroupSelectOneIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        this.country = 'br';
        this.plan = 'pro';
        this.view = 'month';
        this.fruit = 'apple';
        this.tier = 'pro';
    }
    render() {
        return html `
      <div
        style="min-height:100vh; padding:2rem; background:linear-gradient(135deg,#0b1220 0%,#312e81 45%,#7e22ce 100%); font-family:'Inter',system-ui,sans-serif;"
      >
        <header style="text-align:center; margin-bottom:3rem;">
          <span
            style="display:inline-block; padding:0.25rem 0.75rem; background:rgba(255,255,255,0.15); color:#fff; border:1px solid rgba(255,255,255,0.25); border-radius:9999px; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:1rem;"
            >groupSelectOne · glassmorphism</span
          >
          <h1 style="font-size:2.25rem; font-weight:700; color:#fff; margin-bottom:0.5rem;">Select One</h1>
        </header>
        <section style="max-width:28rem; margin:0 auto; display:flex; flex-direction:column; gap:2rem;">
          <groupselectone--ml-select-dropdown
            name="country"
            searchable="true"
            .value=${this.country}
            .isEditing=${true}
            @change=${(e) => {
            this.country = e.detail.value;
        }}
          >
            <Label>País</Label>
            <Helper>Selecionado: ${this.country}</Helper>
            <Item value="br">Brasil</Item>
            <Item value="us">Estados Unidos</Item>
            <Item value="pt">Portugal</Item>
            <Item value="jp">Japão</Item>
          </groupselectone--ml-select-dropdown>

          <groupselectone--ml-radio-group
            name="plan"
            .value=${this.plan}
            .isEditing=${true}
            @change=${(e) => {
            this.plan = e.detail.value;
        }}
          >
            <Label>Plano</Label>
            <Item value="free">Gratuito</Item>
            <Item value="standard">Standard</Item>
            <Item value="pro">Pro</Item>
          </groupselectone--ml-radio-group>

          <groupselectone--ml-segmented-control
            name="view"
            .value=${this.view}
            .isEditing=${true}
            @change=${(e) => {
            this.view = e.detail.value;
        }}
          >
            <Label>Visualização</Label>
            <Item value="day">Dia</Item>
            <Item value="week">Semana</Item>
            <Item value="month">Mês</Item>
          </groupselectone--ml-segmented-control>

          <groupselectone--ml-combobox
            .value=${this.fruit}
            clearable
            @change=${(e) => {
            this.fruit = e.detail.value;
        }}
          >
            <Label>Fruta</Label>
            <Helper>Selecionado: ${this.fruit ?? '—'}</Helper>
            <Item value="apple">Maçã</Item>
            <Item value="banana">Banana</Item>
            <Item value="grape">Uva</Item>
            <Item value="orange">Laranja</Item>
          </groupselectone--ml-combobox>

          <groupselectone--ml-card-selector
            .value=${this.tier}
            searchable
            @change=${(e) => {
            this.tier = e.detail.value;
        }}
          >
            <Label>Tier</Label>
            <Helper>Selecionado: ${this.tier}</Helper>
            <Item value="free"><strong>Free</strong><br /><span style="opacity:.7">R$ 0/mês</span></Item>
            <Item value="pro"><strong>Pro</strong><br /><span style="opacity:.7">R$ 49/mês</span></Item>
            <Item value="business"><strong>Business</strong><br /><span style="opacity:.7">R$ 149/mês</span></Item>
          </groupselectone--ml-card-selector>
        </section>
      </div>
    `;
    }
};
__decorate([
    state()
], GroupSelectOneIndex.prototype, "country", void 0);
__decorate([
    state()
], GroupSelectOneIndex.prototype, "plan", void 0);
__decorate([
    state()
], GroupSelectOneIndex.prototype, "view", void 0);
__decorate([
    state()
], GroupSelectOneIndex.prototype, "fruit", void 0);
__decorate([
    state()
], GroupSelectOneIndex.prototype, "tier", void 0);
GroupSelectOneIndex = __decorate([
    customElement('molecules--groupselectone--index-102054')
], GroupSelectOneIndex);
export { GroupSelectOneIndex };
