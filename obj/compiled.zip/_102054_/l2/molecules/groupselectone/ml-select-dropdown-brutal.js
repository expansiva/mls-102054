var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-select-dropdown-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SELECT DROPDOWN — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Herda MlSelectDropdownMolecule (mls-102040): parsing, busca, teclado,
// outside-click, eventos e estado reativo (isOpen/searchQuery/focusedIndex).
// Sobrescreve so render() com markup/classes brutal.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlSelectDropdownMolecule } from '/_102040_/l2/molecules/groupselectone/ml-select-dropdown.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noSelection: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opcao',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        noSelection: '—',
    },
};
let MlSelectDropdownBrutal = class MlSelectDropdownBrutal extends MlSelectDropdownMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-select-dropdown-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-select-dropdown-brutal .brutal-label {
  font-weight: 700;
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-select-dropdown-brutal .brutal-required {
  color: #ef4444;
}
groupselectone--ml-select-dropdown-brutal .brutal-placeholder {
  color: #999;
}
groupselectone--ml-select-dropdown-brutal .brutal-chevron {
  color: #000;
}
groupselectone--ml-select-dropdown-brutal .brutal-loading-icon {
  display: inline-block;
  animation: brutal-sd-spin 1s steps(8) infinite;
}
@keyframes brutal-sd-spin {
  to {
    transform: rotate(360deg);
  }
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger {
  position: relative;
  color: #000;
  border: 3px solid #000;
  border-radius: 0;
  background: #fff;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger.is-open {
  box-shadow: 1px 1px 0 #000;
  transform: translate(2px, 2px);
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger.is-readonly {
  cursor: default;
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger:not(.is-disabled):not(.is-readonly):not(.is-open):hover {
  background: #f5f5f5;
}
groupselectone--ml-select-dropdown-brutal .brutal-trigger:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectone--ml-select-dropdown-brutal .brutal-helper {
  color: #555;
}
groupselectone--ml-select-dropdown-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupselectone--ml-select-dropdown-brutal .brutal-view-label {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-select-dropdown-brutal .brutal-view-value {
  color: #000;
}
groupselectone--ml-select-dropdown-brutal .brutal-dropdown,
.brutal-sd-portal .brutal-dropdown {
  border: 3px solid #000;
  border-radius: 0;
  background: #fff;
  box-shadow: 4px 4px 0 #000;
}
groupselectone--ml-select-dropdown-brutal .brutal-search-wrap,
.brutal-sd-portal .brutal-search-wrap {
  background: #fff;
  border-bottom: 3px solid #000;
}
groupselectone--ml-select-dropdown-brutal .brutal-search,
.brutal-sd-portal .brutal-search {
  background: #fff;
  color: #000;
  border: none;
  outline: none;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-select-dropdown-brutal .brutal-search::placeholder,
.brutal-sd-portal .brutal-search::placeholder {
  color: #999;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-select-dropdown-brutal .brutal-search:focus,
.brutal-sd-portal .brutal-search:focus {
  background: #f5f5f5;
}
groupselectone--ml-select-dropdown-brutal .brutal-item,
.brutal-sd-portal .brutal-item {
  color: #000;
  cursor: pointer;
  background: transparent;
  border: none;
  border-bottom: 1px solid #e5e5e5;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-select-dropdown-brutal .brutal-item:last-child,
.brutal-sd-portal .brutal-item:last-child {
  border-bottom: none;
}
groupselectone--ml-select-dropdown-brutal .brutal-item:not(.is-disabled):not(.is-selected):hover,
.brutal-sd-portal .brutal-item:not(.is-disabled):not(.is-selected):hover,
groupselectone--ml-select-dropdown-brutal .brutal-item.is-focused,
.brutal-sd-portal .brutal-item.is-focused {
  background: #f5f5f5;
}
groupselectone--ml-select-dropdown-brutal .brutal-item.is-selected,
.brutal-sd-portal .brutal-item.is-selected {
  background: #000;
  color: #fff;
  font-weight: 700;
}
groupselectone--ml-select-dropdown-brutal .brutal-item.is-disabled,
.brutal-sd-portal .brutal-item.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupselectone--ml-select-dropdown-brutal .brutal-group-label,
.brutal-sd-portal .brutal-group-label {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 2px solid #000;
}
groupselectone--ml-select-dropdown-brutal .brutal-empty,
.brutal-sd-portal .brutal-empty {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
`);
        this.portalClassName = 'brutal-sd-portal';
        this.bMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalTriggerClasses() {
        return [
            'brutal-trigger',
            'w-full flex items-center justify-between gap-2 px-3 py-2 text-sm',
            this.error !== '' ? 'is-error' : '',
            this.x.isOpen ? 'is-open' : '',
            this.disabled ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalDropdownClasses() {
        return 'brutal-dropdown w-full max-h-60 overflow-auto';
    }
    brutalItemClasses(item, isSelected, isFocused) {
        return [
            'brutal-item',
            'w-full px-3 py-2 text-sm text-left',
            isSelected ? 'is-selected' : '',
            isFocused ? 'is-focused' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalSearchClasses() {
        return 'brutal-search w-full px-3 py-2 text-sm';
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'select'}`;
        return html `
      <label id="${labelId}" class="brutal-label block text-sm mb-1">
        ${unsafeHTML(labelContent)} ${this.required ? html `<span class="brutal-required ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    brutalTriggerContent() {
        const selectedItem = this.x.findItem(this.value);
        if (this.loading) {
            return html `
        <span class="brutal-placeholder flex items-center gap-2">
          <span class="brutal-loading-icon">&#9881;</span>
          ${this.bMsg.loading}
        </span>
      `;
        }
        if (selectedItem) {
            return html `<span class="truncate">${unsafeHTML(selectedItem.label)}</span>`;
        }
        if (this.hasSlot('Trigger')) {
            return html `<span class="brutal-placeholder truncate">${unsafeHTML(this.getSlotContent('Trigger'))}</span>`;
        }
        const placeholderText = this.placeholder || this.bMsg.placeholder;
        return html `<span class="brutal-placeholder truncate">${placeholderText}</span>`;
    }
    brutalChevron() {
        const rotateClass = this.x.isOpen ? 'rotate-180' : '';
        return html `
      <svg class="brutal-chevron w-4 h-4 ${rotateClass} flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
        <path
          fill-rule="evenodd"
          d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
          clip-rule="evenodd"
        />
      </svg>
    `;
    }
    brutalTrigger() {
        const hasError = this.error !== '';
        const labelId = this.hasSlot('Label') ? `label-${this.name || 'select'}` : undefined;
        const errorId = hasError ? `error-${this.name || 'select'}` : undefined;
        return html `
      <button
        type="button"
        role="combobox"
        aria-expanded="${this.x.isOpen}"
        aria-haspopup="listbox"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        aria-labelledby="${labelId || ''}"
        aria-describedby="${errorId || ''}"
        class="${this.brutalTriggerClasses()}"
        ?disabled="${this.disabled}"
        @click="${(e) => this.x.handleTriggerClick(e)}"
      >
        ${this.brutalTriggerContent()} ${this.brutalChevron()}
      </button>
    `;
    }
    brutalSearchInput() {
        if (!this.searchable)
            return html ``;
        return html `
      <div class="brutal-search-wrap sticky top-0">
        <input
          type="text"
          class="${this.brutalSearchClasses()}"
          placeholder="${this.bMsg.searchPlaceholder}"
          .value="${this.x.searchQuery}"
          @input="${(e) => this.x.handleSearchInput(e)}"
          @click="${(e) => e.stopPropagation()}"
        />
      </div>
    `;
    }
    brutalItems() {
        const filteredItems = this.x.getFilteredItems();
        const selectableItems = this.x.getSelectableItems();
        if (filteredItems.length === 0) {
            return this.brutalEmpty();
        }
        const groups = this.x.parseGroups();
        const standaloneItems = this.x.parseItems();
        const filteredStandalone = standaloneItems.filter((item) => {
            if (!this.searchable || !this.x.searchQuery.trim())
                return true;
            return item.label.toLowerCase().includes(this.x.searchQuery.toLowerCase().trim());
        });
        const filteredGroups = groups
            .map((group) => ({
            ...group,
            items: group.items.filter((item) => {
                if (!this.searchable || !this.x.searchQuery.trim())
                    return true;
                return item.label.toLowerCase().includes(this.x.searchQuery.toLowerCase().trim());
            }),
        }))
            .filter((group) => group.items.length > 0);
        return html `
      <div role="listbox" class="py-1">
        ${filteredStandalone.map((item) => {
            const isSelected = item.value === this.value;
            const selectableIndex = selectableItems.findIndex((si) => si.value === item.value);
            const isFocused = selectableIndex === this.x.focusedIndex;
            return html `
            <button
              type="button"
              role="option"
              aria-selected="${isSelected}"
              aria-disabled="${item.disabled}"
              class="${this.brutalItemClasses(item, isSelected, isFocused)}"
              @click="${() => this.x.handleSelect(item)}"
            >
              ${unsafeHTML(item.label)}
            </button>
          `;
        })}
        ${filteredGroups.map((group) => html `
            <div class="pt-2 first:pt-0">
              <div class="brutal-group-label px-3 py-1 text-xs font-bold uppercase tracking-wider">${group.label}</div>
              ${group.items.map((item) => {
            const isSelected = item.value === this.value;
            const selectableIndex = selectableItems.findIndex((si) => si.value === item.value);
            const isFocused = selectableIndex === this.x.focusedIndex;
            return html `
                  <button
                    type="button"
                    role="option"
                    aria-selected="${isSelected}"
                    aria-disabled="${item.disabled}"
                    class="${this.brutalItemClasses(item, isSelected, isFocused)}"
                    @click="${() => this.x.handleSelect(item)}"
                  >
                    ${unsafeHTML(item.label)}
                  </button>
                `;
        })}
            </div>
          `)}
      </div>
    `;
    }
    brutalEmpty() {
        const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.bMsg.noResults;
        return html `<div class="brutal-empty px-3 py-4 text-sm text-center">${unsafeHTML(emptyContent)}</div>`;
    }
    getPortalTemplate() {
        return html `
      <div class="${this.brutalDropdownClasses()}">
        ${this.brutalSearchInput()} ${this.brutalItems()}
      </div>
    `;
    }
    brutalHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<p class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
    }
    brutalError() {
        if (this.error === '')
            return html ``;
        const errorId = `error-${this.name || 'select'}`;
        return html `<p id="${errorId}" class="brutal-error-text mt-1 text-xs">${this.error}</p>`;
    }
    brutalFeedback() {
        if (this.error !== '') {
            return this.brutalError();
        }
        return this.brutalHelper();
    }
    brutalViewMode() {
        const selectedItem = this.x.findItem(this.value);
        const displayValue = selectedItem ? selectedItem.label : this.bMsg.noSelection;
        return html `
      <div class="text-sm">
        ${this.hasSlot('Label')
            ? html `
              <span class="brutal-view-label">${unsafeHTML(this.getSlotContent('Label'))}:</span>
              <span class="brutal-view-value ml-1">${unsafeHTML(displayValue)}</span>
            `
            : html `<span class="brutal-view-value">${unsafeHTML(displayValue)}</span>`}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        if (!this.isEditing) {
            return this.brutalViewMode();
        }
        return html `
      <div class="relative w-full">
        ${this.brutalLabel()} ${this.brutalTrigger()} ${this.brutalFeedback()}
      </div>
    `;
    }
};
MlSelectDropdownBrutal = __decorate([
    customElement('groupselectone--ml-select-dropdown-brutal')
], MlSelectDropdownBrutal);
export { MlSelectDropdownBrutal };
