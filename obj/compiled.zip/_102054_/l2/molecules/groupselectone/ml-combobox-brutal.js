var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-combobox-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COMBOBOX — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlComboboxMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlComboboxMolecule } from '/_102040_/l2/molecules/groupselectone/ml-combobox.js';
let MlComboboxBrutal = class MlComboboxBrutal extends MlComboboxMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-combobox-brutal,
div[data-widget="groupselectone--ml-combobox-brutal"] {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-radius-md: 0;
  --ml-radius-lg: 0;
  --ml-primary: #3b82f6;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupselectone--ml-combobox-brutal label.ml-label,
div[data-widget="groupselectone--ml-combobox-brutal"] label.ml-label {
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-combobox-brutal div.ml-label,
div[data-widget="groupselectone--ml-combobox-brutal"] div.ml-label {
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: #555555;
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-combobox-brutal .ml-helper,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-combobox-brutal .ml-error-text,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-combobox-brutal .ml-text,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-combobox-brutal .ml-text-muted,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-combobox-brutal span.ml-text-muted,
div[data-widget="groupselectone--ml-combobox-brutal"] span.ml-text-muted {
  color: var(--ml-on-surface, #000000);
}
groupselectone--ml-combobox-brutal button.ml-text-muted,
div[data-widget="groupselectone--ml-combobox-brutal"] button.ml-text-muted {
  color: #000000;
  border: 2px solid #000000;
  border-radius: 0;
  background: #ffffff;
}
groupselectone--ml-combobox-brutal button.ml-text-muted:hover,
div[data-widget="groupselectone--ml-combobox-brutal"] button.ml-text-muted:hover {
  background: #000000;
  color: #ffffff;
}
groupselectone--ml-combobox-brutal button.ml-text-muted:focus-visible,
div[data-widget="groupselectone--ml-combobox-brutal"] button.ml-text-muted:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-combobox-brutal li.ml-text-muted[role="presentation"],
div[data-widget="groupselectone--ml-combobox-brutal"] li.ml-text-muted[role="presentation"] {
  color: #555555;
  font-weight: var(--ml-font-weight-medium, 700);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  border-bottom: 2px solid #000000;
}
groupselectone--ml-combobox-brutal .ml-disabled,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-combobox-brutal .ml-select-trigger,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  box-shadow: 3px 3px 0 #000000;
  transition: none;
}
groupselectone--ml-combobox-brutal .ml-select-trigger:hover:not(.ml-disabled):not(.ml-select-trigger-open),
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger:hover:not(.ml-disabled):not(.ml-select-trigger-open) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-combobox-brutal .ml-select-trigger:focus-visible,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-combobox-brutal div.ml-select-trigger,
div[data-widget="groupselectone--ml-combobox-brutal"] div.ml-select-trigger {
  background: #e5e5e5;
  box-shadow: none;
}
groupselectone--ml-combobox-brutal .ml-select-trigger-open,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger-open {
  box-shadow: 1px 1px 0 #000000;
  transform: translate(2px, 2px);
}
groupselectone--ml-combobox-brutal .ml-select-trigger-error,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectone--ml-combobox-brutal .ml-select-trigger-error.ml-select-trigger-open,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger-error.ml-select-trigger-open {
  box-shadow: 1px 1px 0 #ef4444;
}
groupselectone--ml-combobox-brutal .ml-select-trigger.ml-disabled,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger.ml-disabled {
  border-color: #999999;
}
groupselectone--ml-combobox-brutal .ml-select-trigger[readonly],
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-trigger[readonly] {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-combobox-brutal .ml-combobox-input,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-combobox-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-combobox-brutal .ml-combobox-input::placeholder,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-combobox-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-combobox-brutal .ml-select-panel,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-lg, 0);
  box-shadow: 4px 4px 0 #000000;
  list-style: none;
  padding-left: 0;
}
groupselectone--ml-combobox-brutal .ml-select-empty,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-empty {
  color: #666666;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-combobox-brutal .ml-select-item,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-item {
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  border-bottom: 1px solid #e5e5e5;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  transition: none;
}
groupselectone--ml-combobox-brutal .ml-select-item:last-child,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-item:last-child {
  border-bottom: none;
}
groupselectone--ml-combobox-brutal .ml-select-item:hover:not(.ml-disabled):not(.ml-select-item-selected),
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-item:hover:not(.ml-disabled):not(.ml-select-item-selected) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-combobox-brutal .ml-select-item-highlighted,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-item-highlighted {
  background: #e5e5e5;
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-combobox-brutal .ml-select-item-selected,
div[data-widget="groupselectone--ml-combobox-brutal"] .ml-select-item-selected {
  background: #000000;
  color: #ffffff;
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-combobox-brutal svg.ml-select-checkmark,
div[data-widget="groupselectone--ml-combobox-brutal"] svg.ml-select-checkmark {
  color: var(--ml-primary, #3b82f6);
}
groupselectone--ml-combobox-brutal svg.ml-select-checkmark.ml-auto,
div[data-widget="groupselectone--ml-combobox-brutal"] svg.ml-select-checkmark.ml-auto {
  color: #ffffff;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-brutal"].
        this.portalWidgetName = 'groupselectone--ml-combobox-brutal';
    }
};
MlComboboxBrutal = __decorate([
    customElement('groupselectone--ml-combobox-brutal')
], MlComboboxBrutal);
export { MlComboboxBrutal };
