var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-card-selector-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CARD SELECTOR — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Herda MlCardSelectorMolecule (mls-102040): parsing de Item/Group, busca,
// navegacao por teclado, abertura/fechamento de painel, outside-click e estado
// (isOpen/searchQuery/focusedIndex). Sobrescreve apenas render() + helpers
// presentacionais com classes brutal. This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlCardSelectorMolecule } from '/_102040_/l2/molecules/groupselectone/ml-card-selector.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opcao',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        noValue: '—',
    },
};
let MlCardSelectorBrutal = class MlCardSelectorBrutal extends MlCardSelectorMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-card-selector-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-card-selector-brutal .brutal-cs-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-card-selector-brutal .brutal-cs-req {
  color: #ef4444;
}
groupselectone--ml-card-selector-brutal .brutal-helper {
  color: #555;
}
groupselectone--ml-card-selector-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupselectone--ml-card-selector-brutal .brutal-cs-chevron {
  color: #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-empty {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupselectone--ml-card-selector-brutal .brutal-cs-group {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-card-selector-brutal .brutal-cs-check {
  color: #3b82f6;
}
groupselectone--ml-card-selector-brutal .brutal-cs-loading-icon {
  display: inline-block;
  animation: brutal-spin 1s steps(8) infinite;
}
@keyframes brutal-spin {
  to {
    transform: rotate(360deg);
  }
}
groupselectone--ml-card-selector-brutal .brutal-cs-view {
  color: #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-view .brutal-cs-view-label {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger:hover:not(.is-disabled):not(.is-open):not(.is-error) {
  background: #f5f5f5;
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger.is-open {
  box-shadow: 1px 1px 0 #000;
  transform: translate(2px, 2px);
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger.is-readonly {
  cursor: default;
}
groupselectone--ml-card-selector-brutal .brutal-cs-trigger:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectone--ml-card-selector-brutal .brutal-cs-value {
  color: #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-value.is-placeholder {
  color: #999;
}
groupselectone--ml-card-selector-brutal .brutal-cs-panel,
.brutal-cs-portal .brutal-cs-panel {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 4px 4px 0 #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-search-row,
.brutal-cs-portal .brutal-cs-search-row {
  border-bottom: 3px solid #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-search,
.brutal-cs-portal .brutal-cs-search {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  outline: none;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-card-selector-brutal .brutal-cs-search::placeholder,
.brutal-cs-portal .brutal-cs-search::placeholder {
  color: #999;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-card-selector-brutal .brutal-cs-search:focus,
.brutal-cs-portal .brutal-cs-search:focus {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectone--ml-card-selector-brutal .brutal-cs-card,
.brutal-cs-portal .brutal-cs-card {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 2px 2px 0 #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-card:hover:not(.is-disabled):not(.is-selected),
.brutal-cs-portal .brutal-cs-card:hover:not(.is-disabled):not(.is-selected) {
  background: #f5f5f5;
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 #000;
}
groupselectone--ml-card-selector-brutal .brutal-cs-card.is-selected,
.brutal-cs-portal .brutal-cs-card.is-selected {
  background: #3b82f6;
  color: #fff;
  border-color: #000;
  box-shadow: 1px 1px 0 #000;
  transform: translate(1px, 1px);
}
groupselectone--ml-card-selector-brutal .brutal-cs-card.is-focused,
.brutal-cs-portal .brutal-cs-card.is-focused {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectone--ml-card-selector-brutal .brutal-cs-card.is-disabled,
.brutal-cs-portal .brutal-cs-card.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupselectone--ml-card-selector-brutal .brutal-cs-group,
.brutal-cs-portal .brutal-cs-group {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-card-selector-brutal .brutal-cs-empty,
.brutal-cs-portal .brutal-cs-empty {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupselectone--ml-card-selector-brutal .brutal-cs-check,
.brutal-cs-portal .brutal-cs-check {
  color: #fff;
}
`);
        this.portalClassName = 'brutal-cs-portal';
        this.bMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CSS CLASSES (brutal)
    // ===========================================================================
    brutalTriggerClasses() {
        const hasError = this.error !== '';
        return [
            'brutal-cs-trigger w-full min-h-[44px] px-4 py-3 text-sm',
            'flex items-center justify-between gap-2',
            hasError ? 'is-error' : '',
            this.x.isOpen ? 'is-open' : '',
            this.disabled ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalCardClasses(item, isSelected, isFocused) {
        return [
            'brutal-cs-card p-4',
            isSelected ? 'is-selected' : '',
            isFocused && !isSelected ? 'is-focused' : '',
            item.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalSearchInputClasses() {
        return 'brutal-cs-search w-full px-3 py-2 text-sm';
    }
    brutalGroupLabelClasses() {
        return 'brutal-cs-group text-xs font-bold uppercase tracking-wider mb-2';
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'card-selector'}`;
        return html `
      <label id="${labelId}" class="brutal-cs-label block text-sm font-bold mb-1.5">
        ${unsafeHTML(labelContent)}
        ${this.required ? html `<span class="brutal-cs-req ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    brutalTrigger() {
        const x = this.x;
        const selectedItem = x.findItem(this.value);
        const placeholderText = this.placeholder || this.getSlotContent('Trigger') || this.bMsg.placeholder;
        const hasError = this.error !== '';
        const labelId = `label-${this.name || 'card-selector'}`;
        const errorId = `error-${this.name || 'card-selector'}`;
        return html `
      <button
        type="button"
        role="combobox"
        aria-expanded="${x.isOpen}"
        aria-haspopup="listbox"
        aria-labelledby="${this.hasSlot('Label') ? labelId : ''}"
        aria-describedby="${hasError ? errorId : ''}"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        ?disabled="${this.disabled}"
        class="${this.brutalTriggerClasses()}"
        @click="${(e) => x.handleTriggerClick(e)}"
      >
        <span class="brutal-cs-value flex-1 text-left ${!selectedItem ? 'is-placeholder' : ''}">
          ${this.loading
            ? html `<span class="flex items-center gap-2">
                <span class="brutal-cs-loading-icon">&#9881;</span>
                ${this.bMsg.loading}
              </span>`
            : selectedItem
                ? selectedItem.label
                : unsafeHTML(placeholderText)}
        </span>
        <svg
          class="brutal-cs-chevron w-5 h-5 ${x.isOpen ? 'rotate-180' : ''}"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>
    `;
    }
    brutalSearch() {
        if (!this.searchable)
            return html ``;
        const x = this.x;
        return html `
      <div class="brutal-cs-search-row p-3">
        <input
          type="text"
          class="${this.brutalSearchInputClasses()}"
          placeholder="${this.bMsg.searchPlaceholder}"
          .value="${x.searchQuery}"
          @input="${(e) => x.handleSearchInput(e)}"
        />
      </div>
    `;
    }
    brutalCard(item) {
        const x = this.x;
        const isSelected = this.value === item.value;
        const selectableItems = x.getSelectableItems();
        const selectableIndex = selectableItems.findIndex(i => i.value === item.value);
        const isFocused = selectableIndex === x.focusedIndex;
        return html `
      <div
        role="option"
        aria-selected="${isSelected}"
        aria-disabled="${item.disabled}"
        class="${this.brutalCardClasses(item, isSelected, isFocused)}"
        @click="${() => !item.disabled && x.handleSelect(item.value)}"
      >
        <div class="flex items-start gap-3">
          <div class="flex-1">
            ${unsafeHTML(item.content)}
          </div>
          ${isSelected ? html `
            <div class="flex-shrink-0">
              <svg class="brutal-cs-check w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
              </svg>
            </div>
          ` : html ``}
        </div>
      </div>
    `;
    }
    brutalCardGrid() {
        const x = this.x;
        const standaloneItems = x.getFilteredItems(x.parseItems());
        const groups = x.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some(g => x.getFilteredItems(g.items).length > 0);
        if (!hasItems) {
            return this.brutalEmpty();
        }
        return html `
      <div class="p-4">
        ${groups.map(group => {
            const filteredGroupItems = x.getFilteredItems(group.items);
            if (filteredGroupItems.length === 0)
                return html ``;
            return html `
            <div class="mb-4 last:mb-0">
              <div class="${this.brutalGroupLabelClasses()}">${group.label}</div>
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                ${filteredGroupItems.map(item => this.brutalCard(item))}
              </div>
            </div>
          `;
        })}
        ${standaloneItems.length > 0 ? html `
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            ${standaloneItems.map(item => this.brutalCard(item))}
          </div>
        ` : html ``}
      </div>
    `;
    }
    brutalEmpty() {
        const emptyContent = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.bMsg.noResults;
        return html `
      <div class="brutal-cs-empty p-8 text-center">
        ${unsafeHTML(emptyContent)}
      </div>
    `;
    }
    getPortalTemplate() {
        return html `
      <div role="listbox" class="brutal-cs-panel w-full max-h-[400px] overflow-auto">
        ${this.brutalSearch()}
        ${this.brutalCardGrid()}
      </div>
    `;
    }
    brutalHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        const helperContent = this.getSlotContent('Helper');
        return html `<p class="brutal-helper mt-1.5 text-xs">${unsafeHTML(helperContent)}</p>`;
    }
    brutalError() {
        if (!this.error)
            return html ``;
        const errorId = `error-${this.name || 'card-selector'}`;
        return html `<p id="${errorId}" class="brutal-error-text mt-1.5 text-xs">${unsafeHTML(this.error)}</p>`;
    }
    brutalFeedback() {
        if (this.error) {
            return this.brutalError();
        }
        return this.brutalHelper();
    }
    brutalViewMode() {
        const selectedItem = this.x.findItem(this.value);
        const displayValue = selectedItem
            ? selectedItem.label
            : (this.placeholder || this.bMsg.noValue);
        return html `
      <div class="brutal-cs-view text-sm">
        ${this.hasSlot('Label') ? html `
          <span class="brutal-cs-view-label">
            ${unsafeHTML(this.getSlotContent('Label'))}:
          </span>
          <span class="ml-1">${displayValue}</span>
        ` : html `
          <span>${displayValue}</span>
        `}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        if (!this.isEditing) {
            return this.brutalViewMode();
        }
        return html `
      <div class="relative w-full">
        ${this.brutalLabel()}
        ${this.brutalTrigger()}
        ${this.brutalFeedback()}
      </div>
    `;
    }
};
MlCardSelectorBrutal = __decorate([
    customElement('groupselectone--ml-card-selector-brutal')
], MlCardSelectorBrutal);
export { MlCardSelectorBrutal };
