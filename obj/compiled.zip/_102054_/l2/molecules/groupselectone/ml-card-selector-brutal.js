var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-card-selector-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CARD SELECTOR — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlCardSelectorMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlCardSelectorMolecule } from '/_102040_/l2/molecules/groupselectone/ml-card-selector.js';
let MlCardSelectorBrutal = class MlCardSelectorBrutal extends MlCardSelectorMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-card-selector-brutal,
div[data-widget="groupselectone--ml-card-selector-brutal"] {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-radius-md: 0;
  --ml-radius-lg: 0;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupselectone--ml-card-selector-brutal .ml-label,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-label {
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-card-selector-brutal .ml-helper,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-helper {
  color: #555555;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-card-selector-brutal .ml-error-text,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-card-selector-brutal .ml-text,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-card-selector-brutal .ml-text-muted,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-card-selector-brutal svg.ml-text-muted,
div[data-widget="groupselectone--ml-card-selector-brutal"] svg.ml-text-muted {
  color: var(--ml-on-surface, #000000);
}
groupselectone--ml-card-selector-brutal .ml-text-muted.uppercase,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-text-muted.uppercase {
  color: #555555;
  font-weight: var(--ml-font-weight-medium, 700);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-card-selector-brutal .ml-text .ml-text-muted,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-text .ml-text-muted {
  color: #555555;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-card-selector-brutal .animate-spin,
div[data-widget="groupselectone--ml-card-selector-brutal"] .animate-spin {
  animation-timing-function: steps(8);
}
groupselectone--ml-card-selector-brutal .ml-disabled,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-card-selector-brutal .ml-select-trigger,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-trigger {
  position: relative;
  color: var(--ml-on-surface, #000000);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  background: var(--ml-surface, #ffffff);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  cursor: pointer;
  box-shadow: 3px 3px 0 #000000;
  transition: none;
}
groupselectone--ml-card-selector-brutal .ml-select-trigger:hover:not(.ml-disabled):not(.ml-select-trigger-open),
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-trigger:hover:not(.ml-disabled):not(.ml-select-trigger-open) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-card-selector-brutal .ml-select-trigger:focus-visible,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-trigger:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-card-selector-brutal .ml-select-trigger-open,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-trigger-open {
  box-shadow: 1px 1px 0 #000000;
  transform: translate(2px, 2px);
}
groupselectone--ml-card-selector-brutal .ml-select-trigger-error,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-trigger-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectone--ml-card-selector-brutal .ml-select-trigger.ml-disabled,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-trigger.ml-disabled {
  border-color: #999999;
}
groupselectone--ml-card-selector-brutal .ml-combobox-input,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-combobox-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-card-selector-brutal .ml-combobox-input::placeholder,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-combobox-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-card-selector-brutal .ml-select-panel,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-lg, 0);
  box-shadow: 4px 4px 0 #000000;
}
groupselectone--ml-card-selector-brutal .ml-select-panel .ml-select-panel,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-panel .ml-select-panel {
  border: none;
  border-bottom: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: 0;
  box-shadow: none;
}
groupselectone--ml-card-selector-brutal .ml-select-empty,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-empty {
  color: #666666;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupselectone--ml-card-selector-brutal .ml-select-checkmark,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-checkmark {
  color: var(--ml-on-primary, #ffffff);
}
groupselectone--ml-card-selector-brutal .ml-select-item-highlighted,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-select-item-highlighted {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-card-selector-brutal .ml-card-option,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-card-option {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupselectone--ml-card-selector-brutal .ml-card-option:hover:not(.ml-disabled):not(.ml-card-option-selected),
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-card-option:hover:not(.ml-disabled):not(.ml-card-option-selected) {
  background: var(--ml-surface-dim, #f5f5f5);
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 #000000;
}
groupselectone--ml-card-selector-brutal .ml-card-option-selected,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-card-option-selected {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: #000000;
  box-shadow: 1px 1px 0 #000000;
  transform: translate(1px, 1px);
}
groupselectone--ml-card-selector-brutal .ml-card-option-error,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-card-option-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 2px 2px 0 #ef4444;
}
groupselectone--ml-card-selector-brutal .ml-card-option.ml-disabled,
div[data-widget="groupselectone--ml-card-selector-brutal"] .ml-card-option.ml-disabled {
  border-color: #999999;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-brutal"].
        this.portalWidgetName = 'groupselectone--ml-card-selector-brutal';
    }
};
MlCardSelectorBrutal = __decorate([
    customElement('groupselectone--ml-card-selector-brutal')
], MlCardSelectorBrutal);
export { MlCardSelectorBrutal };
