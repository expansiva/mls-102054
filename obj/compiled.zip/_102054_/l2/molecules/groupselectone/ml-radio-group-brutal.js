var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-radio-group-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RADIO GROUP — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Herda MlRadioGroupMolecule (mls-102040): parsing, teclado, eventos e estado
// reativo (focusedValue). Sobrescreve so render() com markup/classes brutal.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlRadioGroupMolecule } from '/_102040_/l2/molecules/groupselectone/ml-radio-group.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'No selection',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Nenhuma selecao',
        noOptions: 'Nenhuma opcao disponivel',
        loading: 'Carregando...',
    },
};
let MlRadioGroupBrutal = class MlRadioGroupBrutal extends MlRadioGroupMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-radio-group-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectone--ml-radio-group-brutal .brutal-rg-label {
  font-weight: 700;
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectone--ml-radio-group-brutal .brutal-required {
  color: #ef4444;
}
groupselectone--ml-radio-group-brutal .brutal-rg-option {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  cursor: pointer;
  box-shadow: 2px 2px 0 #000;
}
groupselectone--ml-radio-group-brutal .brutal-rg-option.is-selected {
  background: #000;
  color: #fff;
  box-shadow: 1px 1px 0 #000;
  transform: translate(1px, 1px);
}
groupselectone--ml-radio-group-brutal .brutal-rg-option.is-focused {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectone--ml-radio-group-brutal .brutal-rg-option.is-error {
  border-color: #ef4444;
  box-shadow: 2px 2px 0 #ef4444;
}
groupselectone--ml-radio-group-brutal .brutal-rg-option.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupselectone--ml-radio-group-brutal .brutal-rg-option:not(.is-disabled):not(.is-selected):hover {
  background: #f5f5f5;
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 #000;
}
groupselectone--ml-radio-group-brutal .brutal-rg-radio {
  border: 3px solid #000;
  background: #fff;
}
groupselectone--ml-radio-group-brutal .brutal-rg-radio.is-selected {
  border-color: #fff;
  background: #3b82f6;
}
groupselectone--ml-radio-group-brutal .brutal-rg-radio.is-disabled {
  opacity: 0.4;
  border-color: #999;
}
groupselectone--ml-radio-group-brutal .brutal-rg-dot {
  width: 0.5rem;
  height: 0.5rem;
  background: #fff;
}
groupselectone--ml-radio-group-brutal .brutal-rg-text {
  color: #000;
}
groupselectone--ml-radio-group-brutal .brutal-rg-text.is-selected {
  color: #fff;
  font-weight: 700;
}
groupselectone--ml-radio-group-brutal .brutal-rg-text.is-disabled {
  color: #999;
}
groupselectone--ml-radio-group-brutal .brutal-rg-group-label {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 2px solid #000;
}
groupselectone--ml-radio-group-brutal .brutal-rg-empty {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupselectone--ml-radio-group-brutal .brutal-rg-spinner {
  display: inline-block;
  animation: brutal-rg-spin 1s steps(8) infinite;
  font-size: 1rem;
  color: #000;
}
@keyframes brutal-rg-spin {
  to {
    transform: rotate(360deg);
  }
}
groupselectone--ml-radio-group-brutal .brutal-rg-loading-text {
  color: #555;
  font-weight: 700;
  text-transform: uppercase;
}
groupselectone--ml-radio-group-brutal .brutal-helper {
  color: #555;
}
groupselectone--ml-radio-group-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupselectone--ml-radio-group-brutal .brutal-rg-view-value {
  color: #000;
}
`);
        this.bMsg = messages.en;
        this.bLabelId = `label-${Math.random().toString(36).slice(2, 9)}`;
        this.bErrorId = `error-${Math.random().toString(36).slice(2, 9)}`;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalContainerClasses() {
        return ['flex flex-col gap-2', this.disabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalOptionClasses(item) {
        const isSelected = this.value === item.value;
        const isFocused = this.x.focusedValue === item.value;
        const hasError = this.error !== '';
        return [
            'brutal-rg-option',
            'flex items-center gap-3 px-3 py-2',
            isSelected ? 'is-selected' : '',
            isFocused && !isSelected ? 'is-focused' : '',
            hasError && !isSelected ? 'is-error' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalRadioClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'brutal-rg-radio',
            'w-4 h-4 flex items-center justify-center flex-shrink-0',
            isSelected ? 'is-selected' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalTextClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'brutal-rg-text',
            'text-sm',
            isSelected ? 'is-selected' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${this.bLabelId} class="brutal-rg-label text-sm">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="brutal-required ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    brutalRadioIndicator(item) {
        const isSelected = this.value === item.value;
        return html `<span class=${this.brutalRadioClasses(item)}>${isSelected ? html `<span class="brutal-rg-dot"></span>` : html ``}</span>`;
    }
    brutalOption(item) {
        const isSelected = this.value === item.value;
        return html `
      <div
        role="radio"
        aria-checked=${isSelected ? 'true' : 'false'}
        aria-disabled=${item.disabled || this.disabled || this.readonly || this.loading ? 'true' : 'false'}
        tabindex=${item.disabled || this.disabled || this.readonly || this.loading ? '-1' : '0'}
        class=${this.brutalOptionClasses(item)}
        @click=${() => this.x.handleSelect(item)}
        @focus=${() => this.x.handleFocus()}
        @blur=${() => this.x.handleBlur()}
      >
        ${this.brutalRadioIndicator(item)}
        <span class=${this.brutalTextClasses(item)}>${unsafeHTML(item.label)}</span>
      </div>
    `;
    }
    brutalGroup(group) {
        if (group.items.length === 0)
            return html ``;
        return html `
      <div class="flex flex-col gap-1">
        <span class="brutal-rg-group-label text-xs font-bold uppercase tracking-wide px-1">${group.label}</span>
        <div class="flex flex-col gap-1">${group.items.map((item) => this.brutalOption(item))}</div>
      </div>
    `;
    }
    brutalRadioOptions() {
        const standaloneItems = this.x.parseItems();
        const groups = this.x.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some((g) => g.items.length > 0);
        if (!hasItems) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.bMsg.noOptions;
            return html `<div class="brutal-rg-empty text-sm py-2">${unsafeHTML(emptyContent)}</div>`;
        }
        return html `
      <div
        role="radiogroup"
        aria-labelledby=${this.hasSlot('Label') ? this.bLabelId : ''}
        aria-required=${this.required ? 'true' : 'false'}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-describedby=${this.error ? this.bErrorId : ''}
        class="flex flex-col gap-2"
      >
        ${standaloneItems.map((item) => this.brutalOption(item))} ${groups.map((group) => this.brutalGroup(group))}
      </div>
    `;
    }
    brutalLoading() {
        return html `
      <div class="flex items-center gap-2 py-2">
        <span class="brutal-rg-spinner">&#9881;</span>
        <span class="brutal-rg-loading-text text-sm">${this.bMsg.loading}</span>
      </div>
    `;
    }
    brutalFeedback() {
        if (this.error) {
            return html `<p id=${this.bErrorId} class="brutal-error-text text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="brutal-helper text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalViewMode() {
        const selectedItem = this.x.findItem(this.value);
        const displayText = selectedItem ? selectedItem.label : this.placeholder || this.bMsg.placeholder;
        return html `
      <div class="flex flex-col gap-1">
        ${this.brutalLabel()}
        <span class="brutal-rg-view-value text-sm">${selectedItem ? unsafeHTML(displayText) : displayText}</span>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        if (!this.isEditing) {
            return this.brutalViewMode();
        }
        return html `
      <div class=${this.brutalContainerClasses()}>
        ${this.brutalLabel()} ${this.loading ? this.brutalLoading() : this.brutalRadioOptions()} ${this.brutalFeedback()}
      </div>
    `;
    }
};
MlRadioGroupBrutal = __decorate([
    customElement('groupselectone--ml-radio-group-brutal')
], MlRadioGroupBrutal);
export { MlRadioGroupBrutal };
