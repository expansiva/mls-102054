var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-radio-group.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RADIO GROUP MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupSelectOne
// Mesma molécula/contrato do mls-102040. Lógica intacta (parsing, teclado, eventos).
// Aparência (vidro) no .less escopado sob a tag. Layout via Tailwind.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'No selection',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Nenhuma seleção',
        noOptions: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
let MlRadioGroupMolecule = class MlRadioGroupMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-radio-group {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupselectone--ml-radio-group .glass-rg-label {
  font-weight: 600;
  color: rgba(255, 255, 255, 0.92);
}
groupselectone--ml-radio-group .glass-required {
  color: #ffb4ab;
}
groupselectone--ml-radio-group .glass-rg-option {
  position: relative;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  cursor: pointer;
  transition: background 200ms ease, border-color 200ms ease, box-shadow 200ms ease;
}
groupselectone--ml-radio-group .glass-rg-option.is-selected {
  background: rgba(99, 102, 241, 0.4);
  border-color: rgba(199, 210, 254, 0.8);
}
groupselectone--ml-radio-group .glass-rg-option.is-focused {
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupselectone--ml-radio-group .glass-rg-option.is-error {
  border-color: rgba(255, 120, 120, 0.8);
}
groupselectone--ml-radio-group .glass-rg-option.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupselectone--ml-radio-group .glass-rg-option:not(.is-disabled):not(.is-selected):hover {
  background: rgba(255, 255, 255, 0.14);
}
groupselectone--ml-radio-group .glass-rg-radio {
  border-radius: 9999px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.1);
  transition: border-color 200ms ease, background 200ms ease;
}
groupselectone--ml-radio-group .glass-rg-radio.is-selected {
  border-color: #c7d2fe;
  background: rgba(99, 102, 241, 0.9);
}
groupselectone--ml-radio-group .glass-rg-radio.is-disabled {
  opacity: 0.5;
}
groupselectone--ml-radio-group .glass-rg-dot {
  width: 0.5rem;
  height: 0.5rem;
  border-radius: 9999px;
  background: #fff;
}
groupselectone--ml-radio-group .glass-rg-text {
  color: rgba(255, 255, 255, 0.9);
  transition: color 200ms ease;
}
groupselectone--ml-radio-group .glass-rg-text.is-selected {
  color: #fff;
  font-weight: 500;
}
groupselectone--ml-radio-group .glass-rg-text.is-disabled {
  color: rgba(255, 255, 255, 0.45);
}
groupselectone--ml-radio-group .glass-rg-group-label {
  color: rgba(255, 255, 255, 0.55);
}
groupselectone--ml-radio-group .glass-rg-empty {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-radio-group .glass-rg-spinner {
  border: 2px solid rgba(199, 210, 254, 0.9);
  border-top-color: transparent;
}
groupselectone--ml-radio-group .glass-rg-loading-text {
  color: rgba(255, 255, 255, 0.65);
}
groupselectone--ml-radio-group .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupselectone--ml-radio-group .glass-error-text {
  color: #ffb4ab;
}
groupselectone--ml-radio-group .glass-rg-view-value {
  color: rgba(255, 255, 255, 0.95);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedValue = null;
        this.labelId = `label-${Math.random().toString(36).slice(2, 9)}`;
        this.errorId = `error-${Math.random().toString(36).slice(2, 9)}`;
        this.handleKeyDown = (e) => {
            if (this.disabled || this.readonly || this.loading || !this.isEditing)
                return;
            const selectableItems = this.getSelectableItems();
            if (selectableItems.length === 0)
                return;
            const currentIndex = this.focusedValue
                ? selectableItems.findIndex((item) => item.value === this.focusedValue)
                : this.value
                    ? selectableItems.findIndex((item) => item.value === this.value)
                    : -1;
            switch (e.key) {
                case 'ArrowDown':
                case 'ArrowRight': {
                    e.preventDefault();
                    const nextIndex = currentIndex < selectableItems.length - 1 ? currentIndex + 1 : 0;
                    this.focusedValue = selectableItems[nextIndex].value;
                    break;
                }
                case 'ArrowUp':
                case 'ArrowLeft': {
                    e.preventDefault();
                    const prevIndex = currentIndex > 0 ? currentIndex - 1 : selectableItems.length - 1;
                    this.focusedValue = selectableItems[prevIndex].value;
                    break;
                }
                case 'Enter':
                case ' ': {
                    e.preventDefault();
                    if (this.focusedValue) {
                        const item = this.findItem(this.focusedValue);
                        if (item && !item.disabled) {
                            this.handleSelect(item);
                        }
                    }
                    break;
                }
                case 'Escape': {
                    e.preventDefault();
                    this.focusedValue = null;
                    this.blur();
                    break;
                }
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('keydown', this.handleKeyDown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEventListener('keydown', this.handleKeyDown);
    }
    // ===========================================================================
    // PARSING HELPERS
    // ===========================================================================
    parseItems() {
        return this.getSlots('Item')
            .filter((el) => el.closest('Group') === null)
            .map((el) => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML.trim(),
            disabled: el.hasAttribute('disabled'),
        }));
    }
    parseGroups() {
        const groupElements = this.getSlots('Group');
        return groupElements.map((groupEl) => {
            const groupLabel = groupEl.getAttribute('label') || '';
            const itemElements = Array.from(groupEl.querySelectorAll('Item'));
            const items = itemElements.map((el) => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML.trim(),
                disabled: el.hasAttribute('disabled'),
            }));
            return { label: groupLabel, items };
        });
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap((g) => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find((item) => item.value === value);
    }
    getSelectableItems() {
        return this.getAllItems().filter((item) => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.focusedValue = null;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // CSS HELPERS  (aparência = classes glass; layout = Tailwind)
    // ===========================================================================
    getContainerClasses() {
        return ['flex flex-col gap-2', this.disabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    getOptionClasses(item) {
        const isSelected = this.value === item.value;
        const isFocused = this.focusedValue === item.value;
        const hasError = this.error !== '';
        return [
            'glass-rg-option',
            'flex items-center gap-3 px-3 py-2',
            isSelected ? 'is-selected' : '',
            isFocused && !isSelected ? 'is-focused' : '',
            hasError && !isSelected ? 'is-error' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getRadioClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'glass-rg-radio',
            'w-4 h-4 flex items-center justify-center flex-shrink-0',
            isSelected ? 'is-selected' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getLabelTextClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'glass-rg-text',
            'text-sm',
            isSelected ? 'is-selected' : '',
            item.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${this.labelId} class="glass-rg-label text-sm">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="glass-required ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderRadioIndicator(item) {
        const isSelected = this.value === item.value;
        return html `<span class=${this.getRadioClasses(item)}>${isSelected ? html `<span class="glass-rg-dot"></span>` : html ``}</span>`;
    }
    renderOption(item) {
        const isSelected = this.value === item.value;
        return html `
      <div
        role="radio"
        aria-checked=${isSelected ? 'true' : 'false'}
        aria-disabled=${item.disabled || this.disabled || this.readonly || this.loading ? 'true' : 'false'}
        tabindex=${item.disabled || this.disabled || this.readonly || this.loading ? '-1' : '0'}
        class=${this.getOptionClasses(item)}
        @click=${() => this.handleSelect(item)}
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
      >
        ${this.renderRadioIndicator(item)}
        <span class=${this.getLabelTextClasses(item)}>${unsafeHTML(item.label)}</span>
      </div>
    `;
    }
    renderGroup(group) {
        if (group.items.length === 0)
            return html ``;
        return html `
      <div class="flex flex-col gap-1">
        <span class="glass-rg-group-label text-xs font-semibold uppercase tracking-wide px-1">${group.label}</span>
        <div class="flex flex-col gap-1">${group.items.map((item) => this.renderOption(item))}</div>
      </div>
    `;
    }
    renderRadioOptions() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some((g) => g.items.length > 0);
        if (!hasItems) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noOptions;
            return html `<div class="glass-rg-empty text-sm py-2">${unsafeHTML(emptyContent)}</div>`;
        }
        return html `
      <div
        role="radiogroup"
        aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
        aria-required=${this.required ? 'true' : 'false'}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-describedby=${this.error ? this.errorId : ''}
        class="flex flex-col gap-2"
      >
        ${standaloneItems.map((item) => this.renderOption(item))} ${groups.map((group) => this.renderGroup(group))}
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class="flex items-center gap-2 py-2">
        <div class="glass-rg-spinner w-4 h-4 rounded-full animate-spin"></div>
        <span class="glass-rg-loading-text text-sm">${this.msg.loading}</span>
      </div>
    `;
    }
    renderFeedback() {
        if (this.error) {
            return html `<p id=${this.errorId} class="glass-error-text text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="glass-helper text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem ? selectedItem.label : this.placeholder || this.msg.placeholder;
        return html `
      <div class="flex flex-col gap-1">
        ${this.renderLabel()}
        <span class="glass-rg-view-value text-sm">${selectedItem ? unsafeHTML(displayText) : displayText}</span>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()} ${this.loading ? this.renderLoading() : this.renderRadioOptions()} ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlRadioGroupMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlRadioGroupMolecule.prototype, "focusedValue", void 0);
MlRadioGroupMolecule = __decorate([
    customElement('groupselectone--ml-radio-group')
], MlRadioGroupMolecule);
export { MlRadioGroupMolecule };
