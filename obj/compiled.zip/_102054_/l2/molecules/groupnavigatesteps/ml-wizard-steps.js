var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// WIZARD STEPS MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSteps
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    labelFallback: 'Steps',
    loading: 'Loading steps...',
    completed: 'completed',
};
const messages = {
    en: message_en,
    pt: {
        labelFallback: 'Etapas',
        loading: 'Carregando etapas...',
        completed: 'concluída',
    },
};
let MlWizardStepsMolecule = class MlWizardStepsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-wizard-steps {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnavigatesteps--ml-wizard-steps .glass-wz-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-loading {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  color: rgba(255, 255, 255, 0.7);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-step {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-step:hover:not(.is-disabled):not(.is-active) {
  background: rgba(255, 255, 255, 0.1);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-step.is-active {
  background: rgba(199, 210, 254, 0.16);
  border-color: rgba(199, 210, 254, 0.9);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-step.is-completed {
  border-color: rgba(16, 185, 129, 0.5);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-step.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupnavigatesteps--ml-wizard-steps .glass-wz-title {
  color: #fff;
}
groupnavigatesteps--ml-wizard-steps .glass-wz-desc {
  color: rgba(255, 255, 255, 0.55);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-dot {
  border-radius: 9999px;
  border: 1px solid rgba(255, 255, 255, 0.35);
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatesteps--ml-wizard-steps .glass-wz-dot.is-active {
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupnavigatesteps--ml-wizard-steps .glass-wz-dot.is-completed {
  border-color: rgba(16, 185, 129, 0.7);
  color: #6ee7b7;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Step'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = 0;
        this.linear = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedIndex = -1;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStepClick(step) {
        if (!this.canNavigateTo(step.index))
            return;
        this.focusedIndex = step.index;
        this.value = step.index;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: step.index, title: step.title }
        }));
    }
    handleContainerKeyDown(event) {
        if (this.disabled || this.loading)
            return;
        const steps = this.parseSteps();
        const currentFocus = this.getInitialFocusIndex(steps);
        if (steps.length === 0)
            return;
        const key = event.key;
        if (key === 'ArrowRight' || key === 'ArrowLeft') {
            event.preventDefault();
            const direction = key === 'ArrowRight' ? 1 : -1;
            const nextIndex = this.findNextFocusableIndex(steps, currentFocus, direction);
            if (nextIndex !== currentFocus) {
                this.focusedIndex = nextIndex;
            }
            return;
        }
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            const step = steps[currentFocus];
            if (step) {
                this.handleStepClick(step);
            }
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseSteps() {
        const stepElements = this.getSlots('Step');
        return stepElements.map((el, index) => {
            const title = el.getAttribute('title') || '';
            const description = el.getAttribute('description') || '';
            const completed = el.hasAttribute('completed');
            const disabled = el.hasAttribute('disabled');
            return { index, title, description, completed, disabled };
        });
    }
    canNavigateTo(targetIndex) {
        if (this.disabled || this.loading)
            return false;
        const steps = this.parseSteps();
        const target = steps[targetIndex];
        const current = steps[this.value];
        if (!target || target.disabled)
            return false;
        if (!this.linear)
            return true;
        if (!current)
            return false;
        const currentCompleted = current.completed;
        if (targetIndex <= this.value) {
            return target.completed || targetIndex === this.value;
        }
        if (targetIndex === this.value + 1) {
            return currentCompleted;
        }
        return currentCompleted && target.completed;
    }
    getInitialFocusIndex(steps) {
        const baseIndex = this.focusedIndex >= 0 ? this.focusedIndex : this.value;
        const clampedIndex = Math.max(0, Math.min(baseIndex, steps.length - 1));
        const target = steps[clampedIndex];
        if (target && !target.disabled)
            return clampedIndex;
        return this.findNextFocusableIndex(steps, clampedIndex, 1);
    }
    findNextFocusableIndex(steps, start, direction) {
        if (steps.length === 0)
            return 0;
        let index = start;
        for (let i = 0; i < steps.length; i += 1) {
            index = (index + direction + steps.length) % steps.length;
            const step = steps[index];
            if (step && !step.disabled)
                return index;
        }
        return start;
    }
    getStepClasses(step, isActive) {
        const isClickable = this.canNavigateTo(step.index);
        return [
            'glass-wz-step flex-1 min-w-0 px-3 py-3 text-left',
            isActive ? 'is-active' : '',
            step.completed && !isActive ? 'is-completed' : '',
            step.disabled || !isClickable ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getLabelText() {
        const raw = this.getSlotContent('Label');
        if (!raw)
            return this.msg.labelFallback;
        return raw.replace(/<[^>]*>/g, '').trim() || this.msg.labelFallback;
    }
    renderLoading() {
        return html `
      <div class="glass-wz-loading flex items-center gap-2 px-4 py-3 text-sm">
        <span class="inline-flex h-4 w-4 items-center justify-center">
          <svg class="h-4 w-4 animate-spin" viewBox="0 0 24 24" aria-hidden="true">
            ${svg `<circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="3" opacity="0.3"></circle>`}
            ${svg `<path d="M22 12a10 10 0 0 1-10 10" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>`}
          </svg>
        </span>
        <span>${this.msg.loading}</span>
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="glass-wz-label mb-3 text-sm font-medium">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderStep(step, isActive, tabIndex) {
        const isClickable = this.canNavigateTo(step.index);
        const ariaLabel = step.completed ? `${step.title} ${this.msg.completed}` : step.title;
        const dotClasses = [
            'glass-wz-dot flex h-6 w-6 items-center justify-center text-xs font-semibold',
            isActive ? 'is-active' : step.completed ? 'is-completed' : '',
        ].filter(Boolean).join(' ');
        return html `
      <button
        class="${this.getStepClasses(step, isActive)}"
        role="tab"
        aria-selected="${isActive ? 'true' : 'false'}"
        aria-disabled="${step.disabled ? 'true' : 'false'}"
        aria-label="${ariaLabel}"
        ?disabled=${this.disabled || this.loading || step.disabled || !isClickable}
        tabindex="${tabIndex}"
        @click=${() => this.handleStepClick(step)}
      >
        <div class="flex items-center gap-2">
          <span class="${dotClasses}">
            ${step.completed ? html `<span aria-hidden="true">✓</span>` : html `${step.index + 1}`}
          </span>
          <div class="min-w-0">
            <div class="glass-wz-title truncate text-sm font-semibold">${step.title}</div>
            ${step.description ? html `<div class="glass-wz-desc truncate text-xs">${step.description}</div>` : html ``}
          </div>
        </div>
      </button>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `${this.renderLoading()}`;
        }
        const steps = this.parseSteps();
        const focusIndex = this.getInitialFocusIndex(steps);
        const ariaLabel = this.getLabelText();
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        <div class="flex items-start gap-2" role="tablist" aria-label="${ariaLabel}" @keydown=${this.handleContainerKeyDown}>
          ${steps.map((step, index) => this.renderStep(step, index === this.value, index === focusIndex ? 0 : -1))}
        </div>
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], MlWizardStepsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "linear", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlWizardStepsMolecule.prototype, "focusedIndex", void 0);
MlWizardStepsMolecule = __decorate([
    customElement('groupnavigatesteps--ml-wizard-steps')
], MlWizardStepsMolecule);
export { MlWizardStepsMolecule };
