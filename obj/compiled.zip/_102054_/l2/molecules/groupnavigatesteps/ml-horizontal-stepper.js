var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// HORIZONTAL STEPPER MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSteps
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    completed: 'completed',
    loading: 'Loading steps...',
    stepperLabel: 'Progress steps',
};
const messages = {
    en: message_en,
    pt: {
        completed: 'concluído',
        loading: 'Carregando etapas...',
        stepperLabel: 'Etapas de progresso',
    },
};
let MlHorizontalStepperMolecule = class MlHorizontalStepperMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-horizontal-stepper {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnavigatesteps--ml-horizontal-stepper .is-loading {
  opacity: 0.6;
  pointer-events: none;
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-dot {
  border-radius: 9999px;
  border: 1px solid rgba(255, 255, 255, 0.25);
  background: rgba(255, 255, 255, 0.08);
  color: rgba(255, 255, 255, 0.8);
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease, box-shadow 0.15s ease;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-dot:hover:not(.is-disabled):not(.is-active) {
  background: rgba(255, 255, 255, 0.14);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-dot:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.4);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-dot.is-active {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-dot.is-completed {
  background: rgba(16, 185, 129, 0.18);
  border-color: rgba(16, 185, 129, 0.6);
  color: #6ee7b7;
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-dot.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-title {
  color: rgba(255, 255, 255, 0.8);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-title.is-active {
  color: #e0e7ff;
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-title.is-disabled {
  color: rgba(255, 255, 255, 0.4);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-desc {
  color: rgba(255, 255, 255, 0.55);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-desc.is-disabled {
  color: rgba(255, 255, 255, 0.35);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-connector {
  background: rgba(255, 255, 255, 0.2);
  transition: background 0.2s ease;
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-connector.is-completed {
  background: rgba(16, 185, 129, 0.6);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-loading {
  color: rgba(255, 255, 255, 0.7);
}
groupnavigatesteps--ml-horizontal-stepper .glass-hs-loading-dot {
  background: rgba(255, 255, 255, 0.5);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Step'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = 0;
        this.linear = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.focusedIndex = 0;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            const newValue = Number(value) || 0;
            this.value = newValue;
            this.focusedIndex = newValue;
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // =========================================================================
    firstUpdated() {
        this.focusedIndex = this.value || 0;
    }
    // ===========================================================================
    // PARSING
    // =========================================================================
    getSteps() {
        const elements = this.getSlots('Step');
        return elements.map((el) => {
            const title = (el.getAttribute('title') || '').trim();
            const description = (el.getAttribute('description') || '').trim();
            const disabled = el.hasAttribute('disabled');
            const completed = el.hasAttribute('completed');
            const iconHtml = el.innerHTML || '';
            return { title, description, disabled, completed, iconHtml };
        });
    }
    getLabelText() {
        const labelEl = this.getSlot('Label');
        return (labelEl?.textContent || '').trim();
    }
    // ===========================================================================
    // NAVIGATION LOGIC (UI-only)
    // =========================================================================
    isStepCompleted(index, step) {
        if (index < this.value)
            return true;
        return step.completed;
    }
    canNavigateTo(index, step, steps) {
        if (this.loading || this.disabled || step.disabled)
            return false;
        if (!this.linear)
            return true;
        return index <= this.value + 1;
    }
    getNextFocusableIndex(direction, steps) {
        const total = steps.length;
        if (total === 0)
            return 0;
        let idx = this.focusedIndex;
        for (let i = 0; i < total; i += 1) {
            idx = (idx + direction + total) % total;
            const step = steps[idx];
            if (this.canNavigateTo(idx, step, steps))
                return idx;
        }
        return this.focusedIndex;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleStepClick(index, step, steps) {
        if (!this.canNavigateTo(index, step, steps))
            return;
        this.value = index;
        this.focusedIndex = index;
        this.requestUpdate();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: index, title: step.title },
        }));
    }
    handleKeyDown(event, steps) {
        if (this.loading || this.disabled)
            return;
        if (event.key === 'ArrowRight') {
            event.preventDefault();
            this.focusedIndex = this.getNextFocusableIndex(1, steps);
            this.requestUpdate();
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            this.focusedIndex = this.getNextFocusableIndex(-1, steps);
            this.requestUpdate();
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            const step = steps[this.focusedIndex];
            if (step)
                this.handleStepClick(this.focusedIndex, step, steps);
        }
    }
    handleFocus(index) {
        this.focusedIndex = index;
    }
    // ===========================================================================
    // CLASSES (glass)
    // =========================================================================
    getIndicatorClasses(isActive, isCompleted, isDisabled) {
        return [
            'glass-hs-dot flex items-center justify-center text-sm font-semibold w-9 h-9',
            isActive ? 'is-active' : isCompleted ? 'is-completed' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getTitleClasses(isActive, isDisabled) {
        return [
            'glass-hs-title mt-2 text-xs font-medium text-center',
            isActive ? 'is-active' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getDescriptionClasses(isDisabled) {
        return ['glass-hs-desc mt-1 text-[11px] text-center', isDisabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    getContainerClasses() {
        return ['w-full', this.loading ? 'is-loading' : ''].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // =========================================================================
    renderLoading() {
        return html `
      <div class="glass-hs-loading flex items-center gap-2 text-sm">
        <span class="glass-hs-loading-dot h-2 w-2 rounded-full animate-pulse"></span>
        <span>${this.msg.loading}</span>
      </div>
    `;
    }
    renderStep(step, index, steps) {
        const isActive = index === this.value;
        const isCompleted = this.isStepCompleted(index, step);
        const isDisabled = this.disabled || this.loading || step.disabled || !this.canNavigateTo(index, step, steps);
        const indicatorClasses = this.getIndicatorClasses(isActive, isCompleted, isDisabled);
        const titleClasses = this.getTitleClasses(isActive, isDisabled);
        const descriptionClasses = this.getDescriptionClasses(isDisabled);
        const ariaLabel = isCompleted ? `${step.title} ${this.msg.completed}` : step.title;
        return html `
      <div class="flex flex-col items-center flex-none">
        <button
          class="${indicatorClasses}"
          type="button"
          role="tab"
          aria-selected="${isActive ? 'true' : 'false'}"
          aria-disabled="${isDisabled ? 'true' : 'false'}"
          aria-label="${ariaLabel}"
          tabindex="${this.focusedIndex === index ? '0' : '-1'}"
          @click=${() => this.handleStepClick(index, step, steps)}
          @focus=${() => this.handleFocus(index)}
        >
          ${step.iconHtml ? unsafeHTML(step.iconHtml) : html `<span>${index + 1}</span>`}
        </button>
        <div class="${titleClasses}">${step.title}</div>
        ${step.description ? html `<div class="${descriptionClasses}">${step.description}</div>` : html ``}
      </div>
    `;
    }
    renderConnector(afterIndex) {
        const isCompleted = afterIndex < this.value;
        return html `
      <div class="flex-1 flex items-start pt-[18px] px-2">
        <div class="glass-hs-connector h-0.5 w-full ${isCompleted ? 'is-completed' : ''}"></div>
      </div>
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const steps = this.getSteps();
        const labelText = this.getLabelText();
        const ariaLabel = labelText || this.msg.stepperLabel;
        return html `
      <div class="${this.getContainerClasses()}">
        ${labelText
            ? html `<div class="glass-hs-label mb-3 text-sm font-semibold">${unsafeHTML(this.getSlotContent('Label'))}</div>`
            : html ``}
        <div
          class="flex items-start"
          role="tablist"
          aria-label="${ariaLabel}"
          aria-busy="${this.loading ? 'true' : 'false'}"
          @keydown=${(e) => this.handleKeyDown(e, steps)}
        >
          ${steps.map((step, index) => html `
            ${this.renderStep(step, index, steps)}
            ${index < steps.length - 1 ? this.renderConnector(index) : html ``}
          `)}
        </div>
        ${this.loading ? html `<div class="mt-3">${this.renderLoading()}</div>` : html ``}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], MlHorizontalStepperMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlHorizontalStepperMolecule.prototype, "linear", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlHorizontalStepperMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlHorizontalStepperMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlHorizontalStepperMolecule.prototype, "focusedIndex", void 0);
MlHorizontalStepperMolecule = __decorate([
    customElement('groupnavigatesteps--ml-horizontal-stepper')
], MlHorizontalStepperMolecule);
export { MlHorizontalStepperMolecule };
