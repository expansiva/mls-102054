var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// HORIZONTAL STEPPER — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSteps
// Herda MlHorizontalStepperMolecule (mls-102040): parsing de Step slots, lógica
// de navegação linear, completed/active, teclado (Arrow/Enter/Space), estado
// reativo (focusedIndex) e dispatch de change. Sobrescreve apenas render() +
// helpers presentacionais brutal.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlHorizontalStepperMolecule } from '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.js';
/// **collab_i18n_start**
const message_en = {
    completed: 'completed',
    loading: 'Loading steps...',
    stepperLabel: 'Progress steps',
};
const messages = {
    en: message_en,
    pt: {
        completed: 'concluído',
        loading: 'Carregando etapas...',
        stepperLabel: 'Etapas de progresso',
    },
};
let MlHorizontalStepperBrutal = class MlHorizontalStepperBrutal extends MlHorizontalStepperMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-horizontal-stepper-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .is-loading {
  opacity: 0.4;
  pointer-events: none;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-label {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-dot {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-dot:hover:not(.is-disabled):not(.is-active) {
  background: #eee;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-dot:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-dot.is-active {
  background: #3b82f6;
  border-color: #000;
  color: #fff;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-dot.is-completed {
  background: #000;
  border-color: #000;
  color: #fff;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-dot.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-title {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-title.is-active {
  color: #3b82f6;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-title.is-disabled {
  color: #999;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-desc {
  color: #666;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-desc.is-disabled {
  color: #999;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-connector {
  background: #ccc;
  height: 3px;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-connector.is-completed {
  background: #000;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-loading {
  color: #666;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .brutal-hs-loading-dot {
  background: #000;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalIndicatorClasses(isActive, isCompleted, isDisabled) {
        return [
            'brutal-hs-dot flex items-center justify-center text-sm font-bold w-9 h-9',
            isActive ? 'is-active' : isCompleted ? 'is-completed' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalTitleClasses(isActive, isDisabled) {
        return [
            'brutal-hs-title mt-2 text-xs font-bold text-center',
            isActive ? 'is-active' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalDescriptionClasses(isDisabled) {
        return ['brutal-hs-desc mt-1 text-[11px] text-center', isDisabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalContainerClasses() {
        return ['w-full', this.loading ? 'is-loading' : ''].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLoading() {
        return html `
      <div class="brutal-hs-loading flex items-center gap-2 text-sm">
        <span class="brutal-hs-loading-dot h-2 w-2"></span>
        <span>${this.gMsg.loading}</span>
      </div>
    `;
    }
    brutalStep(step, index, steps) {
        const x = this.x;
        const isActive = index === this.value;
        const isCompleted = x.isStepCompleted(index, step);
        const isDisabled = this.disabled || this.loading || step.disabled || !x.canNavigateTo(index, step, steps);
        const indicatorClasses = this.brutalIndicatorClasses(isActive, isCompleted, isDisabled);
        const titleClasses = this.brutalTitleClasses(isActive, isDisabled);
        const descriptionClasses = this.brutalDescriptionClasses(isDisabled);
        const ariaLabel = isCompleted ? `${step.title} ${this.gMsg.completed}` : step.title;
        return html `
      <div class="flex flex-col items-center flex-none">
        <button
          class="${indicatorClasses}"
          type="button"
          role="tab"
          aria-selected="${isActive ? 'true' : 'false'}"
          aria-disabled="${isDisabled ? 'true' : 'false'}"
          aria-label="${ariaLabel}"
          tabindex="${x.focusedIndex === index ? '0' : '-1'}"
          @click=${() => x.handleStepClick(index, step, steps)}
          @focus=${() => x.handleFocus(index)}
        >
          ${step.iconHtml ? unsafeHTML(step.iconHtml) : html `<span>${index + 1}</span>`}
        </button>
        <div class="${titleClasses}">${step.title}</div>
        ${step.description ? html `<div class="${descriptionClasses}">${step.description}</div>` : html ``}
      </div>
    `;
    }
    brutalConnector(afterIndex) {
        const isCompleted = afterIndex < this.value;
        return html `
      <div class="flex-1 flex items-start pt-[18px] px-2">
        <div class="brutal-hs-connector h-0.5 w-full ${isCompleted ? 'is-completed' : ''}"></div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        const steps = x.getSteps();
        const labelText = x.getLabelText();
        const ariaLabel = labelText || this.gMsg.stepperLabel;
        return html `
      <div class="${this.brutalContainerClasses()}">
        ${labelText
            ? html `<div class="brutal-hs-label mb-3 text-sm font-bold">${unsafeHTML(this.getSlotContent('Label'))}</div>`
            : html ``}
        <div
          class="flex items-start"
          role="tablist"
          aria-label="${ariaLabel}"
          aria-busy="${this.loading ? 'true' : 'false'}"
          @keydown=${(e) => x.handleKeyDown(e, steps)}
        >
          ${steps.map((step, index) => html `
            ${this.brutalStep(step, index, steps)}
            ${index < steps.length - 1 ? this.brutalConnector(index) : html ``}
          `)}
        </div>
        ${this.loading ? html `<div class="mt-3">${this.brutalLoading()}</div>` : html ``}
      </div>
    `;
    }
};
MlHorizontalStepperBrutal = __decorate([
    customElement('groupnavigatesteps--ml-horizontal-stepper-brutal')
], MlHorizontalStepperBrutal);
export { MlHorizontalStepperBrutal };
