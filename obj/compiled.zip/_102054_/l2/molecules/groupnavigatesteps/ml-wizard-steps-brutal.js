var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// WIZARD STEPS — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlWizardStepsMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlWizardStepsMolecule } from '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps.js';
let MlWizardStepsBrutal = class MlWizardStepsBrutal extends MlWizardStepsMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-wizard-steps-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-disabled-opacity: 0.4;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-label {
  color: var(--ml-on-surface);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-container {
  background: var(--ml-surface);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  border-radius: var(--ml-radius-sm);
  color: #666666;
  box-shadow: var(--ml-shadow-1);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step {
  background: var(--ml-surface);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  border-radius: var(--ml-radius-sm);
  box-shadow: var(--ml-shadow-1);
  transition: none;
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step:not(.ml-disabled):not(.ml-step-active):hover {
  background: #eeeeee;
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step:has(.ml-step-badge-done) {
  border-color: var(--ml-outline-variant);
  background: #f0f0f0;
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-active {
  background: var(--ml-primary);
  border-color: var(--ml-outline-variant);
  color: var(--ml-on-primary);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-text {
  color: var(--ml-on-surface);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-active .ml-text {
  color: var(--ml-on-primary);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-text-muted {
  color: #666666;
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-active .ml-text-muted {
  color: rgba(255, 255, 255, 0.8);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-badge,
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-badge-active,
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-badge-done {
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  color: var(--ml-on-surface);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-badge-active {
  border-color: var(--ml-on-primary);
  color: var(--ml-on-primary);
}
groupnavigatesteps--ml-wizard-steps-brutal .ml-step-badge-done {
  border-color: var(--ml-outline-variant);
  background: var(--ml-on-surface);
  color: var(--ml-on-primary);
}
`);
    }
};
MlWizardStepsBrutal = __decorate([
    customElement('groupnavigatesteps--ml-wizard-steps-brutal')
], MlWizardStepsBrutal);
export { MlWizardStepsBrutal };
