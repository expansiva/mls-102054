var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI SELECT DROPDOWN MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupSelectMany
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// Popover translúcido (base 0.85 para legibilidade). Layout via Tailwind.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select options',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    empty: 'No options available',
    selectedCount: 'selected',
    requiredError: 'Select at least one option',
    minSelectionError: 'Select at least {min} options',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione opções',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        empty: 'Nenhuma opção disponível',
        selectedCount: 'selecionado(s)',
        requiredError: 'Selecione pelo menos uma opção',
        minSelectionError: 'Selecione pelo menos {min} opções',
    },
};
let MultiSelectDropdownMolecule = class MultiSelectDropdownMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-select-dropdown {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupselectmany--ml-multi-select-dropdown .glass-label {
  font-weight: 600;
  color: rgba(255, 255, 255, 0.92);
}
groupselectmany--ml-multi-select-dropdown .glass-placeholder {
  color: rgba(255, 255, 255, 0.55);
}
groupselectmany--ml-multi-select-dropdown .glass-count {
  color: rgba(255, 255, 255, 0.85);
}
groupselectmany--ml-multi-select-dropdown .glass-tag {
  border-radius: 8px;
  background: rgba(99, 102, 241, 0.45);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupselectmany--ml-multi-select-dropdown .glass-trigger {
  position: relative;
  color: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  cursor: pointer;
  transition: border-color 250ms ease, box-shadow 250ms ease, background 250ms ease;
  text-align: left;
}
groupselectmany--ml-multi-select-dropdown .glass-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.45);
  pointer-events: none;
}
groupselectmany--ml-multi-select-dropdown .glass-trigger:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.3), 0 4px 16px rgba(0, 0, 0, 0.16);
}
groupselectmany--ml-multi-select-dropdown .glass-trigger.is-error {
  border-color: rgba(255, 120, 120, 0.85);
}
groupselectmany--ml-multi-select-dropdown .glass-trigger.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupselectmany--ml-multi-select-dropdown .glass-panel {
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 14px;
  background: rgba(30, 27, 75, 0.85);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.3);
}
groupselectmany--ml-multi-select-dropdown .glass-search-wrap {
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}
groupselectmany--ml-multi-select-dropdown .glass-search {
  background: rgba(255, 255, 255, 0.08);
  color: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 8px;
  outline: none;
}
groupselectmany--ml-multi-select-dropdown .glass-search::placeholder {
  color: rgba(255, 255, 255, 0.5);
}
groupselectmany--ml-multi-select-dropdown .glass-search:focus {
  border-color: rgba(199, 210, 254, 0.8);
}
groupselectmany--ml-multi-select-dropdown .glass-item {
  border-radius: 8px;
  border: 1px solid transparent;
  color: rgba(255, 255, 255, 0.9);
  background: transparent;
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease, border-color 150ms ease;
}
groupselectmany--ml-multi-select-dropdown .glass-item:not(.is-disabled):not(.is-selected):hover {
  background: rgba(255, 255, 255, 0.12);
}
groupselectmany--ml-multi-select-dropdown .glass-item.is-selected {
  background: rgba(99, 102, 241, 0.4);
  border-color: rgba(199, 210, 254, 0.7);
  color: #fff;
}
groupselectmany--ml-multi-select-dropdown .glass-item.is-disabled {
  opacity: 0.45;
  cursor: not-allowed;
}
groupselectmany--ml-multi-select-dropdown .glass-check {
  color: #c7d2fe;
}
groupselectmany--ml-multi-select-dropdown .glass-group-label {
  color: rgba(255, 255, 255, 0.6);
}
groupselectmany--ml-multi-select-dropdown .glass-empty {
  color: rgba(255, 255, 255, 0.6);
}
groupselectmany--ml-multi-select-dropdown .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupselectmany--ml-multi-select-dropdown .glass-error-text {
  color: #ffb4ab;
}
groupselectmany--ml-multi-select-dropdown .glass-view-box {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.06);
  color: rgba(255, 255, 255, 0.95);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.uid = `msd-${Math.random().toString(36).slice(2)}`;
        this.labelId = `${this.uid}-label`;
        this.helperId = `${this.uid}-helper`;
        this.errorId = `${this.uid}-error`;
        this.panelId = `${this.uid}-panel`;
        this.hasFocus = false;
        this.handleDocumentClick = (e) => {
            const target = e.target;
            if (!target || !this.contains(target)) {
                this.closePanel();
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.unregisterOutsideClick();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.toggleOpen();
    }
    handleTriggerKeydown(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.toggleOpen();
        }
    }
    handlePanelKeydown(e) {
        if (!this.isOpen)
            return;
        if (e.key === 'Escape') {
            e.preventDefault();
            this.closePanel();
            this.focusTrigger();
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const direction = e.key === 'ArrowDown' ? 1 : -1;
            this.moveOptionFocus(direction);
            return;
        }
        if (e.key === ' ' || e.key === 'Enter') {
            const active = document.activeElement;
            if (active && active.dataset.optionValue) {
                e.preventDefault();
                this.toggleSelection(active.dataset.optionValue);
            }
        }
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleOptionClick(value) {
        this.toggleSelection(value);
    }
    handleFocusIn() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
    }
    handleFocusOut(e) {
        if (!this.isEditing)
            return;
        const related = e.relatedTarget;
        if (this.hasFocus && (!related || !this.contains(related))) {
            this.hasFocus = false;
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            this.closePanel();
        }
    }
    // ===========================================================================
    // SELECTION LOGIC
    // ===========================================================================
    toggleSelection(value) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const selected = this.getSelectedValues();
        const isSelected = selected.includes(value);
        const maxReached = this.maxSelection > 0 && selected.length >= this.maxSelection;
        if (!isSelected && maxReached)
            return;
        const updated = isSelected ? selected.filter((v) => v !== value) : [...selected, value];
        this.value = updated.join(',');
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    // ===========================================================================
    // OPEN/CLOSE
    // ===========================================================================
    toggleOpen() {
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.registerOutsideClick();
            if (this.searchable) {
                setTimeout(() => this.focusSearchInput(), 0);
            }
        }
        else {
            this.closePanel();
        }
    }
    closePanel() {
        if (!this.isOpen)
            return;
        this.isOpen = false;
        this.searchQuery = '';
        this.unregisterOutsideClick();
    }
    registerOutsideClick() {
        document.addEventListener('pointerdown', this.handleDocumentClick);
    }
    unregisterOutsideClick() {
        document.removeEventListener('pointerdown', this.handleDocumentClick);
    }
    focusSearchInput() {
        const input = this.querySelector('input[data-search]');
        input?.focus();
    }
    focusTrigger() {
        const trigger = this.querySelector('[data-trigger]');
        trigger?.focus();
    }
    moveOptionFocus(direction) {
        const options = Array.from(this.querySelectorAll('[data-option]'));
        if (!options.length)
            return;
        const activeIndex = options.findIndex((el) => el === document.activeElement);
        const nextIndex = activeIndex === -1 ? 0 : (activeIndex + direction + options.length) % options.length;
        options[nextIndex]?.focus();
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    getSelectedValues() {
        return this.value
            .split(',')
            .map((v) => v.trim())
            .filter((v) => v.length > 0);
    }
    parseItem(el, groupLabel) {
        const value = el.getAttribute('value') || '';
        const disabled = el.hasAttribute('disabled');
        const labelHtml = el.innerHTML || value;
        const labelText = (el.textContent || value).trim();
        return { value, labelHtml, labelText, disabled, groupLabel };
    }
    getGroupedItems() {
        const groups = this.getSlots('Group');
        return groups
            .map((groupEl) => {
            const label = groupEl.getAttribute('label') || '';
            const items = Array.from(groupEl.querySelectorAll('Item'))
                .map((itemEl) => this.parseItem(itemEl, label))
                .filter((item) => item.value);
            return { label, items };
        })
            .filter((group) => group.items.length > 0);
    }
    getUngroupedItems() {
        const items = Array.from(this.querySelectorAll('Item'))
            .filter((itemEl) => !itemEl.closest('Group'))
            .map((itemEl) => this.parseItem(itemEl))
            .filter((item) => item.value);
        return items;
    }
    getAllItems() {
        const grouped = this.getGroupedItems().flatMap((g) => g.items);
        const ungrouped = this.getUngroupedItems();
        return [...grouped, ...ungrouped];
    }
    // ===========================================================================
    // RENDER HELPERS  (aparência = classes glass; layout = Tailwind)
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.labelId}" class="glass-label mb-1 block text-sm">${unsafeHTML(this.getSlotContent('Label'))}</label>
    `;
    }
    renderHelperOrError(errorMessage) {
        if (!this.isEditing)
            return html ``;
        if (errorMessage) {
            return html `<p id="${this.errorId}" class="glass-error-text mt-1 text-xs">${unsafeHTML(errorMessage)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.helperId}" class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderSelectedTags(items, selectedValues) {
        const selectedItems = selectedValues
            .map((value) => items.find((item) => item.value === value) || { value, labelHtml: value, labelText: value, disabled: false })
            .filter(Boolean);
        if (selectedItems.length === 0) {
            const placeholder = this.placeholder || this.msg.placeholder;
            return html `<span class="glass-placeholder">${placeholder}</span>`;
        }
        if (selectedItems.length > 3) {
            return html `<span class="glass-count">${selectedItems.length} ${this.msg.selectedCount}</span>`;
        }
        return html `
      <div class="flex flex-wrap gap-1">
        ${selectedItems.map((item) => html `<span class="glass-tag px-2 py-0.5 text-xs">${unsafeHTML(item.labelHtml)}</span>`)}
      </div>
    `;
    }
    getTriggerClasses(hasError) {
        return [
            'glass-trigger',
            'w-full px-3 py-2 text-sm flex flex-wrap items-center gap-2',
            hasError ? 'is-error' : '',
            this.disabled || this.readonly || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getPanelClasses() {
        return 'glass-panel absolute z-20 mt-2 w-full';
    }
    getItemClasses(item, isSelected, isDisabled) {
        return [
            'glass-item',
            'flex w-full items-center justify-between px-3 py-2 text-sm',
            isSelected ? 'is-selected' : '',
            isDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderOptionList(groups, items, selectedValues) {
        const query = this.searchQuery.trim().toLowerCase();
        const filterItem = (item) => !query || item.labelText.toLowerCase().includes(query);
        const filteredGroups = groups
            .map((group) => ({ ...group, items: group.items.filter(filterItem) }))
            .filter((group) => group.items.length > 0);
        const filteredItems = items.filter(filterItem);
        if (!filteredGroups.length && !filteredItems.length) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
            return html `<div class="glass-empty px-3 py-4 text-sm">${unsafeHTML(emptyContent)}</div>`;
        }
        const maxReached = this.maxSelection > 0 && selectedValues.length >= this.maxSelection;
        return html `
      <div class="max-h-60 overflow-auto p-2" role="listbox" aria-multiselectable="true" id="${this.panelId}">
        ${filteredGroups.map((group) => html `
            <div class="mb-2">
              ${group.label ? html `<div class="glass-group-label px-2 py-1 text-xs font-semibold">${group.label}</div>` : html ``}
              ${group.items.map((item) => {
            const isSelected = selectedValues.includes(item.value);
            const isDisabled = item.disabled || (!isSelected && maxReached);
            return html `
                  <button
                    class="${this.getItemClasses(item, isSelected, isDisabled)}"
                    role="option"
                    aria-selected="${isSelected}"
                    aria-disabled="${isDisabled}"
                    type="button"
                    ?disabled=${isDisabled}
                    @mousedown=${(e) => e.preventDefault()}
                    @click=${() => this.handleOptionClick(item.value)}
                    .data-option=${true}
                    .data-option-value=${item.value}
                  >
                    <span>${unsafeHTML(item.labelHtml)}</span>
                    ${isSelected ? html `<span class="glass-check">✓</span>` : html ``}
                  </button>
                `;
        })}
            </div>
          `)}
        ${filteredItems.map((item) => {
            const isSelected = selectedValues.includes(item.value);
            const isDisabled = item.disabled || (!isSelected && maxReached);
            return html `
            <button
              class="${this.getItemClasses(item, isSelected, isDisabled)}"
              role="option"
              aria-selected="${isSelected}"
              aria-disabled="${isDisabled}"
              type="button"
              ?disabled=${isDisabled}
              @mousedown=${(e) => e.preventDefault()}
              @click=${() => this.handleOptionClick(item.value)}
              .data-option=${true}
              .data-option-value=${item.value}
            >
              <span>${unsafeHTML(item.labelHtml)}</span>
              ${isSelected ? html `<span class="glass-check">✓</span>` : html ``}
            </button>
          `;
        })}
      </div>
    `;
    }
    renderTriggerContent(items, selectedValues) {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        return this.renderSelectedTags(items, selectedValues);
    }
    getComputedError(selectedCount) {
        if (this.error)
            return this.error;
        if (this.minSelection > 0 && selectedCount < this.minSelection) {
            return this.msg.minSelectionError.replace('{min}', String(this.minSelection));
        }
        if (this.required && selectedCount === 0) {
            return this.msg.requiredError;
        }
        return '';
    }
    renderViewMode() {
        const items = this.getAllItems();
        const selectedValues = this.getSelectedValues();
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        <div class="glass-view-box px-3 py-2 text-sm">${this.renderSelectedTags(items, selectedValues)}</div>
        ${this.name ? html `<input type="hidden" name="${this.name}" value="${this.value}" />` : html ``}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const groups = this.getGroupedItems();
        const items = this.getUngroupedItems();
        const allItems = [...groups.flatMap((g) => g.items), ...items];
        const selectedValues = this.getSelectedValues();
        const errorMessage = this.getComputedError(selectedValues.length);
        const hasError = Boolean(errorMessage);
        const describedBy = hasError ? this.errorId : this.hasSlot('Helper') ? this.helperId : undefined;
        const labelAttr = this.hasSlot('Label') ? this.labelId : undefined;
        const isPanelOpen = this.isOpen && !this.loading;
        return html `
      <div class="w-full" @focusin=${this.handleFocusIn} @focusout=${this.handleFocusOut} @keydown=${this.handlePanelKeydown}>
        ${this.renderLabel()}
        <div class="relative">
          <button
            class="${this.getTriggerClasses(hasError)}"
            type="button"
            role="combobox"
            aria-expanded="${isPanelOpen}"
            aria-haspopup="listbox"
            aria-required="${this.required}"
            aria-invalid="${hasError}"
            ${labelAttr ? html `aria-labelledby="${labelAttr}"` : html `aria-label="${this.placeholder || this.msg.placeholder}"`}
            ${describedBy ? html `aria-describedby="${describedBy}"` : html ``}
            @keydown=${this.handleTriggerKeydown}
            @click=${this.handleTriggerClick}
            .data-trigger=${true}
          >
            ${this.loading
            ? html `<span class="glass-placeholder">${this.msg.loading}</span>`
            : this.renderTriggerContent(allItems, selectedValues)}
          </button>
          ${isPanelOpen
            ? html `
                <div class="${this.getPanelClasses()}">
                  ${this.searchable
                ? html `
                        <div class="glass-search-wrap p-2">
                          <input
                            class="glass-search w-full px-3 py-2 text-sm"
                            type="text"
                            placeholder="${this.msg.searchPlaceholder}"
                            .value=${this.searchQuery}
                            @input=${this.handleSearchInput}
                            data-search
                          />
                        </div>
                      `
                : html ``}
                  ${this.renderOptionList(groups, items, selectedValues)}
                </div>
              `
            : html ``}
        </div>
        ${this.renderHelperOrError(errorMessage)}
        ${this.name ? html `<input type="hidden" name="${this.name}" value="${this.value}" />` : html ``}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MultiSelectDropdownMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MultiSelectDropdownMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MultiSelectDropdownMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MultiSelectDropdownMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MultiSelectDropdownMolecule.prototype, "searchQuery", void 0);
MultiSelectDropdownMolecule = __decorate([
    customElement('groupselectmany--ml-multi-select-dropdown')
], MultiSelectDropdownMolecule);
export { MultiSelectDropdownMolecule };
