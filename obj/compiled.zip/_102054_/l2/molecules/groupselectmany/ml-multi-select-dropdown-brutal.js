var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI SELECT DROPDOWN — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MultiSelectDropdownMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MultiSelectDropdownMolecule } from '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown.js';
let MultiSelectDropdownBrutal = class MultiSelectDropdownBrutal extends MultiSelectDropdownMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-select-dropdown-brutal,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #666666;
  --ml-error: #ef4444;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-radius-md: 0;
  --ml-radius-lg: 0;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  font-family: var(--ml-font-family);
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-label,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-label {
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  color: var(--ml-on-surface, #000000);
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-helper,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-helper {
  color: var(--ml-on-surface-muted, #666666);
  font-family: var(--ml-font-family);
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-error-text,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectmany--ml-multi-select-dropdown-brutal span.ml-text-muted,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] span.ml-text-muted {
  color: var(--ml-on-surface-muted, #666666);
  font-family: var(--ml-font-family);
}
groupselectmany--ml-multi-select-dropdown-brutal div.ml-text-muted,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] div.ml-text-muted {
  color: var(--ml-on-surface-muted, #666666);
  font-weight: 700;
  font-family: var(--ml-font-family);
}
groupselectmany--ml-multi-select-dropdown-brutal div.ml-text-muted.font-semibold,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] div.ml-text-muted.font-semibold {
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-disabled,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-tag,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-tag {
  border-radius: 0;
  background: #3b82f6;
  color: #ffffff;
  border: 2px solid #000000;
  font-weight: 700;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-trigger,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-trigger {
  position: relative;
  color: var(--ml-on-surface, #000000);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  background: var(--ml-surface, #ffffff);
  box-shadow: 3px 3px 0 #000000;
  text-align: left;
  transition: none;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-trigger:focus-visible,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-trigger:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-trigger-focus:focus,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-trigger-focus:focus {
  box-shadow: none !important;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-trigger-error,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-trigger-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-trigger.ml-disabled,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-trigger.ml-disabled {
  box-shadow: 2px 2px 0 #999999;
  border-color: #999999;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-view,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-view {
  border-radius: var(--ml-radius-md, 0);
  border: var(--ml-border-width, 3px) solid #000000;
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #000000);
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-panel,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-panel {
  border: var(--ml-border-width, 3px) solid #000000;
  border-radius: var(--ml-radius-lg, 0);
  background: var(--ml-surface, #ffffff);
  box-shadow: 3px 3px 0 #000000;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-panel > div:has(> input[data-search]),
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-panel > div:has(> input[data-search]) {
  border-bottom: var(--ml-border-width, 3px) solid #000000;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-search,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-search {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border: var(--ml-border-width, 3px) solid #000000;
  border-radius: 0;
  outline: none;
  font-family: var(--ml-font-family);
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-search::placeholder,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-search::placeholder {
  color: #999999;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-search:focus,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-search:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: none !important;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-item,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-item {
  border-width: 2px;
  border-style: solid;
  border-color: transparent;
  border-radius: 0;
  color: var(--ml-on-surface, #000000);
  background: transparent;
  font-family: var(--ml-font-family);
  transition: none;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-item-hover:hover,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-item-hover:hover {
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: #000000;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-item-selected,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-item-selected {
  border: 2px solid #000000;
  border-radius: 0;
  background: #3b82f6;
  color: #ffffff;
  font-weight: 700;
  transition: none;
}
groupselectmany--ml-multi-select-dropdown-brutal .ml-select-check,
div[data-widget="groupselectmany--ml-multi-select-dropdown-brutal"] .ml-select-check {
  color: #ffffff;
  font-weight: 900;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-brutal"].
        this.portalWidgetName = 'groupselectmany--ml-multi-select-dropdown-brutal';
    }
};
MultiSelectDropdownBrutal = __decorate([
    customElement('groupselectmany--ml-multi-select-dropdown-brutal')
], MultiSelectDropdownBrutal);
export { MultiSelectDropdownBrutal };
