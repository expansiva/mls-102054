var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI SELECT DROPDOWN — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupSelectMany
// Herda MultiSelectDropdownMolecule (mls-102040): selecao multipla, parsing de
// slots (Group/Item), busca, min/max, foco/teclado, outside-click e estado
// reativo (isOpen/searchQuery). Sobrescreve apenas render() + helpers de template
// com classes brutal. i18n proprio.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MultiSelectDropdownMolecule } from '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select options',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    empty: 'No options available',
    selectedCount: 'selected',
    requiredError: 'Select at least one option',
    minSelectionError: 'Select at least {min} options',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione opcoes',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        empty: 'Nenhuma opcao disponivel',
        selectedCount: 'selecionado(s)',
        requiredError: 'Selecione pelo menos uma opcao',
        minSelectionError: 'Selecione pelo menos {min} opcoes',
    },
};
let MlMultiSelectDropdownBrutal = class MlMultiSelectDropdownBrutal extends MultiSelectDropdownMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-select-dropdown-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-label {
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #000;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-placeholder {
  color: #666;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-count {
  color: #000;
  font-weight: 700;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-tag {
  border-radius: 0;
  background: #3b82f6;
  color: #fff;
  border: 2px solid #000;
  font-weight: 700;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-trigger {
  position: relative;
  color: #000;
  border: 3px solid #000;
  border-radius: 0;
  background: #fff;
  box-shadow: 3px 3px 0 #000;
  cursor: pointer;
  text-align: left;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-trigger:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-trigger.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-trigger.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: 2px 2px 0 #999;
  border-color: #999;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-helper {
  color: #666;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-view-box {
  border-radius: 0;
  border: 3px solid #000;
  background: #f5f5f5;
  color: #000;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-panel,
.brutal-msd-portal .brutal-panel {
  border: 3px solid #000;
  border-radius: 0;
  background: #fff;
  box-shadow: 3px 3px 0 #000;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-search-wrap,
.brutal-msd-portal .brutal-search-wrap {
  border-bottom: 3px solid #000;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-search,
.brutal-msd-portal .brutal-search {
  background: #fff;
  color: #000;
  border: 3px solid #000;
  border-radius: 0;
  outline: none;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-search::placeholder,
.brutal-msd-portal .brutal-search::placeholder {
  color: #999;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-search:focus,
.brutal-msd-portal .brutal-search:focus {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-item,
.brutal-msd-portal .brutal-item {
  border-radius: 0;
  border: 2px solid transparent;
  color: #000;
  background: transparent;
  cursor: pointer;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-item:not(.is-disabled):not(.is-selected):hover,
.brutal-msd-portal .brutal-item:not(.is-disabled):not(.is-selected):hover {
  background: #f0f0f0;
  border-color: #000;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-item.is-selected,
.brutal-msd-portal .brutal-item.is-selected {
  background: #3b82f6;
  border-color: #000;
  color: #fff;
  font-weight: 700;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-item.is-disabled,
.brutal-msd-portal .brutal-item.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-check,
.brutal-msd-portal .brutal-check {
  color: #fff;
  font-weight: 900;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-group-label,
.brutal-msd-portal .brutal-group-label {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectmany--ml-multi-select-dropdown-brutal .brutal-empty,
.brutal-msd-portal .brutal-empty {
  color: #666;
  font-weight: 700;
}
`);
        this.portalClassName = 'brutal-msd-portal';
        this.bMsg = messages.en;
        this.bUid = `brutal-msd-${Math.random().toString(36).slice(2)}`;
        this.bLabelId = `${this.bUid}-label`;
        this.bHelperId = `${this.bUid}-helper`;
        this.bErrorId = `${this.bUid}-error`;
        this.bPanelId = `${this.bUid}-panel`;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalTriggerClasses(hasError) {
        return [
            'brutal-trigger',
            'w-full px-3 py-2 text-sm flex flex-wrap items-center gap-2',
            hasError ? 'is-error' : '',
            this.disabled || this.readonly || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalItemClasses(isSelected, isDisabled) {
        return [
            'brutal-item',
            'flex w-full items-center justify-between px-3 py-2 text-sm',
            isSelected ? 'is-selected' : '',
            isDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.bLabelId}" class="brutal-label mb-1 block text-sm">${unsafeHTML(this.getSlotContent('Label'))}</label>
    `;
    }
    brutalHelperOrError(errorMessage) {
        if (!this.isEditing)
            return html ``;
        if (errorMessage) {
            return html `<p id="${this.bErrorId}" class="brutal-error-text mt-1 text-xs">${unsafeHTML(errorMessage)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.bHelperId}" class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalSelectedTags(items, selectedValues) {
        const selectedItems = selectedValues
            .map((value) => items.find((item) => item.value === value) || { value, labelHtml: value, labelText: value, disabled: false })
            .filter(Boolean);
        if (selectedItems.length === 0) {
            const placeholder = this.placeholder || this.bMsg.placeholder;
            return html `<span class="brutal-placeholder">${placeholder}</span>`;
        }
        if (selectedItems.length > 3) {
            return html `<span class="brutal-count">${selectedItems.length} ${this.bMsg.selectedCount}</span>`;
        }
        return html `
      <div class="flex flex-wrap gap-1">
        ${selectedItems.map((item) => html `<span class="brutal-tag px-2 py-0.5 text-xs">${unsafeHTML(item.labelHtml)}</span>`)}
      </div>
    `;
    }
    brutalTriggerContent(items, selectedValues) {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        return this.brutalSelectedTags(items, selectedValues);
    }
    brutalOptionButton(item, isSelected, isDisabled) {
        const x = this.x;
        return html `
      <button
        class="${this.brutalItemClasses(isSelected, isDisabled)}"
        role="option"
        aria-selected="${isSelected}"
        aria-disabled="${isDisabled}"
        type="button"
        ?disabled=${isDisabled}
        @mousedown=${(e) => e.preventDefault()}
        @click=${() => x.handleOptionClick(item.value)}
        .data-option=${true}
        .data-option-value=${item.value}
      >
        <span>${unsafeHTML(item.labelHtml)}</span>
        ${isSelected ? html `<span class="brutal-check">&#x2713;</span>` : html ``}
      </button>
    `;
    }
    brutalOptionList(groups, items, selectedValues) {
        const query = this.x.searchQuery.trim().toLowerCase();
        const filterItem = (item) => !query || item.labelText.toLowerCase().includes(query);
        const filteredGroups = groups
            .map((group) => ({ ...group, items: group.items.filter(filterItem) }))
            .filter((group) => group.items.length > 0);
        const filteredItems = items.filter(filterItem);
        if (!filteredGroups.length && !filteredItems.length) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.bMsg.empty;
            return html `<div class="brutal-empty px-3 py-4 text-sm">${unsafeHTML(emptyContent)}</div>`;
        }
        const maxReached = this.maxSelection > 0 && selectedValues.length >= this.maxSelection;
        return html `
      <div class="max-h-60 overflow-auto p-2" role="listbox" aria-multiselectable="true" id="${this.bPanelId}">
        ${filteredGroups.map((group) => html `
            <div class="mb-2">
              ${group.label ? html `<div class="brutal-group-label px-2 py-1 text-xs">${group.label}</div>` : html ``}
              ${group.items.map((item) => {
            const isSelected = selectedValues.includes(item.value);
            const isDisabled = item.disabled || (!isSelected && maxReached);
            return this.brutalOptionButton(item, isSelected, isDisabled);
        })}
            </div>
          `)}
        ${filteredItems.map((item) => {
            const isSelected = selectedValues.includes(item.value);
            const isDisabled = item.disabled || (!isSelected && maxReached);
            return this.brutalOptionButton(item, isSelected, isDisabled);
        })}
      </div>
    `;
    }
    getPortalTemplate() {
        const x = this.x;
        const groups = x.getGroupedItems();
        const items = x.getUngroupedItems();
        const selectedValues = x.getSelectedValues();
        return html `
      <div class="brutal-panel w-full" @keydown=${(e) => x.handlePanelKeydown(e)}>
        ${this.searchable
            ? html `
              <div class="brutal-search-wrap p-2">
                <input
                  class="brutal-search w-full px-3 py-2 text-sm"
                  type="text"
                  placeholder="${this.bMsg.searchPlaceholder}"
                  .value=${x.searchQuery}
                  @input=${(e) => x.handleSearchInput(e)}
                  data-search
                />
              </div>
            `
            : html ``}
        ${this.brutalOptionList(groups, items, selectedValues)}
      </div>
    `;
    }
    brutalViewMode() {
        const items = this.x.getAllItems();
        const selectedValues = this.x.getSelectedValues();
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        <div class="brutal-view-box px-3 py-2 text-sm">${this.brutalSelectedTags(items, selectedValues)}</div>
        ${this.name ? html `<input type="hidden" name="${this.name}" value="${this.value}" />` : html ``}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        const x = this.x;
        if (!this.isEditing) {
            return this.brutalViewMode();
        }
        const groups = x.getGroupedItems();
        const items = x.getUngroupedItems();
        const allItems = [...groups.flatMap((g) => g.items), ...items];
        const selectedValues = x.getSelectedValues();
        const errorMessage = x.getComputedError(selectedValues.length);
        const hasError = Boolean(errorMessage);
        const describedBy = hasError ? this.bErrorId : this.hasSlot('Helper') ? this.bHelperId : undefined;
        const labelAttr = this.hasSlot('Label') ? this.bLabelId : undefined;
        const isPanelOpen = x.isOpen && !this.loading;
        return html `
      <div
        class="w-full"
        @focusin=${(e) => x.handleFocusIn()}
        @focusout=${(e) => x.handleFocusOut(e)}
        @keydown=${(e) => x.handlePanelKeydown(e)}
      >
        ${this.brutalLabel()}
        <div class="relative">
          <button
            class="${this.brutalTriggerClasses(hasError)}"
            type="button"
            role="combobox"
            aria-expanded="${isPanelOpen}"
            aria-haspopup="listbox"
            aria-required="${this.required}"
            aria-invalid="${hasError}"
            ${labelAttr ? html `aria-labelledby="${labelAttr}"` : html `aria-label="${this.placeholder || this.bMsg.placeholder}"`}
            ${describedBy ? html `aria-describedby="${describedBy}"` : html ``}
            @keydown=${(e) => x.handleTriggerKeydown(e)}
            @click=${() => x.handleTriggerClick()}
            .data-trigger=${true}
          >
            ${this.loading
            ? html `<span class="brutal-placeholder">${this.bMsg.loading}</span>`
            : this.brutalTriggerContent(allItems, selectedValues)}
          </button>
        </div>
        ${this.brutalHelperOrError(errorMessage)}
        ${this.name ? html `<input type="hidden" name="${this.name}" value="${this.value}" />` : html ``}
      </div>
    `;
    }
};
MlMultiSelectDropdownBrutal = __decorate([
    customElement('groupselectmany--ml-multi-select-dropdown-brutal')
], MlMultiSelectDropdownBrutal);
export { MlMultiSelectDropdownBrutal };
