var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectmany/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
// Registra a(s) molécula(s) do grupo (side-effect import)
import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select';
let GroupSelectManyIndex = class GroupSelectManyIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        this.skills = 'ts,js';
        this.langs = 'lit,ts';
    }
    render() {
        return html `
      <div
        style="min-height:100vh; padding:2rem; background:linear-gradient(135deg,#0b1220 0%,#312e81 45%,#7e22ce 100%); font-family:'Inter',system-ui,sans-serif;"
      >
        <header style="text-align:center; margin-bottom:3rem;">
          <span
            style="display:inline-block; padding:0.25rem 0.75rem; background:rgba(255,255,255,0.15); color:#fff; border:1px solid rgba(255,255,255,0.25); border-radius:9999px; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:1rem;"
            >groupSelectMany · glassmorphism</span
          >
          <h1 style="font-size:2.25rem; font-weight:700; color:#fff; margin-bottom:0.5rem;">Select Many</h1>
        </header>
        <section style="max-width:28rem; margin:0 auto; display:flex; flex-direction:column; gap:2rem;">
          <groupselectmany--ml-multi-select-dropdown
            name="skills"
            searchable="true"
            .value=${this.skills}
            .isEditing=${true}
            @change=${(e) => {
            this.skills = e.detail.value;
        }}
          >
            <Label>Tecnologias</Label>
            <Helper>Selecionadas: ${this.skills || '—'}</Helper>
            <Item value="ts">TypeScript</Item>
            <Item value="js">JavaScript</Item>
            <Item value="py">Python</Item>
            <Item value="go">Go</Item>
          </groupselectmany--ml-multi-select-dropdown>

          <groupselectmany--ml-popover-multi-select
            searchable
            max-selection="3"
            .value=${this.langs}
            .isEditing=${true}
            @change=${(e) => {
            this.langs = e.detail.value;
        }}
          >
            <Label>Habilidades (máx. 3)</Label>
            <Helper>Selecionadas: ${this.langs || '—'}</Helper>
            <Item value="lit">Lit</Item>
            <Item value="ts">TypeScript</Item>
            <Item value="less">LESS</Item>
            <Item value="a11y">Acessibilidade</Item>
            <Item value="design">Design Systems</Item>
          </groupselectmany--ml-popover-multi-select>
        </section>
      </div>
    `;
    }
};
__decorate([
    state()
], GroupSelectManyIndex.prototype, "skills", void 0);
__decorate([
    state()
], GroupSelectManyIndex.prototype, "langs", void 0);
GroupSelectManyIndex = __decorate([
    customElement('molecules--groupselectmany--index-102054')
], GroupSelectManyIndex);
export { GroupSelectManyIndex };
