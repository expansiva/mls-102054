var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectmany/ml-popover-multi-select-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML POPOVER MULTI SELECT — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupSelectMany
// Herda MlPopoverMultiSelectMolecule (mls-102040): selecao multipla, parsing de
// slots, busca, navegacao por teclado (activeIndex), min/max, outside-click e
// estado reativo (isOpen/searchQuery/activeIndex). Sobrescreve apenas render() +
// helpers de template com classes brutal. i18n proprio.
// Mantem data-ml-item + data-index para o focusActiveItem do pai.
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlPopoverMultiSelectMolecule } from '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select options',
    noResults: 'No results found',
    loading: 'Loading...',
    search: 'Search',
    selected: 'selected',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione opcoes',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        search: 'Buscar',
        selected: 'selecionado',
    },
};
let MlPopoverMultiSelectBrutal = class MlPopoverMultiSelectBrutal extends MlPopoverMultiSelectMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-popover-multi-select-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-helper {
  color: #666;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-muted {
  color: #666;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-placeholder {
  color: #999;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-chevron {
  color: #000;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-empty {
  color: #666;
  font-weight: 700;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-group {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-check {
  color: #fff;
  font-weight: 900;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-trigger {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-trigger:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-trigger.is-open {
  box-shadow: 1px 1px 0 #000;
  transform: translate(2px, 2px);
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-trigger.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-trigger.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: 2px 2px 0 #999;
  border-color: #999;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-tag {
  background: #3b82f6;
  color: #fff;
  border: 2px solid #000;
  border-radius: 0;
  font-weight: 700;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-view {
  background: #f5f5f5;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-panel,
.brutal-pms-portal .brutal-pms-panel {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-search-row,
.brutal-pms-portal .brutal-pms-search-row {
  border-bottom: 3px solid #000;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-search,
.brutal-pms-portal .brutal-pms-search {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  outline: none;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-search::placeholder,
.brutal-pms-portal .brutal-pms-search::placeholder {
  color: #999;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-search:focus,
.brutal-pms-portal .brutal-pms-search:focus {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-item,
.brutal-pms-portal .brutal-pms-item {
  background: transparent;
  border: 2px solid transparent;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-item:hover:not(.is-disabled):not(.is-selected),
.brutal-pms-portal .brutal-pms-item:hover:not(.is-disabled):not(.is-selected) {
  background: #f0f0f0;
  border-color: #000;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-item:focus-visible,
.brutal-pms-portal .brutal-pms-item:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-item.is-selected,
.brutal-pms-portal .brutal-pms-item.is-selected {
  background: #3b82f6;
  color: #fff;
  border-color: #000;
  font-weight: 700;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-item.is-disabled,
.brutal-pms-portal .brutal-pms-item.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-empty,
.brutal-pms-portal .brutal-pms-empty {
  color: #666;
  font-weight: 700;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-group,
.brutal-pms-portal .brutal-pms-group {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectmany--ml-popover-multi-select-brutal .brutal-pms-check,
.brutal-pms-portal .brutal-pms-check {
  color: #fff;
  font-weight: 900;
}
`);
        this.portalClassName = 'brutal-pms-portal';
        this.bMsg = messages.en;
        this.bUid = `brutal-pms-${Math.random().toString(36).slice(2)}`;
        this.bLabelId = `${this.bUid}-label`;
        this.bErrorId = `${this.bUid}-error`;
        this.bPanelId = `${this.bUid}-panel`;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalTriggerClasses(hasError) {
        return [
            'brutal-pms-trigger w-full min-h-[40px] px-3 py-2 text-sm flex items-center justify-between gap-2',
            hasError ? 'is-error' : '',
            this.disabled || this.readonly || this.loading ? 'is-disabled' : '',
            this.x.isOpen ? 'is-open' : '',
        ].filter(Boolean).join(' ');
    }
    brutalItemClasses(isSelected, isDisabled) {
        return [
            'brutal-pms-item w-full px-3 py-2 text-sm flex items-center justify-between',
            isSelected ? 'is-selected' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return nothing;
        return html `<label id="${this.bLabelId}" class="brutal-pms-label text-sm">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    brutalHelper(hasError) {
        if (hasError || !this.hasSlot('Helper'))
            return nothing;
        return html `<p class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
    }
    brutalError(hasError) {
        if (!hasError)
            return nothing;
        const message = this.error || '';
        return html `<p id="${this.bErrorId}" class="brutal-error-text mt-1 text-xs">${unsafeHTML(message)}</p>`;
    }
    brutalSelectedTag(label, isHtml) {
        return html `
      <span class="brutal-pms-tag px-2 py-0.5 text-xs">
        ${isHtml ? unsafeHTML(label) : label}
      </span>
    `;
    }
    brutalTriggerContent(selectedLabels, selectedCount) {
        if (this.loading) {
            return html `<span class="brutal-pms-muted">${this.bMsg.loading}</span>`;
        }
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        if (selectedCount === 0) {
            const placeholder = this.placeholder || this.bMsg.placeholder;
            return html `<span class="brutal-pms-placeholder">${placeholder}</span>`;
        }
        const visible = selectedLabels.slice(0, 2);
        const extraCount = selectedCount - visible.length;
        return html `
      <div class="flex flex-wrap items-center gap-1">
        ${visible.map((item) => this.brutalSelectedTag(item.label, item.isHtml))}
        ${extraCount > 0
            ? html `<span class="brutal-pms-muted text-xs">+${extraCount}</span>`
            : nothing}
      </div>
    `;
    }
    brutalEmpty() {
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.bMsg.noResults;
        return html `<div class="brutal-pms-empty px-3 py-2 text-sm">${unsafeHTML(content)}</div>`;
    }
    brutalOptionButton(item, isSelected, isDisabled, itemIndex) {
        const x = this.x;
        return html `
      <button
        type="button"
        role="option"
        aria-selected="${isSelected}"
        aria-disabled="${isDisabled}"
        class="${this.brutalItemClasses(isSelected, isDisabled)}"
        ?disabled=${isDisabled}
        @mouseenter=${() => { x.activeIndex = itemIndex; }}
        @click=${() => x.handleItemClick(item, isDisabled)}
        @keydown=${(e) => x.handlePanelKeyDown(e)}
        data-ml-item
        data-index="${itemIndex}"
      >
        <span>${unsafeHTML(item.labelHtml || item.labelText)}</span>
        ${isSelected
            ? html `<span class="brutal-pms-check text-xs">&#x2713;</span>`
            : nothing}
      </button>
    `;
    }
    brutalGroup(group, selectedSet, selectionFull, baseIndex) {
        const x = this.x;
        let runningIndex = baseIndex;
        return html `
      <div class="mb-2">
        ${group.label
            ? html `<div class="brutal-pms-group px-3 py-1 text-xs">${group.label}</div>`
            : nothing}
        <div class="flex flex-col gap-1">
          ${group.items.map((item) => {
            const isSelected = selectedSet.has(item.value);
            const isDisabled = x.getItemDisabled(item, selectionFull, selectedSet);
            const itemIndex = runningIndex++;
            return this.brutalOptionButton(item, isSelected, isDisabled, itemIndex);
        })}
        </div>
      </div>
    `;
    }
    brutalItems(groups, items, selectedSet, selectionFull) {
        const x = this.x;
        let indexCounter = 0;
        return html `
      ${groups.map((group) => {
            const template = this.brutalGroup(group, selectedSet, selectionFull, indexCounter);
            indexCounter += group.items.length;
            return template;
        })}
      ${items.length
            ? html `<div class="flex flex-col gap-1">
            ${items.map((item) => {
                const isSelected = selectedSet.has(item.value);
                const isDisabled = x.getItemDisabled(item, selectionFull, selectedSet);
                const itemIndex = indexCounter++;
                return this.brutalOptionButton(item, isSelected, isDisabled, itemIndex);
            })}
          </div>`
            : nothing}
    `;
    }
    getPortalTemplate() {
        const x = this.x;
        const slotData = x.collectSlotData();
        const filtered = x.filterData(slotData, x.searchQuery);
        const { selectedSet, selectionFull } = x.getSelectionState();
        const showEmpty = filtered.groups.length === 0 && filtered.items.length === 0;
        return html `
      <div
        class="brutal-pms-panel w-full"
        role="listbox"
        aria-multiselectable="true"
        @keydown=${(e) => x.handlePanelKeyDown(e)}
      >
        ${this.searchable
            ? html `
            <div class="brutal-pms-search-row p-2">
              <input
                class="brutal-pms-search w-full px-3 py-2 text-sm"
                .placeholder=${this.bMsg.search}
                value=${x.searchQuery}
                @input=${(e) => x.handleSearchInput(e)}
                data-ml-search
              />
            </div>`
            : nothing}
        <div class="max-h-64 overflow-auto p-2">
          ${showEmpty ? this.brutalEmpty() : this.brutalItems(filtered.groups, filtered.items, selectedSet, selectionFull)}
        </div>
      </div>
    `;
    }
    brutalViewMode(selectedLabels) {
        const hasSelection = selectedLabels.length > 0;
        const placeholder = this.placeholder || this.bMsg.placeholder;
        return html `
      <div class="flex flex-col gap-1">
        ${this.brutalLabel()}
        <div class="brutal-pms-view min-h-[40px] px-3 py-2 text-sm">
          ${hasSelection
            ? html `<div class="flex flex-wrap gap-1">
                ${selectedLabels.map((item) => this.brutalSelectedTag(item.label, item.isHtml))}
              </div>`
            : html `<span class="brutal-pms-placeholder">${placeholder}</span>`}
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        const x = this.x;
        const slotData = x.collectSlotData();
        const filtered = x.filterData(slotData, x.searchQuery);
        const { selectedValues, selectedSet, selectedCount, selectionFull } = x.getSelectionState();
        const hasError = this.isEditing ? Boolean(x.getValidationError(selectedCount)) : false;
        const labelMap = x.getSelectedLabelMap(slotData.allItems);
        const selectedLabels = selectedValues.map((val) => {
            const label = labelMap.get(val);
            if (label) {
                return { label, isHtml: true };
            }
            return { label: val, isHtml: false };
        });
        if (!this.isEditing) {
            return this.brutalViewMode(selectedLabels);
        }
        const triggerClasses = this.brutalTriggerClasses(hasError);
        return html `
      <div class="w-full" role="group">
        <div class="flex items-start gap-3">
          ${this.brutalLabel()}
          <div class="relative flex-1">
            <button
              id="${this.name || this.bPanelId}"
              type="button"
              class="${triggerClasses}"
              role="combobox"
              aria-expanded="${x.isOpen}"
              aria-haspopup="listbox"
              aria-controls="${this.bPanelId}"
              aria-labelledby="${this.hasSlot('Label') ? this.bLabelId : ''}"
              aria-invalid="${hasError}"
              aria-required="${this.required}"
              ?disabled=${this.disabled || this.readonly || this.loading}
              @focus=${() => x.handleTriggerFocus()}
              @blur=${() => x.handleTriggerBlur()}
              @click=${() => x.handleTriggerClick()}
              @keydown=${(e) => {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                x.openPanel();
            }
        }}
            >
              <div class="flex-1 flex items-center gap-2">
                ${this.brutalTriggerContent(selectedLabels, selectedCount)}
              </div>
              <span class="brutal-pms-chevron">
                <svg viewBox="0 0 20 20" class="w-4 h-4" aria-hidden="true">
                  ${svg `<path d="M5 7l5 5 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square" stroke-linejoin="miter"></path>`}
                </svg>
              </span>
            </button>
          </div>
        </div>
        ${this.brutalError(hasError)}
        ${this.brutalHelper(hasError)}
      </div>
    `;
    }
};
MlPopoverMultiSelectBrutal = __decorate([
    customElement('groupselectmany--ml-popover-multi-select-brutal')
], MlPopoverMultiSelectBrutal);
export { MlPopoverMultiSelectBrutal };
