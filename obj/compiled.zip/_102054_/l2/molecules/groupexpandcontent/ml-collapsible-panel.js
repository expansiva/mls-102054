var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COLLAPSIBLE PANEL MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupExpandContent
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlCollapsiblePanelMolecule = class MlCollapsiblePanelMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-collapsible-panel {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupexpandcontent--ml-collapsible-panel .glass-clp-label {
  color: rgba(255, 255, 255, 0.85);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-section {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  overflow: hidden;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  transition: border-color 0.2s ease;
}
groupexpandcontent--ml-collapsible-panel .glass-clp-section.is-open {
  border-color: rgba(199, 210, 254, 0.6);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-header {
  background: transparent;
  border: 1px solid transparent;
  cursor: pointer;
  transition: background 0.15s ease;
}
groupexpandcontent--ml-collapsible-panel .glass-clp-header:hover:not(.is-disabled):not(.is-open) {
  background: rgba(255, 255, 255, 0.08);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-header:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.4);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-header.is-open {
  background: rgba(199, 210, 254, 0.14);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-header.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupexpandcontent--ml-collapsible-panel .glass-clp-icon {
  color: rgba(255, 255, 255, 0.6);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-title {
  color: #fff;
}
groupexpandcontent--ml-collapsible-panel .glass-clp-subtitle {
  color: rgba(255, 255, 255, 0.55);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-chevron {
  color: rgba(255, 255, 255, 0.6);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-body {
  color: rgba(255, 255, 255, 0.8);
}
groupexpandcontent--ml-collapsible-panel .glass-clp-skel {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 12px;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.openSections = new Set();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.getSlots('Section').forEach((el, index) => {
            if (el.hasAttribute('expanded')) {
                this.openSections.add(index);
            }
        });
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleHeaderClick(index) {
        if (this.loading || this.disabled)
            return;
        const sections = this.getSlots('Section');
        const sectionEl = sections[index];
        if (!sectionEl || sectionEl.hasAttribute('disabled'))
            return;
        const isOpen = this.openSections.has(index);
        if (this.multiple) {
            if (isOpen) {
                this.openSections.delete(index);
            }
            else {
                this.openSections.add(index);
            }
        }
        else {
            this.openSections = new Set(isOpen ? [] : [index]);
        }
        const title = sectionEl.getAttribute('title') || '';
        const expanded = this.openSections.has(index);
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { index, title, expanded },
        }));
        this.requestUpdate();
    }
    handleHeaderKeydown(event, index) {
        if (this.loading || this.disabled)
            return;
        const key = event.key;
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            this.handleHeaderClick(index);
            return;
        }
        if (key === 'ArrowDown' || key === 'ArrowUp') {
            event.preventDefault();
            this.focusAdjacentHeader(index, key === 'ArrowDown' ? 1 : -1);
        }
    }
    focusAdjacentHeader(currentIndex, delta) {
        const headers = Array.from(this.querySelectorAll('[data-header="true"]'));
        if (headers.length === 0)
            return;
        const nextIndex = (currentIndex + delta + headers.length) % headers.length;
        headers[nextIndex]?.focus();
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        ${this.loading ? this.renderLoading() : this.renderSections()}
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="glass-clp-label mb-2 text-sm font-medium">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderLoading() {
        const items = [0, 1, 2];
        return html `
      <div class="space-y-2" aria-busy="true" aria-live="polite">
        ${items.map(() => html `<div class="glass-clp-skel h-12 w-full animate-pulse"></div>`)}
        <div class="sr-only">${this.msg.loading}</div>
      </div>
    `;
    }
    renderSections() {
        const sections = this.getSlots('Section');
        return html `
      <div class="space-y-2">
        ${sections.map((el, index) => {
            const title = el.getAttribute('title') || '';
            const subtitle = el.getAttribute('subtitle') || '';
            const icon = el.getAttribute('icon') || '';
            const isDisabled = this.disabled || el.hasAttribute('disabled');
            const isOpen = this.openSections.has(index);
            const headerId = `${this.localName}-header-${index}`;
            const contentId = `${this.localName}-content-${index}`;
            return html `
            <div class="glass-clp-section w-full ${isOpen ? 'is-open' : ''}">
              <div
                id=${headerId}
                role="button"
                tabindex=${isDisabled ? -1 : 0}
                aria-expanded=${isOpen ? 'true' : 'false'}
                aria-disabled=${isDisabled ? 'true' : 'false'}
                data-header="true"
                class=${this.getHeaderClasses(isOpen, isDisabled)}
                @click=${() => this.handleHeaderClick(index)}
                @keydown=${(e) => this.handleHeaderKeydown(e, index)}
              >
                <div class="flex items-center gap-3">
                  ${icon ? html `<span class="glass-clp-icon">${unsafeHTML(icon)}</span>` : html ``}
                  <div class="flex flex-col">
                    <span class="glass-clp-title text-sm font-medium">${title}</span>
                    ${subtitle ? html `<span class="glass-clp-subtitle text-xs">${subtitle}</span>` : html ``}
                  </div>
                </div>
                <span class=${this.getChevronClasses(isOpen)} aria-hidden="true">
                  <svg viewBox="0 0 20 20" fill="none" class="h-4 w-4">
                    ${svg `<path d="M6 8l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />`}
                  </svg>
                </span>
              </div>
              <div id=${contentId} role="region" aria-labelledby=${headerId} class=${this.getContentClasses(isOpen)}>
                <div class="glass-clp-body px-4 pb-4 pt-0 text-sm">${unsafeHTML(this.getSectionContent(el))}</div>
              </div>
            </div>
          `;
        })}
      </div>
    `;
    }
    getSectionContent(el) {
        return el.innerHTML || '';
    }
    getHeaderClasses(isOpen, isDisabled) {
        return [
            'glass-clp-header flex w-full items-center justify-between gap-3 px-4 py-3 text-left',
            isOpen ? 'is-open' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getChevronClasses(isOpen) {
        return ['glass-clp-chevron transition-transform', isOpen ? 'rotate-180' : 'rotate-0'].join(' ');
    }
    getContentClasses(isOpen) {
        return [
            'overflow-hidden transition-all duration-300 ease-in-out',
            isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0',
        ].join(' ');
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlCollapsiblePanelMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCollapsiblePanelMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCollapsiblePanelMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlCollapsiblePanelMolecule.prototype, "openSections", void 0);
MlCollapsiblePanelMolecule = __decorate([
    customElement('groupexpandcontent--ml-collapsible-panel')
], MlCollapsiblePanelMolecule);
export { MlCollapsiblePanelMolecule };
