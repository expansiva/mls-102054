var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// REVEAL OVERLAY — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de RevealOverlayMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { RevealOverlayMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay.js';
let RevealOverlayBrutal = class RevealOverlayBrutal extends RevealOverlayMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-reveal-overlay-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #eeeeee;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #666666;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-skeleton {
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  background: var(--ml-surface);
  box-shadow: var(--ml-shadow-1);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-trigger {
  position: relative;
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  background: var(--ml-surface);
  color: var(--ml-on-surface);
  box-shadow: var(--ml-shadow-1);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
  transition: none;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-trigger:not(.ml-disabled):hover {
  background: var(--ml-surface-dim);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-trigger.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  border-color: #999999;
  cursor: not-allowed;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-trigger:focus-visible {
  outline: var(--ml-border-width) solid var(--ml-outline-variant);
  outline-offset: 2px;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-trigger .ml-text-muted {
  color: var(--ml-primary);
  font-weight: var(--ml-font-weight-medium);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-panel:has(> .ml-reveal-overlay) {
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  background: var(--ml-surface);
  overflow: hidden;
  box-shadow: var(--ml-shadow-1);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-panel:has(> .ml-reveal-overlay).ml-disabled {
  opacity: var(--ml-disabled-opacity);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-panel:has(> .ml-reveal-overlay) > .ml-reveal-panel {
  color: var(--ml-on-surface);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-panel.ml-text-muted {
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  background: var(--ml-surface);
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-overlay {
  border-radius: var(--ml-radius-sm);
  background: #000000;
  transition: none;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-overlay.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  pointer-events: none;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-close {
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-on-primary);
  background: var(--ml-primary);
  color: var(--ml-on-primary);
  cursor: pointer;
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
  transition: none;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-close:not(.ml-disabled):hover {
  background: #2563eb;
}
groupexpandcontent--ml-reveal-overlay-brutal .ml-reveal-close.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
}
`);
    }
};
RevealOverlayBrutal = __decorate([
    customElement('groupexpandcontent--ml-reveal-overlay-brutal')
], RevealOverlayBrutal);
export { RevealOverlayBrutal };
