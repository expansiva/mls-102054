var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// REVEAL OVERLAY — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupExpandContent
// Herda toda a lógica de RevealOverlayMolecule (mls-102040): estado de seções
// abertas (openSections), toggle, navegação por teclado e inicialização no
// firstUpdated. Sobrescreve apenas render() e os helpers de classe (brutal).
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { RevealOverlayMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay.js';
/// **collab_i18n_start**
const message_en = {
    reveal: 'Reveal',
    hide: 'Hide',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
let MlRevealOverlayBrutal = class MlRevealOverlayBrutal extends RevealOverlayMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-reveal-overlay-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-loading {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #666;
  box-shadow: 3px 3px 0 #000;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-header {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-header:not(.is-disabled):hover {
  background: #eee;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-header.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-header:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-action {
  color: #3b82f6;
  font-weight: 700;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-warning {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #666;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-container {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  overflow: hidden;
  box-shadow: 3px 3px 0 #000;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-container.is-disabled {
  opacity: 0.4;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-content {
  color: #000;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-overlay {
  border-radius: 0;
  background: #000;
  opacity: 1;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-overlay.is-open {
  opacity: 0;
  pointer-events: none;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-overlay.is-disabled {
  opacity: 0.4;
  pointer-events: none;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-btn {
  border-radius: 0;
  border: 3px solid #fff;
  background: #3b82f6;
  color: #fff;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-btn:not(.is-disabled):hover {
  background: #2563eb;
}
groupexpandcontent--ml-reveal-overlay-brutal .brutal-reveal-btn.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalHeaderClasses(sectionDisabled) {
        return [
            'brutal-reveal-header',
            'w-full flex items-center justify-between px-4 py-3 text-sm font-bold',
            this.disabled || sectionDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalContainerClasses(sectionDisabled) {
        return ['brutal-reveal-container', 'relative mt-2', this.disabled || sectionDisabled ? 'is-disabled' : '']
            .filter(Boolean)
            .join(' ');
    }
    brutalOverlayClasses(expanded, sectionDisabled) {
        return [
            'brutal-reveal-overlay',
            'absolute inset-0 flex items-center justify-center',
            expanded ? 'is-open' : '',
            this.disabled || sectionDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalActionButtonClasses(sectionDisabled) {
        return ['brutal-reveal-btn', 'px-4 py-2 text-sm font-bold', this.disabled || sectionDisabled ? 'is-disabled' : '']
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalRenderLoading() {
        return html `<div class="brutal-reveal-loading p-4 text-sm">${this.gMsg.loading}</div>`;
    }
    brutalRenderSectionContent(content) {
        return html `<div class="brutal-reveal-content relative p-4 text-sm">${unsafeHTML(content)}</div>`;
    }
    // ===========================================================================
    // RENDER (override) — lógica herdada via this.x
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        if (this.loading) {
            return this.brutalRenderLoading();
        }
        const warning = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const sections = this.getSlots('Section').map((el, index) => ({
            index,
            title: el.getAttribute('title') || '',
            content: el.innerHTML || '',
            sectionDisabled: el.hasAttribute('disabled'),
            expanded: x.openSections.has(index),
        }));
        return html `
      <div class="space-y-4">
        ${sections.map((section) => {
            const headerId = `brutal-reveal-header-${section.index}`;
            const regionId = `brutal-reveal-region-${section.index}`;
            const actionLabel = section.expanded
                ? `${this.gMsg.hide} ${section.title}`
                : `${this.gMsg.reveal} ${section.title}`;
            return html `
            <div>
              <button
                id=${headerId}
                class=${this.brutalHeaderClasses(section.sectionDisabled)}
                role="button"
                aria-expanded=${section.expanded ? 'true' : 'false'}
                aria-controls=${regionId}
                aria-disabled=${this.disabled || section.sectionDisabled ? 'true' : 'false'}
                data-header="true"
                data-index=${section.index}
                tabindex=${this.disabled || section.sectionDisabled ? '-1' : '0'}
                @click=${() => x.handleToggle(section.index, section.title, section.sectionDisabled)}
                @keydown=${(e) => x.handleHeaderKeydown(e, section.index, section.title, section.sectionDisabled)}
              >
                <span>${section.title}</span>
                <span class="brutal-reveal-action">${actionLabel}</span>
              </button>
              ${warning
                ? html `<div class="brutal-reveal-warning mt-2 px-4 py-3 text-sm">${unsafeHTML(warning)}</div>`
                : html ``}
              <div id=${regionId} class=${this.brutalContainerClasses(section.sectionDisabled)} role="region" aria-labelledby=${headerId}>
                ${this.brutalRenderSectionContent(section.content)}
                <div class=${this.brutalOverlayClasses(section.expanded, section.sectionDisabled)}>
                  <button
                    class=${this.brutalActionButtonClasses(section.sectionDisabled)}
                    @click=${() => x.handleToggle(section.index, section.title, section.sectionDisabled)}
                    ?disabled=${this.disabled || section.sectionDisabled}
                  >
                    ${actionLabel}
                  </button>
                </div>
              </div>
            </div>
          `;
        })}
      </div>
    `;
    }
};
MlRevealOverlayBrutal = __decorate([
    customElement('groupexpandcontent--ml-reveal-overlay-brutal')
], MlRevealOverlayBrutal);
export { MlRevealOverlayBrutal };
