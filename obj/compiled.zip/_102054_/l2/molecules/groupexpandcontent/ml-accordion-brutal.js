var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ACCORDION — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlAccordionMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlAccordionMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-accordion.js';
let MlAccordionBrutal = class MlAccordionBrutal extends MlAccordionMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-accordion-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #eeeeee;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #666666;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family);
}
groupexpandcontent--ml-accordion-brutal .ml-label {
  font-weight: var(--ml-font-weight-medium);
  color: var(--ml-on-surface);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupexpandcontent--ml-accordion-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted);
}
groupexpandcontent--ml-accordion-brutal .ml-skeleton {
  border-radius: var(--ml-radius-sm);
  background: var(--ml-surface-dim);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
}
groupexpandcontent--ml-accordion-brutal div:has(> [data-accordion-header='true']) {
  border-radius: var(--ml-radius-sm);
  overflow: hidden;
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  box-shadow: var(--ml-shadow-1);
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-header {
  position: relative;
  color: var(--ml-on-surface);
  background: var(--ml-surface);
  border: none;
  font-weight: var(--ml-font-weight-medium);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
  transition: none;
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-header:not(.ml-disabled):not(.ml-accordion-header-open):hover {
  background: var(--ml-surface-dim);
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-header:focus-visible {
  outline: var(--ml-border-width) solid var(--ml-outline-variant);
  outline-offset: 2px;
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-header-open {
  background: var(--ml-primary);
  color: var(--ml-on-primary);
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-header.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  border-color: #999999;
  cursor: not-allowed;
  pointer-events: none;
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-chevron {
  color: var(--ml-on-surface);
  transition: none;
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-chevron-open {
  color: var(--ml-on-primary);
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-content {
  background: var(--ml-surface);
  border-top: var(--ml-border-width) solid var(--ml-outline-variant);
  color: var(--ml-on-surface);
  transition: none;
}
groupexpandcontent--ml-accordion-brutal .ml-accordion-content .ml-accordion-content {
  border-top: none;
  background: transparent;
}
`);
    }
};
MlAccordionBrutal = __decorate([
    customElement('groupexpandcontent--ml-accordion-brutal')
], MlAccordionBrutal);
export { MlAccordionBrutal };
