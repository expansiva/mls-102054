var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML ACCORDION — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupExpandContent
// Herda toda a lógica de MlAccordionMolecule (mls-102040): estado openSections,
// toggle, navegação WAI-ARIA por teclado, evento 'toggle', inicialização por
// atributo expanded. Sobrescreve apenas render() e helpers presentacionais
// (brutal*). i18n próprio (gMsg) para não depender do `msg` privado do pai.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlAccordionMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-accordion.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No sections available',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhuma seção disponível',
    },
};
let MlAccordionBrutal = class MlAccordionBrutal extends MlAccordionMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-accordion-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-label {
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
  font-weight: 700;
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-muted {
  color: #666;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-skeleton {
  border-radius: 0;
  background: #eee;
  border: 3px solid #000;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-section {
  border-radius: 0;
  overflow: hidden;
  border: 3px solid #000;
  box-shadow: 3px 3px 0 #000;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-header {
  position: relative;
  color: #000;
  background: #fff;
  border: none;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-header.is-open {
  background: #3b82f6;
  color: #fff;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-header:not(.is-disabled):not(.is-open):hover {
  background: #eee;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-header.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-header:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-chevron {
  color: #000;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-chevron.is-open {
  color: #fff;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-content {
  background: #fff;
  border-top: 3px solid #000;
}
groupexpandcontent--ml-accordion-brutal .brutal-acc-body {
  color: #000;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalHeaderClasses(isOpen, isDisabled) {
        return [
            'brutal-acc-header',
            'w-full flex items-center justify-between gap-3 px-4 py-3 text-sm',
            isOpen ? 'is-open' : '',
            this.disabled || isDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalContentClasses(isOpen) {
        return [
            'brutal-acc-content overflow-hidden',
            isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalChevronClasses(isOpen) {
        return [
            'brutal-acc-chevron flex items-center justify-center',
            isOpen ? 'rotate-180 is-open' : 'rotate-0',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER (override) — lógica herdada via this.x
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        return html `
      <div class="w-full"> ${this.brutalLabel()} ${this.loading ? this.brutalLoading() : this.brutalSections()} </div>
    `;
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="brutal-acc-label">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    brutalLoading() {
        return html `
      <div class="space-y-2">
        <div class="brutal-acc-skeleton h-10 w-full"></div>
        <div class="brutal-acc-skeleton h-10 w-full"></div>
        <div class="brutal-acc-muted text-xs">${this.gMsg.loading}</div>
      </div>
    `;
    }
    brutalSections() {
        const sectionElements = this.getSlots('Section');
        if (sectionElements.length === 0) {
            return html `<div class="brutal-acc-muted text-sm">${this.gMsg.empty}</div>`;
        }
        return html `<div class="space-y-2">${sectionElements.map((el, index) => this.brutalSection(el, index))}</div>`;
    }
    brutalSection(el, index) {
        const title = el.getAttribute('title') || '';
        const isDisabled = el.hasAttribute('disabled');
        const isOpen = this.x.openSections.has(index);
        const headerId = `brutal-accordion-header-${index}`;
        const contentId = `brutal-accordion-content-${index}`;
        const content = this.x.getSectionContent(el);
        return html `
      <div class="brutal-acc-section">
        <div
          id=${headerId}
          data-accordion-header="true"
          role="button"
          aria-expanded=${String(isOpen)}
          aria-controls=${contentId}
          aria-disabled=${String(this.disabled || isDisabled)}
          class=${this.brutalHeaderClasses(isOpen, isDisabled)}
          tabindex=${this.disabled || isDisabled ? -1 : 0}
          @click=${() => this.x.handleToggle(index, title, isDisabled)}
          @keydown=${(e) => this.x.handleHeaderKeydown(e, index, title, isDisabled)}
        >
          <span class="truncate">${title}</span>
          <span class=${this.brutalChevronClasses(isOpen)} aria-hidden="true">
            <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              <path
                fill-rule="evenodd"
                d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.27a.75.75 0 01.02-1.06z"
                clip-rule="evenodd"
              />
            </svg>
          </span>
        </div>
        <div id=${contentId} role="region" aria-labelledby=${headerId} class=${this.brutalContentClasses(isOpen)}>
          <div class="brutal-acc-body px-4 pb-4 pt-2 text-sm">${unsafeHTML(content)}</div>
        </div>
      </div>
    `;
    }
};
MlAccordionBrutal = __decorate([
    customElement('groupexpandcontent--ml-accordion-brutal')
], MlAccordionBrutal);
export { MlAccordionBrutal };
