var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// REVEAL OVERLAY MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupExpandContent
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// O overlay fosco usa backdrop-filter para esconder o conteúdo até revelar.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    reveal: 'Reveal',
    hide: 'Hide',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let RevealOverlayMolecule = class RevealOverlayMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-reveal-overlay {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-loading {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.08);
  color: rgba(255, 255, 255, 0.6);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-header {
  position: relative;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  color: rgba(255, 255, 255, 0.92);
  cursor: pointer;
  transition: background 200ms ease;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-header:not(.is-disabled):hover {
  background: rgba(255, 255, 255, 0.16);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-header.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-header:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-action {
  color: rgba(199, 210, 254, 0.95);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-warning {
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  color: rgba(255, 255, 255, 0.7);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-container {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.05);
  overflow: hidden;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-container.is-disabled {
  opacity: 0.5;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-content {
  color: rgba(255, 255, 255, 0.9);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-overlay {
  border-radius: 12px;
  background: rgba(20, 18, 50, 0.45);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  opacity: 1;
  transition: opacity 300ms ease;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-overlay.is-open {
  opacity: 0;
  pointer-events: none;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-overlay.is-disabled {
  opacity: 0.5;
  pointer-events: none;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-btn {
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.14);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  color: #fff;
  cursor: pointer;
  transition: background 200ms ease;
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-btn:not(.is-disabled):hover {
  background: rgba(255, 255, 255, 0.24);
}
groupexpandcontent--ml-reveal-overlay .glass-reveal-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.openSections = new Set();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        const initial = new Set();
        this.getSlots('Section').forEach((el, index) => {
            if (el.hasAttribute('expanded')) {
                initial.add(index);
            }
        });
        this.openSections = initial;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle(index, title, sectionDisabled) {
        if (this.disabled || sectionDisabled)
            return;
        const next = new Set(this.openSections);
        const isOpen = next.has(index);
        if (isOpen) {
            next.delete(index);
        }
        else {
            if (!this.multiple) {
                next.clear();
            }
            next.add(index);
        }
        this.openSections = next;
        this.dispatchEvent(new CustomEvent('toggle', { bubbles: true, composed: true, detail: { index, title, expanded: !isOpen } }));
    }
    handleHeaderKeydown(e, index, title, sectionDisabled) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleToggle(index, title, sectionDisabled);
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const headers = Array.from(this.querySelectorAll('[data-header="true"]'));
            const current = headers.findIndex((el) => Number(el.getAttribute('data-index')) === index);
            if (current === -1)
                return;
            const nextIndex = e.key === 'ArrowDown' ? Math.min(headers.length - 1, current + 1) : Math.max(0, current - 1);
            headers[nextIndex]?.focus();
        }
    }
    // ===========================================================================
    // RENDER HELPERS  (aparência = classes glass; layout = Tailwind)
    // ===========================================================================
    renderLoading() {
        return html `<div class="glass-reveal-loading p-4 text-sm">${this.msg.loading}</div>`;
    }
    getHeaderClasses(sectionDisabled) {
        return [
            'glass-reveal-header',
            'w-full flex items-center justify-between px-4 py-3 text-sm font-medium',
            this.disabled || sectionDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getContainerClasses(sectionDisabled) {
        return ['glass-reveal-container', 'relative mt-2', this.disabled || sectionDisabled ? 'is-disabled' : '']
            .filter(Boolean)
            .join(' ');
    }
    getOverlayClasses(expanded, sectionDisabled) {
        return [
            'glass-reveal-overlay',
            'absolute inset-0 flex items-center justify-center transition',
            expanded ? 'is-open' : '',
            this.disabled || sectionDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getActionButtonClasses(sectionDisabled) {
        return ['glass-reveal-btn', 'px-4 py-2 text-sm font-medium', this.disabled || sectionDisabled ? 'is-disabled' : '']
            .filter(Boolean)
            .join(' ');
    }
    renderSectionContent(content) {
        return html `<div class="glass-reveal-content relative p-4 text-sm">${unsafeHTML(content)}</div>`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const warning = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const sections = this.getSlots('Section').map((el, index) => ({
            index,
            title: el.getAttribute('title') || '',
            content: el.innerHTML || '',
            sectionDisabled: el.hasAttribute('disabled'),
            expanded: this.openSections.has(index),
        }));
        return html `
      <div class="space-y-4">
        ${sections.map((section) => {
            const headerId = `reveal-header-${section.index}`;
            const regionId = `reveal-region-${section.index}`;
            const actionLabel = section.expanded
                ? `${this.msg.hide} ${section.title}`
                : `${this.msg.reveal} ${section.title}`;
            return html `
            <div>
              <button
                id=${headerId}
                class=${this.getHeaderClasses(section.sectionDisabled)}
                role="button"
                aria-expanded=${section.expanded ? 'true' : 'false'}
                aria-controls=${regionId}
                aria-disabled=${this.disabled || section.sectionDisabled ? 'true' : 'false'}
                data-header="true"
                data-index=${section.index}
                tabindex=${this.disabled || section.sectionDisabled ? '-1' : '0'}
                @click=${() => this.handleToggle(section.index, section.title, section.sectionDisabled)}
                @keydown=${(e) => this.handleHeaderKeydown(e, section.index, section.title, section.sectionDisabled)}
              >
                <span>${section.title}</span>
                <span class="glass-reveal-action">${actionLabel}</span>
              </button>
              ${warning
                ? html `<div class="glass-reveal-warning mt-2 px-4 py-3 text-sm">${unsafeHTML(warning)}</div>`
                : html ``}
              <div id=${regionId} class=${this.getContainerClasses(section.sectionDisabled)} role="region" aria-labelledby=${headerId}>
                ${this.renderSectionContent(section.content)}
                <div class=${this.getOverlayClasses(section.expanded, section.sectionDisabled)}>
                  <button
                    class=${this.getActionButtonClasses(section.sectionDisabled)}
                    @click=${() => this.handleToggle(section.index, section.title, section.sectionDisabled)}
                    ?disabled=${this.disabled || section.sectionDisabled}
                  >
                    ${actionLabel}
                  </button>
                </div>
              </div>
            </div>
          `;
        })}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], RevealOverlayMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], RevealOverlayMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], RevealOverlayMolecule.prototype, "loading", void 0);
__decorate([
    state()
], RevealOverlayMolecule.prototype, "openSections", void 0);
RevealOverlayMolecule = __decorate([
    customElement('groupexpandcontent--ml-reveal-overlay')
], RevealOverlayMolecule);
export { RevealOverlayMolecule };
