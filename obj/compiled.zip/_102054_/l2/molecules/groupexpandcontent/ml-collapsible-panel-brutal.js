var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COLLAPSIBLE PANEL — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupExpandContent
// Herda toda a lógica de MlCollapsiblePanelMolecule (mls-102040): estado das
// seções abertas (openSections), toggle, navegação por teclado e parsing dos
// slots Section. Sobrescreve apenas render() + helpers brutal-*.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlCollapsiblePanelMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
let MlCollapsiblePanelBrutal = class MlCollapsiblePanelBrutal extends MlCollapsiblePanelMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-collapsible-panel-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-section {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  overflow: hidden;
  box-shadow: 3px 3px 0 #000;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-section.is-open {
  border-color: #3b82f6;
  box-shadow: 3px 3px 0 #3b82f6;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-header {
  background: #fff;
  border: none;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-header:hover:not(.is-disabled):not(.is-open) {
  background: #eee;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-header:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-header.is-open {
  background: #3b82f6;
  color: #fff;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-header.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-icon {
  color: #000;
}
groupexpandcontent--ml-collapsible-panel-brutal .is-open .brutal-clp-icon {
  color: #fff;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-title {
  color: #000;
}
groupexpandcontent--ml-collapsible-panel-brutal .is-open .brutal-clp-title {
  color: #fff;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-subtitle {
  color: #666;
}
groupexpandcontent--ml-collapsible-panel-brutal .is-open .brutal-clp-subtitle {
  color: rgba(255, 255, 255, 0.8);
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-chevron {
  color: #000;
}
groupexpandcontent--ml-collapsible-panel-brutal .is-open .brutal-clp-chevron {
  color: #fff;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-body {
  color: #000;
  border-top: 3px solid #000;
}
groupexpandcontent--ml-collapsible-panel-brutal .brutal-clp-skel {
  background: #eee;
  border: 3px solid #000;
  border-radius: 0;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // RENDER (override) — lógica herdada via this.x
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        ${this.loading ? this.brutalLoading() : this.brutalSections()}
      </div>
    `;
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="brutal-clp-label mb-2 text-sm font-bold">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    brutalLoading() {
        const items = [0, 1, 2];
        return html `
      <div class="space-y-2" aria-busy="true" aria-live="polite">
        ${items.map(() => html `<div class="brutal-clp-skel h-12 w-full"></div>`)}
        <div class="sr-only">${this.gMsg.loading}</div>
      </div>
    `;
    }
    brutalSections() {
        const sections = this.getSlots('Section');
        return html `
      <div class="space-y-2">
        ${sections.map((el, index) => {
            const title = el.getAttribute('title') || '';
            const subtitle = el.getAttribute('subtitle') || '';
            const icon = el.getAttribute('icon') || '';
            const isDisabled = this.disabled || el.hasAttribute('disabled');
            const isOpen = this.x.openSections.has(index);
            const headerId = `${this.localName}-header-${index}`;
            const contentId = `${this.localName}-content-${index}`;
            return html `
            <div class="brutal-clp-section w-full ${isOpen ? 'is-open' : ''}">
              <div
                id=${headerId}
                role="button"
                tabindex=${isDisabled ? -1 : 0}
                aria-expanded=${isOpen ? 'true' : 'false'}
                aria-disabled=${isDisabled ? 'true' : 'false'}
                data-header="true"
                class=${this.brutalHeaderClasses(isOpen, isDisabled)}
                @click=${() => this.x.handleHeaderClick(index)}
                @keydown=${(e) => this.x.handleHeaderKeydown(e, index)}
              >
                <div class="flex items-center gap-3">
                  ${icon ? html `<span class="brutal-clp-icon">${unsafeHTML(icon)}</span>` : html ``}
                  <div class="flex flex-col">
                    <span class="brutal-clp-title text-sm font-bold">${title}</span>
                    ${subtitle ? html `<span class="brutal-clp-subtitle text-xs">${subtitle}</span>` : html ``}
                  </div>
                </div>
                <span class=${this.brutalChevronClasses(isOpen)} aria-hidden="true">
                  <svg viewBox="0 0 20 20" fill="none" class="h-4 w-4">
                    ${svg `<path d="M6 8l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />`}
                  </svg>
                </span>
              </div>
              <div id=${contentId} role="region" aria-labelledby=${headerId} class=${this.brutalContentClasses(isOpen)}>
                <div class="brutal-clp-body px-4 pb-4 pt-0 text-sm">${unsafeHTML(this.x.getSectionContent(el))}</div>
              </div>
            </div>
          `;
        })}
      </div>
    `;
    }
    brutalHeaderClasses(isOpen, isDisabled) {
        return [
            'brutal-clp-header flex w-full items-center justify-between gap-3 px-4 py-3 text-left',
            isOpen ? 'is-open' : '',
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalChevronClasses(isOpen) {
        return ['brutal-clp-chevron', isOpen ? 'rotate-180' : 'rotate-0'].join(' ');
    }
    brutalContentClasses(isOpen) {
        return [
            'overflow-hidden',
            isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0',
        ].join(' ');
    }
};
MlCollapsiblePanelBrutal = __decorate([
    customElement('groupexpandcontent--ml-collapsible-panel-brutal')
], MlCollapsiblePanelBrutal);
export { MlCollapsiblePanelBrutal };
