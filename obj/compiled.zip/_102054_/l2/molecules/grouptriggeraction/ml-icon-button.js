var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-icon-button.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ICON BUTTON MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupTriggerAction
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Action',
    loadingLabel: 'Processing',
};
const messages = {
    en: message_en,
    pt: {
        defaultLabel: 'Ação',
        loadingLabel: 'Processando',
    },
};
/// **collab_i18n_end**
let IconButtonMolecule = class IconButtonMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-icon-button {
  display: inline-block;
}
grouptriggeraction--ml-icon-button .glass-icon-btn {
  position: relative;
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.25);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  color: #fff;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.16), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  cursor: pointer;
  transition: background 200ms ease, box-shadow 200ms ease, transform 120ms ease;
  appearance: none;
}
grouptriggeraction--ml-icon-button .glass-icon-btn:not(.is-disabled):hover {
  background: rgba(255, 255, 255, 0.18);
}
grouptriggeraction--ml-icon-button .glass-icon-btn:not(.is-disabled):active {
  transform: translateY(1px);
}
grouptriggeraction--ml-icon-button .glass-icon-btn:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.5);
}
grouptriggeraction--ml-icon-button .glass-icon-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
grouptriggeraction--ml-icon-button .glass-icon-btn.is-loading {
  cursor: wait;
}
grouptriggeraction--ml-icon-button .glass-icon-btn-icon {
  color: rgba(255, 255, 255, 0.92);
  padding: 22%;
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Icon'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleActionClick(event) {
        if (this.disabled || this.loading) {
            event.stopPropagation();
            event.preventDefault();
            return;
        }
        this.dispatchEvent(new CustomEvent('action', { bubbles: true, composed: true, detail: {} }));
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const isDisabled = this.disabled || this.loading;
        const labelContent = this.getSlotContent('Label') || this.msg.defaultLabel;
        const ariaLabel = this.getAccessibleLabel(labelContent);
        return html `
      <button
        type=${this.type}
        class=${this.getButtonClasses(isDisabled)}
        ?disabled=${isDisabled}
        aria-label=${ariaLabel}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        @click=${this.handleActionClick}
      >
        <span class="sr-only">${unsafeHTML(labelContent)}</span>
        ${this.loading ? this.renderLoadingIcon() : this.renderIcon()}
      </button>
    `;
    }
    // =========================================================================
    // TEMPLATE PARTS
    // =========================================================================
    renderIcon() {
        const iconContent = this.getSlotContent('Icon');
        if (iconContent) {
            return html `<span class=${this.getIconClasses()} aria-hidden="true">${unsafeHTML(iconContent)}</span>`;
        }
        return html `
      <span class=${this.getIconClasses()} aria-hidden="true">
        <svg viewBox="0 0 24 24" class="w-full h-full" fill="currentColor" aria-hidden="true">${svg `<circle cx="12" cy="12" r="4"></circle>`}</svg>
      </span>
    `;
    }
    renderLoadingIcon() {
        const label = this.getSlotContent('Label') || this.msg.loadingLabel;
        return html `
      <span class=${this.getIconClasses()} aria-hidden="true">
        <svg viewBox="0 0 24 24" class="w-full h-full animate-spin" fill="none" stroke="currentColor" stroke-width="2">${svg `<circle cx="12" cy="12" r="9" opacity="0.25"></circle><path d="M21 12a9 9 0 0 1-9 9"></path>`}</svg>
      </span>
      <span class="sr-only">${unsafeHTML(label)}</span>
    `;
    }
    // =========================================================================
    // HELPERS  (aparência = classes glass; tamanho = Tailwind)
    // =========================================================================
    getAccessibleLabel(rawLabel) {
        const clean = rawLabel.replace(/<[^>]*>/g, '').trim();
        return clean || this.msg.defaultLabel;
    }
    getButtonClasses(isDisabled) {
        return [
            'glass-icon-btn',
            'inline-flex items-center justify-center',
            this.getSizeClasses(),
            isDisabled ? 'is-disabled' : '',
            this.loading ? 'is-loading' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getIconClasses() {
        return 'glass-icon-btn-icon inline-flex items-center justify-center w-full h-full';
    }
    getSizeClasses() {
        switch (this.size) {
            case 'xs':
                return 'w-7 h-7 text-xs';
            case 'sm':
                return 'w-8 h-8 text-sm';
            case 'lg':
                return 'w-11 h-11 text-base';
            case 'md':
            default:
                return 'w-9 h-9 text-sm';
        }
    }
};
__decorate([
    propertyDataSource({ type: String })
], IconButtonMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], IconButtonMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], IconButtonMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], IconButtonMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], IconButtonMolecule.prototype, "loading", void 0);
IconButtonMolecule = __decorate([
    customElement('grouptriggeraction--ml-icon-button')
], IconButtonMolecule);
export { IconButtonMolecule };
