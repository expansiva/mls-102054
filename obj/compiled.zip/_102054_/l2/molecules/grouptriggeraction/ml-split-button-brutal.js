var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SPLIT BUTTON — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupTriggerAction
// Herda MlSplitButtonMolecule (mls-102040): coleta de opções secundárias, estado
// (isOpen), evento 'action', sizes, loading. Sobrescreve só render() + helpers
// presentacionais brutal. Menu = popover brutal.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlSplitButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-split-button.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Action',
    moreOptions: 'More options',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
let MlSplitButtonBrutal = class MlSplitButtonBrutal extends MlSplitButtonMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-split-button-brutal {
  display: inline-block;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary,
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron {
  border: 3px solid #000;
  background: #3b82f6;
  color: #fff;
  cursor: pointer;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  transition: none;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary:hover:not(:disabled),
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron:hover:not(:disabled) {
  background: #2563eb;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary:focus-visible,
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary:disabled,
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron:disabled {
  opacity: 0.4;
  cursor: not-allowed;
  border-color: #999;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary {
  border-radius: 0;
  box-shadow: 4px 4px 0 #000;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary:hover:not(:disabled) {
  box-shadow: 2px 2px 0 #000;
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-split-button-brutal .brutal-split-primary:active:not(:disabled) {
  box-shadow: 0 0 0 #000;
  transform: translate(4px, 4px);
}
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron {
  border-radius: 0;
  border-left: none;
  box-shadow: 4px 4px 0 #000;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron:hover:not(:disabled) {
  box-shadow: 2px 2px 0 #000;
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-split-button-brutal .brutal-split-chevron:active:not(:disabled) {
  box-shadow: 0 0 0 #000;
  transform: translate(4px, 4px);
}
grouptriggeraction--ml-split-button-brutal .brutal-split-menu {
  border: 3px solid #000;
  border-radius: 0;
  background: #fff;
  box-shadow: 4px 4px 0 #000;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-option {
  border-radius: 0;
  border: none;
  background: transparent;
  color: #000;
  cursor: pointer;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  transition: none;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-option:not(.is-disabled):hover {
  background: #f0f0f0;
}
grouptriggeraction--ml-split-button-brutal .brutal-split-option.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    brutalPrimaryClasses() {
        return ['brutal-split-primary', 'inline-flex items-center justify-center gap-2', this.x.getSizeClasses('primary')]
            .filter(Boolean).join(' ');
    }
    brutalChevronClasses() {
        return ['brutal-split-chevron', 'inline-flex items-center justify-center', this.x.getSizeClasses('chevron')]
            .filter(Boolean).join(' ');
    }
    brutalOptionClasses(item) {
        return ['brutal-split-option', 'w-full text-left px-3 py-2 text-sm', item.disabled ? 'is-disabled' : '']
            .filter(Boolean).join(' ');
    }
    brutalRenderIcon() {
        if (this.loading)
            return this.brutalRenderSpinner();
        if (!this.hasSlot('Icon'))
            return html ``;
        return html `<span class="inline-flex items-center">${unsafeHTML(this.getSlotContent('Icon'))}</span>`;
    }
    brutalRenderLabel() {
        const label = this.getSlotContent('Label') || this.gMsg.defaultLabel;
        return html `<span class="inline-flex items-center">${unsafeHTML(label)}</span>`;
    }
    brutalRenderSpinner() {
        const sizeMap = { xs: 'h-3.5 w-3.5', sm: 'h-4 w-4', md: 'h-4.5 w-4.5', lg: 'h-5 w-5' };
        const sizeClass = sizeMap[this.size] || sizeMap.md;
        return html `
      <span class="inline-flex items-center" aria-hidden="true">
        <svg class="${sizeClass} animate-spin" viewBox="0 0 24 24" fill="none">
          ${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" opacity="0.3"></circle>`}
          ${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>`}
        </svg>
      </span>
    `;
    }
    brutalRenderChevron() {
        return html `<svg class="h-4 w-4" viewBox="0 0 20 20" fill="none" aria-hidden="true">${svg `<path d="M5 7l5 5 5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>`}</svg>`;
    }
    brutalRenderMenuOptions(items) {
        const x = this.x;
        if (!x.isOpen || items.length === 0)
            return html ``;
        return html `
      <div class="brutal-split-menu absolute right-0 top-full z-10 mt-1 min-w-full p-2">
        <div class="flex flex-col gap-1">
          ${items.map((item) => html `
            <button
              type="button"
              class="${this.brutalOptionClasses(item)}"
              ?disabled=${this.disabled || this.loading || item.disabled}
              aria-disabled=${this.disabled || this.loading || item.disabled ? 'true' : 'false'}
              @click=${() => x.handleOptionClick(item)}
            >
              ${unsafeHTML(item.label)}
            </button>
          `)}
        </div>
      </div>
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        const items = x.collectSecondaryItems();
        const hasLabel = this.hasSlot('Label') || !!x.getPrimaryLabelText();
        const hasIcon = this.hasSlot('Icon') || this.loading;
        const ariaLabel = !hasLabel && hasIcon ? x.getAriaLabel() : undefined;
        return html `
      <div class="relative inline-flex items-stretch" role="group">
        <button
          type=${this.type}
          class="${this.brutalPrimaryClasses()}"
          ?disabled=${this.disabled || this.loading}
          aria-busy=${this.loading ? 'true' : 'false'}
          aria-disabled=${this.disabled || this.loading ? 'true' : 'false'}
          aria-label=${ariaLabel || this.gMsg.defaultLabel}
          @click=${() => x.handlePrimaryClick()}
        >
          ${this.iconPosition === 'start' ? this.brutalRenderIcon() : html ``}
          ${this.brutalRenderLabel()}
          ${this.iconPosition === 'end' ? this.brutalRenderIcon() : html ``}
        </button>
        <button
          type="button"
          class="${this.brutalChevronClasses()}"
          ?disabled=${this.disabled || this.loading}
          aria-busy=${this.loading ? 'true' : 'false'}
          aria-disabled=${this.disabled || this.loading ? 'true' : 'false'}
          aria-label=${this.gMsg.moreOptions}
          @click=${() => x.handleToggleMenu()}
        >
          ${this.brutalRenderChevron()}
        </button>
        ${this.brutalRenderMenuOptions(items)}
      </div>
    `;
    }
};
MlSplitButtonBrutal = __decorate([
    customElement('grouptriggeraction--ml-split-button-brutal')
], MlSplitButtonBrutal);
export { MlSplitButtonBrutal };
