var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BUTTON STANDARD — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupTriggerAction
// Herda ButtonStandardMolecule (mls-102040): variants, sizes, loading, ícone,
// evento 'action'. Sobrescreve só render() + helpers presentacionais brutal.
// This molecule does NOT contain business logic.
import { html, nothing, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ButtonStandardMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
let ButtonStandardBrutal = class ButtonStandardBrutal extends ButtonStandardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-button-standard-brutal {
  display: inline-block;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  cursor: pointer;
  box-shadow: 4px 4px 0 #000;
  transition: none;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn:not(.is-disabled):hover {
  box-shadow: 2px 2px 0 #000;
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn:not(.is-disabled):active {
  box-shadow: 0 0 0 #000;
  transform: translate(4px, 4px);
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: 2px 2px 0 #999;
  border-color: #999;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--primary {
  background: #3b82f6;
  color: #fff;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--primary:not(.is-disabled):hover {
  background: #2563eb;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--secondary {
  background: #fff;
  color: #000;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--secondary:not(.is-disabled):hover {
  background: #f0f0f0;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--danger {
  background: #ef4444;
  color: #fff;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--danger:not(.is-disabled):hover {
  background: #dc2626;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--ghost {
  background: transparent;
  color: #000;
  border-color: #000;
  box-shadow: none;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--ghost:not(.is-disabled):hover {
  background: #f0f0f0;
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--ghost:not(.is-disabled):active {
  background: #e0e0e0;
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--link {
  background: transparent;
  border: none;
  box-shadow: none;
  color: #000;
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-thickness: 2px;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--link:not(.is-disabled):hover {
  color: #3b82f6;
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .brutal-btn--link:not(.is-disabled):active {
  box-shadow: none;
  transform: none;
}
`);
    }
    get x() {
        return this;
    }
    brutalButtonClasses(hasLabel) {
        const isDisabled = this.x.isDisabled();
        const variant = this.x.getVariant();
        const sizeClasses = this.x.getSizeClasses(hasLabel);
        return [
            'brutal-btn',
            `brutal-btn--${variant}`,
            'inline-flex items-center justify-center',
            sizeClasses.button,
            sizeClasses.gap,
            isDisabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalSpinner(sizeClass) {
        return html `
      <svg class="animate-spin ${sizeClass}" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        ${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.3" stroke-width="4"></circle>`}
        ${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="4" stroke-linecap="round"></path>`}
      </svg>
    `;
    }
    render() {
        const x = this.x;
        const labelContent = (this.getSlotContent('Label') || '').trim();
        const iconContent = (this.getSlotContent('Icon') || '').trim();
        const hasLabel = labelContent.length > 0;
        const hasIcon = iconContent.length > 0;
        const isDisabled = x.isDisabled();
        const sizeClasses = x.getSizeClasses(hasLabel);
        const iconPosition = this.iconPosition === 'end' ? 'end' : 'start';
        const ariaLabel = !hasLabel && hasIcon ? labelContent : undefined;
        const iconTemplate = hasIcon
            ? html `<span class="${x.getIconClasses(sizeClasses.icon)}">${unsafeHTML(iconContent)}</span>`
            : nothing;
        const spinnerTemplate = html `<span class="${x.getIconClasses(sizeClasses.spinner)}">${this.brutalSpinner(sizeClasses.spinner)}</span>`;
        const labelTemplate = hasLabel
            ? html `<span class="${this.loading && !hasIcon ? 'opacity-0' : ''}">${unsafeHTML(labelContent)}</span>`
            : nothing;
        const labelWithSpinner = html `
      <span class="relative inline-flex items-center justify-center">
        ${labelTemplate}
        ${this.loading && !hasIcon ? html `<span class="absolute">${spinnerTemplate}</span>` : nothing}
      </span>
    `;
        const contentTemplate = html `
      ${iconPosition === 'start'
            ? html `${this.loading && hasIcon ? spinnerTemplate : iconTemplate} ${labelWithSpinner}`
            : html `${labelWithSpinner} ${this.loading && hasIcon ? spinnerTemplate : iconTemplate}`}
    `;
        return html `
      <button
        class="${this.brutalButtonClasses(hasLabel)}"
        type="${this.type}"
        ?disabled=${isDisabled}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        aria-label=${ariaLabel || nothing}
        @click=${(e) => x.handleActionClick(e)}
      >
        ${contentTemplate}
      </button>
    `;
    }
};
ButtonStandardBrutal = __decorate([
    customElement('grouptriggeraction--ml-button-standard-brutal')
], ButtonStandardBrutal);
export { ButtonStandardBrutal };
