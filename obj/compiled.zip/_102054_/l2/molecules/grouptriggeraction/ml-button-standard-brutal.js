var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BUTTON STANDARD — BRUTALISM (mls-102054)
// =============================================================================
// Skill Group: groupTriggerAction
// Casca (estratégia D): herda tudo de ButtonStandardMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ButtonStandardMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
let ButtonStandardBrutal = class ButtonStandardBrutal extends ButtonStandardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-button-standard-brutal {
  display: inline-block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
grouptriggeraction--ml-button-standard-brutal .ml-button {
  position: relative;
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  cursor: pointer;
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
grouptriggeraction--ml-button-standard-brutal .ml-button:not(.ml-disabled):hover {
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-button-standard-brutal .ml-button:not(.ml-disabled):active {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
grouptriggeraction--ml-button-standard-brutal .ml-button:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-primary {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
grouptriggeraction--ml-button-standard-brutal .ml-button-primary:not(.ml-disabled):hover {
  background: #2563eb;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-secondary {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
}
grouptriggeraction--ml-button-standard-brutal .ml-button-secondary:not(.ml-disabled):hover {
  background: var(--ml-surface-dim, #f0f0f0);
}
grouptriggeraction--ml-button-standard-brutal .ml-button-danger {
  background: var(--ml-error, #ef4444);
  color: var(--ml-on-primary, #ffffff);
}
grouptriggeraction--ml-button-standard-brutal .ml-button-danger:not(.ml-disabled):hover {
  background: #dc2626;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-ghost {
  background: transparent;
  color: var(--ml-on-surface, #000000);
  border-color: var(--ml-outline-variant, #000000);
  box-shadow: none;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-ghost:not(.ml-disabled):hover {
  background: var(--ml-surface-dim, #f0f0f0);
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-ghost:not(.ml-disabled):active {
  background: #e0e0e0;
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-link {
  background: transparent;
  border: none;
  box-shadow: none;
  color: var(--ml-on-surface, #000000);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-thickness: 2px;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-link:not(.ml-disabled):hover {
  color: var(--ml-primary, #3b82f6);
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .ml-button-link:not(.ml-disabled):active {
  box-shadow: none;
  transform: none;
}
grouptriggeraction--ml-button-standard-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  box-shadow: 2px 2px 0 #999999;
  border-color: #999999;
}
`);
    }
};
ButtonStandardBrutal = __decorate([
    customElement('grouptriggeraction--ml-button-standard-brutal')
], ButtonStandardBrutal);
export { ButtonStandardBrutal };
