var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ICON BUTTON — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupTriggerAction
// Herda IconButtonMolecule (mls-102040): sizes, loading, evento 'action', rótulo
// acessível. Sobrescreve só render() + helpers presentacionais brutal.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { IconButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Action',
    loadingLabel: 'Processing',
};
const messages = {
    en: message_en,
    pt: {
        defaultLabel: 'Ação',
        loadingLabel: 'Processando',
    },
};
let IconButtonBrutal = class IconButtonBrutal extends IconButtonMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-icon-button-brutal {
  display: inline-block;
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  box-shadow: 3px 3px 0 #000;
  cursor: pointer;
  transition: none;
  appearance: none;
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn:not(.is-disabled):hover {
  background: #f0f0f0;
  box-shadow: 1px 1px 0 #000;
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn:not(.is-disabled):active {
  box-shadow: 0 0 0 #000;
  transform: translate(3px, 3px);
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  border-color: #999;
  box-shadow: 2px 2px 0 #999;
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn.is-loading {
  cursor: wait;
}
grouptriggeraction--ml-icon-button-brutal .brutal-icon-btn-icon {
  color: #000;
  padding: 22%;
}
grouptriggeraction--ml-icon-button-brutal .is-disabled .brutal-icon-btn-icon {
  color: #999;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    brutalButtonClasses(isDisabled) {
        return [
            'brutal-icon-btn',
            'inline-flex items-center justify-center',
            this.x.getSizeClasses(),
            isDisabled ? 'is-disabled' : '',
            this.loading ? 'is-loading' : '',
        ].filter(Boolean).join(' ');
    }
    brutalIconClasses() {
        return 'brutal-icon-btn-icon inline-flex items-center justify-center w-full h-full';
    }
    brutalRenderIcon() {
        const iconContent = this.getSlotContent('Icon');
        if (iconContent) {
            return html `<span class=${this.brutalIconClasses()} aria-hidden="true">${unsafeHTML(iconContent)}</span>`;
        }
        return html `
      <span class=${this.brutalIconClasses()} aria-hidden="true">
        <svg viewBox="0 0 24 24" class="w-full h-full" fill="currentColor" aria-hidden="true">${svg `<circle cx="12" cy="12" r="4"></circle>`}</svg>
      </span>
    `;
    }
    brutalRenderLoadingIcon() {
        const label = this.getSlotContent('Label') || this.gMsg.loadingLabel;
        return html `
      <span class=${this.brutalIconClasses()} aria-hidden="true">
        <svg viewBox="0 0 24 24" class="w-full h-full animate-spin" fill="none" stroke="currentColor" stroke-width="2">${svg `<circle cx="12" cy="12" r="9" opacity="0.3"></circle><path d="M21 12a9 9 0 0 1-9 9"></path>`}</svg>
      </span>
      <span class="sr-only">${unsafeHTML(label)}</span>
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        const isDisabled = this.disabled || this.loading;
        const labelContent = this.getSlotContent('Label') || this.gMsg.defaultLabel;
        const ariaLabel = x.getAccessibleLabel(labelContent);
        return html `
      <button
        type=${this.type}
        class=${this.brutalButtonClasses(isDisabled)}
        ?disabled=${isDisabled}
        aria-label=${ariaLabel}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        @click=${(e) => x.handleActionClick(e)}
      >
        <span class="sr-only">${unsafeHTML(labelContent)}</span>
        ${this.loading ? this.brutalRenderLoadingIcon() : this.brutalRenderIcon()}
      </button>
    `;
    }
};
IconButtonBrutal = __decorate([
    customElement('grouptriggeraction--ml-icon-button-brutal')
], IconButtonBrutal);
export { IconButtonBrutal };
