var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-button-standard.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BUTTON STANDARD MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupTriggerAction
// Mesma molécula/contrato do mls-102040. Lógica intacta (variants, sizes, loading,
// ícone, evento 'action'). A aparência (vidro) vive no .less, escopada sob a tag.
// Layout (flex, padding, gap, tamanho de ícone) permanece em Tailwind.
// This molecule does NOT contain business logic.
import { html, nothing, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let ButtonStandardMolecule = class ButtonStandardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-button-standard {
  display: inline-block;
}
grouptriggeraction--ml-button-standard .glass-btn {
  position: relative;
  overflow: hidden;
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.25);
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 600;
  color: #fff;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.18);
  transition: background 250ms ease, border-color 250ms ease, box-shadow 250ms ease, transform 120ms ease;
  cursor: pointer;
}
grouptriggeraction--ml-button-standard .glass-btn::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
grouptriggeraction--ml-button-standard .glass-btn:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.5), 0 4px 18px rgba(0, 0, 0, 0.18);
}
grouptriggeraction--ml-button-standard .glass-btn:not(.is-disabled):hover {
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.26);
}
grouptriggeraction--ml-button-standard .glass-btn:not(.is-disabled):active {
  transform: translateY(1px);
}
grouptriggeraction--ml-button-standard .glass-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
grouptriggeraction--ml-button-standard .glass-btn--primary {
  background: rgba(99, 102, 241, 0.55);
}
grouptriggeraction--ml-button-standard .glass-btn--primary:not(.is-disabled):hover {
  background: rgba(99, 102, 241, 0.68);
}
grouptriggeraction--ml-button-standard .glass-btn--secondary {
  background: rgba(255, 255, 255, 0.14);
}
grouptriggeraction--ml-button-standard .glass-btn--secondary:not(.is-disabled):hover {
  background: rgba(255, 255, 255, 0.22);
}
grouptriggeraction--ml-button-standard .glass-btn--danger {
  background: rgba(244, 63, 94, 0.55);
}
grouptriggeraction--ml-button-standard .glass-btn--danger:not(.is-disabled):hover {
  background: rgba(244, 63, 94, 0.68);
}
grouptriggeraction--ml-button-standard .glass-btn--ghost {
  background: rgba(255, 255, 255, 0.04);
  border-color: rgba(255, 255, 255, 0.15);
}
grouptriggeraction--ml-button-standard .glass-btn--ghost:not(.is-disabled):hover {
  background: rgba(255, 255, 255, 0.12);
}
grouptriggeraction--ml-button-standard .glass-btn--link {
  background: transparent;
  border-color: transparent;
  backdrop-filter: none;
  -webkit-backdrop-filter: none;
  box-shadow: none;
  color: #c7d2fe;
}
grouptriggeraction--ml-button-standard .glass-btn--link::before {
  display: none;
}
grouptriggeraction--ml-button-standard .glass-btn--link:not(.is-disabled):hover {
  text-decoration: underline;
  box-shadow: none;
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleActionClick(e) {
        const isDisabled = this.isDisabled();
        if (isDisabled) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        this.dispatchEvent(new CustomEvent('action', { bubbles: true, composed: true, detail: {} }));
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isDisabled() {
        return this.disabled || this.loading;
    }
    getVariant() {
        const variant = (this.getAttribute('data-variant') || 'primary').toLowerCase();
        if (variant === 'secondary' || variant === 'danger' || variant === 'ghost' || variant === 'link') {
            return variant;
        }
        return 'primary';
    }
    getSizeKey() {
        if (this.size === 'xs' || this.size === 'sm' || this.size === 'lg')
            return this.size;
        return 'md';
    }
    // Layout (Tailwind): padding, escala de ícone e gap/text-size por tamanho.
    getSizeClasses(hasLabel) {
        const sizeKey = this.getSizeKey();
        const iconOnly = !hasLabel;
        const paddingMap = {
            xs: iconOnly ? 'p-1.5' : 'px-2 py-1',
            sm: iconOnly ? 'p-2' : 'px-3 py-1.5',
            md: iconOnly ? 'p-2.5' : 'px-4 py-2',
            lg: iconOnly ? 'p-3' : 'px-5 py-2.5',
        };
        const iconMap = { xs: 'h-3 w-3', sm: 'h-4 w-4', md: 'h-5 w-5', lg: 'h-6 w-6' };
        const gapMap = {
            xs: 'gap-1.5 text-xs',
            sm: 'gap-2 text-sm',
            md: 'gap-2 text-sm',
            lg: 'gap-2.5 text-base',
        };
        return { button: paddingMap[sizeKey], icon: iconMap[sizeKey], spinner: iconMap[sizeKey], gap: gapMap[sizeKey] };
    }
    // Aparência (glass): classes locais definidas no .less, dirigidas por variant/estado.
    getButtonClasses(hasLabel) {
        const isDisabled = this.isDisabled();
        const variant = this.getVariant();
        const sizeClasses = this.getSizeClasses(hasLabel);
        return [
            'glass-btn',
            `glass-btn--${variant}`,
            'inline-flex items-center justify-center',
            sizeClasses.button,
            sizeClasses.gap,
            isDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getIconClasses(sizeClass) {
        return ['inline-flex items-center justify-center', sizeClass].join(' ');
    }
    renderSpinner(sizeClass) {
        return html `
      <svg class="animate-spin ${sizeClass}" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        ${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25" stroke-width="4"></circle>`}
        ${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="4" stroke-linecap="round"></path>`}
      </svg>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const labelContent = (this.getSlotContent('Label') || '').trim();
        const iconContent = (this.getSlotContent('Icon') || '').trim();
        const hasLabel = labelContent.length > 0;
        const hasIcon = iconContent.length > 0;
        const isDisabled = this.isDisabled();
        const sizeClasses = this.getSizeClasses(hasLabel);
        const iconPosition = this.iconPosition === 'end' ? 'end' : 'start';
        const ariaLabel = !hasLabel && hasIcon ? labelContent : undefined;
        const iconTemplate = hasIcon
            ? html `<span class="${this.getIconClasses(sizeClasses.icon)}">${unsafeHTML(iconContent)}</span>`
            : nothing;
        const spinnerTemplate = html `<span class="${this.getIconClasses(sizeClasses.spinner)}"
      >${this.renderSpinner(sizeClasses.spinner)}</span
    >`;
        const labelTemplate = hasLabel
            ? html `<span class="${this.loading && !hasIcon ? 'opacity-0' : ''}">${unsafeHTML(labelContent)}</span>`
            : nothing;
        const labelWithSpinner = html `
      <span class="relative inline-flex items-center justify-center">
        ${labelTemplate} ${this.loading && !hasIcon ? html `<span class="absolute">${spinnerTemplate}</span>` : nothing}
      </span>
    `;
        const contentTemplate = html `
      ${iconPosition === 'start'
            ? html ` ${this.loading && hasIcon ? spinnerTemplate : iconTemplate} ${labelWithSpinner} `
            : html ` ${labelWithSpinner} ${this.loading && hasIcon ? spinnerTemplate : iconTemplate} `}
    `;
        return html `
      <button
        class="${this.getButtonClasses(hasLabel)}"
        type="${this.type}"
        ?disabled=${isDisabled}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        aria-label=${ariaLabel || nothing}
        @click=${this.handleActionClick}
      >
        ${contentTemplate}
      </button>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], ButtonStandardMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], ButtonStandardMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], ButtonStandardMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ButtonStandardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ButtonStandardMolecule.prototype, "loading", void 0);
ButtonStandardMolecule = __decorate([
    customElement('grouptriggeraction--ml-button-standard')
], ButtonStandardMolecule);
export { ButtonStandardMolecule };
