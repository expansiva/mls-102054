var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// METRIC BIG NUMBER — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupViewMetric
// Herda MlMetricBigNumberMolecule (mls-102040): contrato/slots/loading intactos.
// Sobrescreve so render() + helpers presentacionais (brutal). Display-only.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlMetricBigNumberMolecule } from '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number.js';
let MlMetricBigNumberBrutal = class MlMetricBigNumberBrutal extends MlMetricBigNumberMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-big-number-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  box-shadow: 4px 4px 0 #000;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-icon {
  color: #000;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-label {
  color: #555;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-value {
  color: #000;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-helper {
  color: #777;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-trend.is-up {
  color: #10b981;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-trend.is-down {
  color: #ef4444;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-trend.is-neutral {
  color: #777;
}
groupviewmetric--ml-metric-big-number-brutal .brutal-bn-skel {
  background: #e5e5e5;
  border: 2px solid #ccc;
  border-radius: 0;
  animation: brutal-bn-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-bn-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
    }
    // ===========================================================================
    // RENDER (override) — contrato/slots/loading herdados
    // ===========================================================================
    render() {
        if (this.loading) {
            return this.brutalLoadingSkeleton();
        }
        if (!this.hasSlot('Value')) {
            return html ``;
        }
        const ariaLabel = this.brutalAriaLabel();
        return html `
      <div class="${this.brutalContainerClasses()}" role="figure" aria-label="${ariaLabel}">
        ${this.hasSlot('Icon') ? this.brutalIcon() : html ``}
        ${this.hasSlot('Label') ? this.brutalLabel() : html ``}
        ${this.brutalValue()}
        ${this.hasSlot('Trend') ? this.brutalTrend() : html ``}
        ${this.hasSlot('Helper') ? this.brutalHelper() : html ``}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER HELPERS (brutal) — nomes proprios p/ nao colidir com os private do pai
    // ===========================================================================
    brutalIcon() {
        const content = this.getSlotContent('Icon');
        return html `<div class="brutal-bn-icon flex items-center">${unsafeHTML(content)}</div>`;
    }
    brutalLabel() {
        const content = this.getSlotContent('Label');
        return html `<div class="brutal-bn-label text-sm font-bold">${unsafeHTML(content)}</div>`;
    }
    brutalValue() {
        const content = this.getSlotContent('Value');
        return html `<div class="brutal-bn-value text-4xl leading-tight font-black" aria-live="polite">${unsafeHTML(content)}</div>`;
    }
    brutalTrend() {
        const direction = this.brutalTrendDirection();
        const content = this.getSlotContent('Trend');
        return html `<div class="${this.brutalTrendClasses(direction)}" aria-label="Trend: ${direction}">${unsafeHTML(content)}</div>`;
    }
    brutalHelper() {
        const content = this.getSlotContent('Helper');
        return html `<div class="brutal-bn-helper text-xs">${unsafeHTML(content)}</div>`;
    }
    brutalLoadingSkeleton() {
        return html `
      <div class="${this.brutalContainerClasses()}" role="figure" aria-busy="true">
        <div class="brutal-bn-skel h-4 w-24"></div>
        <div class="brutal-bn-skel mt-2 h-10 w-40"></div>
        <div class="brutal-bn-skel mt-2 h-4 w-20"></div>
      </div>
    `;
    }
    // ===========================================================================
    // CLASS HELPERS (brutal)
    // ===========================================================================
    brutalContainerClasses() {
        return 'brutal-bn flex flex-col gap-1 p-4';
    }
    brutalTrendClasses(direction) {
        const dir = direction === 'up' ? 'is-up' : direction === 'down' ? 'is-down' : 'is-neutral';
        return `brutal-bn-trend ${dir} inline-flex items-center gap-1 text-sm font-bold`;
    }
    // ===========================================================================
    // UTILITIES (brutal)
    // ===========================================================================
    brutalTrendDirection() {
        const dir = this.getSlotAttr('Trend', 'direction');
        if (dir === 'up' || dir === 'down' || dir === 'neutral')
            return dir;
        return 'neutral';
    }
    brutalAriaLabel() {
        const raw = this.getSlotContent('Label') || 'Metric';
        return raw.replace(/<[^>]*>/g, '').trim() || 'Metric';
    }
};
MlMetricBigNumberBrutal = __decorate([
    customElement('groupviewmetric--ml-metric-big-number-brutal')
], MlMetricBigNumberBrutal);
export { MlMetricBigNumberBrutal };
