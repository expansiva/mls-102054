var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewmetric/ml-metric-card.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// METRIC CARD MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupViewMetric
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MetricCardMolecule = class MetricCardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-card {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupviewmetric--ml-metric-card .glass-mc {
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 16px;
  color: #fff;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
}
groupviewmetric--ml-metric-card .glass-mc-label {
  color: rgba(255, 255, 255, 0.7);
}
groupviewmetric--ml-metric-card .glass-mc-value {
  color: #fff;
}
groupviewmetric--ml-metric-card .glass-mc-helper {
  color: rgba(255, 255, 255, 0.55);
}
groupviewmetric--ml-metric-card .glass-mc-icon {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 10px;
  color: rgba(255, 255, 255, 0.85);
}
groupviewmetric--ml-metric-card .glass-mc-trend {
  border-radius: 8px;
  border: 1px solid transparent;
}
groupviewmetric--ml-metric-card .glass-mc-trend.is-up {
  color: #6ee7b7;
  background: rgba(16, 185, 129, 0.15);
  border-color: rgba(16, 185, 129, 0.4);
}
groupviewmetric--ml-metric-card .glass-mc-trend.is-down {
  color: #fca5a5;
  background: rgba(239, 68, 68, 0.15);
  border-color: rgba(239, 68, 68, 0.4);
}
groupviewmetric--ml-metric-card .glass-mc-trend.is-neutral {
  color: rgba(255, 255, 255, 0.7);
  background: rgba(255, 255, 255, 0.08);
  border-color: rgba(255, 255, 255, 0.2);
}
groupviewmetric--ml-metric-card .glass-mc-skel {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 6px;
  animation: glass-mc-pulse 1.4s ease-in-out infinite;
}
@keyframes glass-mc-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Value', 'Icon', 'Trend', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.loading = false;
    }
    // ===========================================================================
    // RENDER HELPERS (glass)
    // ===========================================================================
    getBaseClasses() {
        return 'glass-mc w-full p-4';
    }
    getLabelClasses() {
        return 'glass-mc-label text-sm font-medium';
    }
    getValueClasses() {
        return 'glass-mc-value text-3xl font-semibold tracking-tight';
    }
    getHelperClasses() {
        return 'glass-mc-helper text-xs';
    }
    getTrendClasses(direction) {
        const dir = direction === 'up' ? 'is-up' : direction === 'down' ? 'is-down' : 'is-neutral';
        return `glass-mc-trend ${dir} inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium`;
    }
    getAriaLabelFromHtml(content) {
        if (!content)
            return '';
        return content.replace(/<[^>]*>/g, '').trim();
    }
    renderIcon() {
        if (!this.hasSlot('Icon'))
            return html ``;
        return html `
      <div class="glass-mc-icon flex items-center justify-center p-2">
        <span>${unsafeHTML(this.getSlotContent('Icon'))}</span>
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="${this.getLabelClasses()}">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderValue() {
        return html `<div class="${this.getValueClasses()}" aria-live="polite">${unsafeHTML(this.getSlotContent('Value'))}</div>`;
    }
    renderTrend() {
        if (!this.hasSlot('Trend'))
            return html ``;
        const direction = this.getSlotAttr('Trend', 'direction');
        const aria = direction ? `Trend: ${direction}` : '';
        return html `<div class="${this.getTrendClasses(direction)}" aria-label=${aria}>${unsafeHTML(this.getSlotContent('Trend'))}</div>`;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<div class="${this.getHelperClasses()}">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
    }
    renderSkeleton() {
        const block = 'glass-mc-skel';
        return html `
      <div class="flex items-start gap-3">
        <div class="h-10 w-10 ${block}"></div>
        <div class="flex-1 space-y-2">
          <div class="h-3 w-1/2 ${block}"></div>
          <div class="h-8 w-2/3 ${block}"></div>
          <div class="h-4 w-1/3 ${block}"></div>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const labelContent = this.getSlotContent('Label');
        const ariaLabel = this.getAriaLabelFromHtml(labelContent);
        return html `
      <div class="${this.getBaseClasses()}" role="figure" aria-label=${ariaLabel}>
        ${this.loading
            ? this.renderSkeleton()
            : html `
              <div class="flex items-start justify-between gap-3">
                <div class="flex items-start gap-3">
                  ${this.renderIcon()}
                  <div class="space-y-1">
                    ${this.renderLabel()}
                    ${this.renderValue()}
                  </div>
                </div>
                <div class="pt-1">${this.renderTrend()}</div>
              </div>
              <div class="mt-2">${this.renderHelper()}</div>
            `}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MetricCardMolecule.prototype, "loading", void 0);
MetricCardMolecule = __decorate([
    customElement('groupviewmetric--ml-metric-card')
], MetricCardMolecule);
export { MetricCardMolecule };
