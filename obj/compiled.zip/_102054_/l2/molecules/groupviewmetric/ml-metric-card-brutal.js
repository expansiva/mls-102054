var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// METRIC CARD — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupViewMetric
// Herda MetricCardMolecule (mls-102040): contrato/slots/loading intactos.
// Sobrescreve so render() + helpers presentacionais (brutal). Display-only.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MetricCardMolecule } from '/_102040_/l2/molecules/groupviewmetric/ml-metric-card.js';
let MetricCardBrutal = class MetricCardBrutal extends MetricCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-card-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  box-shadow: 4px 4px 0 #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-label {
  color: #555;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-value {
  color: #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-helper {
  color: #777;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-icon {
  background: #f5f5f5;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-trend {
  border-radius: 0;
  border: 2px solid #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-trend.is-up {
  color: #fff;
  background: #10b981;
  border-color: #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-trend.is-down {
  color: #fff;
  background: #ef4444;
  border-color: #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-trend.is-neutral {
  color: #000;
  background: #e5e5e5;
  border-color: #000;
}
groupviewmetric--ml-metric-card-brutal .brutal-mc-skel {
  background: #e5e5e5;
  border: 2px solid #ccc;
  border-radius: 0;
  animation: brutal-mc-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-mc-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
    }
    // ---- helpers presentacionais (brutal) — nomes proprios p/ nao colidir com os private do pai ----
    brutalBaseClasses() {
        return 'brutal-mc w-full p-4';
    }
    brutalLabelClasses() {
        return 'brutal-mc-label text-sm font-bold';
    }
    brutalValueClasses() {
        return 'brutal-mc-value text-3xl font-black tracking-tight';
    }
    brutalHelperClasses() {
        return 'brutal-mc-helper text-xs';
    }
    brutalTrendClasses(direction) {
        const dir = direction === 'up' ? 'is-up' : direction === 'down' ? 'is-down' : 'is-neutral';
        return `brutal-mc-trend ${dir} inline-flex items-center gap-1 px-2 py-0.5 text-xs font-bold`;
    }
    brutalAriaLabelFromHtml(content) {
        if (!content)
            return '';
        return content.replace(/<[^>]*>/g, '').trim();
    }
    brutalIcon() {
        if (!this.hasSlot('Icon'))
            return html ``;
        return html `
      <div class="brutal-mc-icon flex items-center justify-center p-2">
        <span>${unsafeHTML(this.getSlotContent('Icon'))}</span>
      </div>
    `;
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="${this.brutalLabelClasses()}">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    brutalValue() {
        return html `<div class="${this.brutalValueClasses()}" aria-live="polite">${unsafeHTML(this.getSlotContent('Value'))}</div>`;
    }
    brutalTrend() {
        if (!this.hasSlot('Trend'))
            return html ``;
        const direction = this.getSlotAttr('Trend', 'direction');
        const aria = direction ? `Trend: ${direction}` : '';
        return html `<div class="${this.brutalTrendClasses(direction)}" aria-label=${aria}>${unsafeHTML(this.getSlotContent('Trend'))}</div>`;
    }
    brutalHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<div class="${this.brutalHelperClasses()}">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
    }
    brutalSkeleton() {
        const block = 'brutal-mc-skel';
        return html `
      <div class="flex items-start gap-3">
        <div class="h-10 w-10 ${block}"></div>
        <div class="flex-1 space-y-2">
          <div class="h-3 w-1/2 ${block}"></div>
          <div class="h-8 w-2/3 ${block}"></div>
          <div class="h-4 w-1/3 ${block}"></div>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — contrato/slots/loading herdados
    // ===========================================================================
    render() {
        const labelContent = this.getSlotContent('Label');
        const ariaLabel = this.brutalAriaLabelFromHtml(labelContent);
        return html `
      <div class="${this.brutalBaseClasses()}" role="figure" aria-label=${ariaLabel}>
        ${this.loading
            ? this.brutalSkeleton()
            : html `
              <div class="flex items-start justify-between gap-3">
                <div class="flex items-start gap-3">
                  ${this.brutalIcon()}
                  <div class="space-y-1">
                    ${this.brutalLabel()}
                    ${this.brutalValue()}
                  </div>
                </div>
                <div class="pt-1">${this.brutalTrend()}</div>
              </div>
              <div class="mt-2">${this.brutalHelper()}</div>
            `}
      </div>
    `;
    }
};
MetricCardBrutal = __decorate([
    customElement('groupviewmetric--ml-metric-card-brutal')
], MetricCardBrutal);
export { MetricCardBrutal };
