/// <mls fileReference="_102054_/l2/molecules/groupviewmetric/ml-metric-big-number.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML METRIC BIG NUMBER MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupViewMetric
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MlMetricBigNumberMolecule = class MlMetricBigNumberMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-big-number {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupviewmetric--ml-metric-big-number .glass-bn {
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 14px;
  color: #fff;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
}
groupviewmetric--ml-metric-big-number .glass-bn-icon {
  color: rgba(255, 255, 255, 0.7);
}
groupviewmetric--ml-metric-big-number .glass-bn-label {
  color: rgba(255, 255, 255, 0.7);
}
groupviewmetric--ml-metric-big-number .glass-bn-value {
  color: #fff;
}
groupviewmetric--ml-metric-big-number .glass-bn-helper {
  color: rgba(255, 255, 255, 0.55);
}
groupviewmetric--ml-metric-big-number .glass-bn-trend.is-up {
  color: #6ee7b7;
}
groupviewmetric--ml-metric-big-number .glass-bn-trend.is-down {
  color: #fca5a5;
}
groupviewmetric--ml-metric-big-number .glass-bn-trend.is-neutral {
  color: rgba(255, 255, 255, 0.6);
}
groupviewmetric--ml-metric-big-number .glass-bn-skel {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 6px;
  animation: glass-bn-pulse 1.4s ease-in-out infinite;
}
@keyframes glass-bn-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Value', 'Icon', 'Trend', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.loading = false;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        if (this.loading) {
            return this.renderLoadingSkeleton();
        }
        if (!this.hasSlot('Value')) {
            return html ``;
        }
        const ariaLabel = this.getAriaLabel();
        return html `
      <div class="${this.getContainerClasses()}" role="figure" aria-label="${ariaLabel}">
        ${this.hasSlot('Icon') ? this.renderIcon() : html ``}
        ${this.hasSlot('Label') ? this.renderLabel() : html ``}
        ${this.renderValue()}
        ${this.hasSlot('Trend') ? this.renderTrend() : html ``}
        ${this.hasSlot('Helper') ? this.renderHelper() : html ``}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER HELPERS (glass)
    // ===========================================================================
    renderIcon() {
        const content = this.getSlotContent('Icon');
        return html `<div class="glass-bn-icon flex items-center">${unsafeHTML(content)}</div>`;
    }
    renderLabel() {
        const content = this.getSlotContent('Label');
        return html `<div class="glass-bn-label text-sm font-medium">${unsafeHTML(content)}</div>`;
    }
    renderValue() {
        const content = this.getSlotContent('Value');
        return html `<div class="glass-bn-value text-4xl leading-tight font-semibold" aria-live="polite">${unsafeHTML(content)}</div>`;
    }
    renderTrend() {
        const direction = this.getTrendDirection();
        const content = this.getSlotContent('Trend');
        return html `<div class="${this.getTrendClasses(direction)}" aria-label="Trend: ${direction}">${unsafeHTML(content)}</div>`;
    }
    renderHelper() {
        const content = this.getSlotContent('Helper');
        return html `<div class="glass-bn-helper text-xs">${unsafeHTML(content)}</div>`;
    }
    renderLoadingSkeleton() {
        return html `
      <div class="${this.getContainerClasses()}" role="figure" aria-busy="true">
        <div class="glass-bn-skel h-4 w-24"></div>
        <div class="glass-bn-skel mt-2 h-10 w-40"></div>
        <div class="glass-bn-skel mt-2 h-4 w-20"></div>
      </div>
    `;
    }
    // ===========================================================================
    // CLASS HELPERS (glass)
    // ===========================================================================
    getContainerClasses() {
        return 'glass-bn flex flex-col gap-1 p-4';
    }
    getTrendClasses(direction) {
        const dir = direction === 'up' ? 'is-up' : direction === 'down' ? 'is-down' : 'is-neutral';
        return `glass-bn-trend ${dir} inline-flex items-center gap-1 text-sm font-medium`;
    }
    // ===========================================================================
    // UTILITIES
    // ===========================================================================
    getTrendDirection() {
        const dir = this.getSlotAttr('Trend', 'direction');
        if (dir === 'up' || dir === 'down' || dir === 'neutral')
            return dir;
        return 'neutral';
    }
    getAriaLabel() {
        const raw = this.getSlotContent('Label') || 'Metric';
        return raw.replace(/<[^>]*>/g, '').trim() || 'Metric';
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlMetricBigNumberMolecule.prototype, "loading", void 0);
MlMetricBigNumberMolecule = __decorate([
    customElement('groupviewmetric--ml-metric-big-number')
], MlMetricBigNumberMolecule);
export { MlMetricBigNumberMolecule };
