var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SIDEBAR NAV — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlSidebarNavMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSidebarNavMolecule } from '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav.js';
let MlSidebarNavBrutal = class MlSidebarNavBrutal extends MlSidebarNavMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatemain--ml-sidebar-nav-brutal {
  display: block;
  height: 100%;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-surface: #ffffff;
  --ml-surface-dim: #eeeeee;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-radius-sm: 0;
  --ml-disabled-opacity: 0.4;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupnavigatemain--ml-sidebar-nav-brutal .transition,
groupnavigatemain--ml-sidebar-nav-brutal .transition-all,
groupnavigatemain--ml-sidebar-nav-brutal .transition-transform {
  transition: none;
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-border {
  border-color: var(--ml-outline-variant, #000000);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-border.border-r {
  border-right-width: var(--ml-border-width, 3px);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-border.border-b {
  border-bottom-width: var(--ml-border-width, 3px);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-border.border-t {
  border-top-width: var(--ml-border-width, 3px);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-text-faint {
  color: var(--ml-on-surface, #000000);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-text-faint.tracking-wider {
  color: #666666;
  font-weight: 700;
}
groupnavigatemain--ml-sidebar-nav-brutal .hover\:ml-text-muted.tracking-wider:hover {
  color: #000000;
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-primary-text {
  color: #ffffff;
}
groupnavigatemain--ml-sidebar-nav-brutal .hover\:ml-surface-dim-bg:hover {
  background: var(--ml-surface-dim, #eeeeee);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #eeeeee);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-surface-dim-bg.h-px {
  background: #000000;
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-surface-dim-bg.rounded-md {
  border: 2px solid #000000;
}
groupnavigatemain--ml-sidebar-nav-brutal .animate-pulse .ml-surface-dim-bg.rounded {
  border: 2px solid #cccccc;
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-primary-dim-bg {
  background: var(--ml-primary, #3b82f6);
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-primary-dim-bg.rounded-full {
  background: #000000;
  color: #ffffff;
  border: 2px solid #000000;
}
groupnavigatemain--ml-sidebar-nav-brutal button[aria-current='page'] .ml-primary-dim-bg.rounded-full {
  background: #ffffff;
  color: #000000;
}
groupnavigatemain--ml-sidebar-nav-brutal button[aria-current='page'] .ml-surface-dim-bg.rounded-md {
  background: rgba(255, 255, 255, 0.2);
  border-color: #ffffff;
  color: #ffffff;
}
groupnavigatemain--ml-sidebar-nav-brutal .ml-error-dim-bg {
  background: var(--ml-error, #ef4444);
  border: 2px solid #000000;
}
groupnavigatemain--ml-sidebar-nav-brutal button[aria-disabled] {
  border-radius: var(--ml-radius-sm, 0);
  border: none;
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnavigatemain--ml-sidebar-nav-brutal button[aria-disabled='true'] {
  opacity: var(--ml-disabled-opacity, 0.4);
  border-color: #999999;
}
groupnavigatemain--ml-sidebar-nav-brutal button:focus-visible {
  outline: var(--ml-border-width, 3px) solid #000000;
  outline-offset: 2px;
}
`);
    }
};
MlSidebarNavBrutal = __decorate([
    customElement('groupnavigatemain--ml-sidebar-nav-brutal')
], MlSidebarNavBrutal);
export { MlSidebarNavBrutal };
