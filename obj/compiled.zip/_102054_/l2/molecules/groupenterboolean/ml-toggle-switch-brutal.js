var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TOGGLE SWITCH — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterBoolean
// Herda toda a lógica de ToggleSwitchMolecule (mls-102040) e sobrescreve apenas
// o render() com o template brutal. Aparência no .less escopado na tag -brutal.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ToggleSwitchMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.js';
/// **collab_i18n_start**
const message_en = { yes: 'Yes', no: 'No' };
const messages = {
    en: message_en,
    pt: { yes: 'Sim', no: 'Não' },
};
let ToggleSwitchBrutal = class ToggleSwitchBrutal extends ToggleSwitchMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-toggle-switch-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-view {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-helper {
  color: #666;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-track {
  border-radius: 0;
  background: #e5e5e5;
  border: 3px solid #000;
  cursor: pointer;
  transition: none;
  box-shadow: 2px 2px 0 #000;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-track:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-track.is-on {
  background: #3b82f6;
  border-color: #000;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-track.is-error {
  border-color: #ef4444;
  box-shadow: 2px 2px 0 #ef4444;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-track.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  border-color: #999;
  box-shadow: 2px 2px 0 #999;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-thumb {
  border-radius: 0;
  background: #000;
  box-shadow: none;
  transform: translateX(0.2rem);
  transition: none;
}
groupenterboolean--ml-toggle-switch-brutal .brutal-tg-thumb.is-on {
  background: #fff;
  transform: translateX(1.7rem);
}
`);
        this.gMsg = messages.en;
        this.gUid = `tg-brutal-${Math.random().toString(36).slice(2, 9)}`;
    }
    get internals() {
        return this;
    }
    brutalLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id=${labelId || ''} class="brutal-tg-label mb-2 text-sm">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </div>`;
    }
    brutalHelper(helperId) {
        if (!this.hasSlot('Helper') || this.error)
            return html ``;
        return html `<div id=${helperId || ''} class="brutal-helper mt-2 text-xs">
      ${unsafeHTML(this.getSlotContent('Helper'))}
    </div>`;
    }
    brutalError(errorId) {
        if (!this.error)
            return html ``;
        return html `<div id=${errorId || ''} class="brutal-error-text mt-2 text-xs">
      ${unsafeHTML(String(this.error))}
    </div>`;
    }
    brutalTrackClasses() {
        return [
            'brutal-tg-track relative inline-flex h-7 w-14 items-center',
            this.value ? 'is-on' : '',
            this.error ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalThumbClasses() {
        return ['brutal-tg-thumb inline-block h-5 w-5', this.value ? 'is-on' : ''].filter(Boolean).join(' ');
    }
    brutalViewMode() {
        const labelId = this.hasSlot('Label') ? `${this.gUid}-label` : undefined;
        const viewValue = this.value ? this.gMsg.yes : this.gMsg.no;
        return html `
      <div class="w-full">
        ${this.brutalLabel(labelId)}
        <div class="brutal-tg-view text-sm">${viewValue}</div>
      </div>
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (!this.isEditing) {
            return this.brutalViewMode();
        }
        const labelId = this.hasSlot('Label') ? `${this.gUid}-label` : undefined;
        const helperId = this.hasSlot('Helper') ? `${this.gUid}-helper` : undefined;
        const errorId = this.error ? `${this.gUid}-error` : undefined;
        const describedBy = this.error ? errorId : helperId;
        const self = this.internals;
        return html `
      <div class="w-full">
        ${this.brutalLabel(labelId)}
        <button
          type="button"
          class=${this.brutalTrackClasses()}
          role="switch"
          aria-checked=${this.value ? 'true' : 'false'}
          aria-labelledby=${labelId || undefined}
          aria-describedby=${describedBy || undefined}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-disabled=${this.disabled ? 'true' : 'false'}
          ?disabled=${this.disabled}
          tabindex=${this.disabled ? -1 : 0}
          @click=${() => self.handleToggle()}
          @focus=${() => self.handleFocus()}
          @blur=${() => self.handleBlur()}
          @keydown=${(e) => self.handleKeydown(e)}
        >
          <span class=${this.brutalThumbClasses()}></span>
        </button>
        ${this.brutalError(errorId)}
        ${this.brutalHelper(helperId)}
      </div>
    `;
    }
};
ToggleSwitchBrutal = __decorate([
    customElement('groupenterboolean--ml-toggle-switch-brutal')
], ToggleSwitchBrutal);
export { ToggleSwitchBrutal };
