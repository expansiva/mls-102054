var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterboolean/ml-toggle-switch.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
// =============================================================================
// TOGGLE SWITCH MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupEnterBoolean
// Mesma molécula/contrato do mls-102040. A aparência (vidro) vive no .less,
// escopada sob a tag. Este projeto implementa apenas o modelo glassmorphism.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    yes: 'Yes',
    no: 'No',
};
const messages = {
    en: message_en,
    pt: {
        yes: 'Sim',
        no: 'Não',
    },
};
/// **collab_i18n_end**
let ToggleSwitchMolecule = class ToggleSwitchMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-toggle-switch {
  display: block;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
}
groupenterboolean--ml-toggle-switch .glass-label {
  display: block;
  margin-bottom: 0.5rem;
  font-size: 0.8rem;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.92);
}
groupenterboolean--ml-toggle-switch .glass-helper {
  margin-top: 0.5rem;
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.7);
}
groupenterboolean--ml-toggle-switch .glass-error-text {
  margin-top: 0.5rem;
  font-size: 0.72rem;
  color: #ffb4ab;
}
groupenterboolean--ml-toggle-switch .glass-view-value {
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.92);
}
groupenterboolean--ml-toggle-switch .glass-track {
  position: relative;
  display: inline-flex;
  align-items: center;
  width: 2.75rem;
  height: 1.5rem;
  padding: 0 0.1875rem;
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 9999px;
  background: rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  cursor: pointer;
  transition: background 300ms ease, border-color 300ms ease, box-shadow 300ms ease;
  appearance: none;
  outline: none;
}
groupenterboolean--ml-toggle-switch .glass-track.is-on {
  background: rgba(99, 102, 241, 0.55);
  border-color: rgba(255, 255, 255, 0.4);
}
groupenterboolean--ml-toggle-switch .glass-track.is-error {
  border-color: rgba(255, 120, 120, 0.75);
}
groupenterboolean--ml-toggle-switch .glass-track.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenterboolean--ml-toggle-switch .glass-track:focus-visible {
  box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.5), 0 4px 16px rgba(0, 0, 0, 0.18);
}
groupenterboolean--ml-toggle-switch .glass-track-highlight {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.55);
  border-left: 1px solid rgba(255, 255, 255, 0.3);
  pointer-events: none;
}
groupenterboolean--ml-toggle-switch .glass-thumb {
  position: relative;
  z-index: 1;
  width: 1rem;
  height: 1rem;
  border-radius: 9999px;
  background: rgba(255, 255, 255, 0.92);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  transform: translateX(0);
  transition: transform 300ms cubic-bezier(0.2, 0.8, 0.2, 1);
}
groupenterboolean--ml-toggle-switch .glass-track.is-on .glass-thumb {
  transform: translateX(1.25rem);
}
`);
        this.msg = messages.en;
        this.uid = `toggle-${Math.random().toString(36).slice(2, 9)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = false;
        this.error = '';
        this.name = '';
        this.isEditing = true;
        this.disabled = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle() {
        if (!this.isEditing || this.disabled)
            return;
        this.value = !this.value;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    handleFocus() {
        if (!this.isEditing || this.disabled)
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true, detail: {} }));
    }
    handleBlur() {
        if (!this.isEditing || this.disabled)
            return;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true, detail: {} }));
    }
    handleKeydown(event) {
        if (!this.isEditing || this.disabled)
            return;
        if (event.key === ' ' || event.key === 'Spacebar' || event.key === 'Enter') {
            event.preventDefault();
            this.handleToggle();
        }
    }
    // ===========================================================================
    // RENDER HELPERS  (aparência via classes locais definidas no .less)
    // ===========================================================================
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id=${labelId || ''} class="glass-label">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderHelper(helperId) {
        if (!this.hasSlot('Helper') || this.error)
            return html ``;
        return html `<div id=${helperId || ''} class="glass-helper">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
    }
    renderError(errorId) {
        if (!this.error)
            return html ``;
        return html `<div id=${errorId || ''} class="glass-error-text">${unsafeHTML(String(this.error))}</div>`;
    }
    renderViewMode() {
        const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;
        const viewValue = this.value ? this.msg.yes : this.msg.no;
        return html `
      <div class="w-full">
        ${this.renderLabel(labelId)}
        <div class="glass-view-value">${viewValue}</div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;
        const helperId = this.hasSlot('Helper') ? `${this.uid}-helper` : undefined;
        const errorId = this.error ? `${this.uid}-error` : undefined;
        const describedBy = this.error ? errorId : helperId;
        const trackClasses = [
            'glass-track',
            this.value ? 'is-on' : '',
            this.error ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
        return html `
      <div class="w-full">
        ${this.renderLabel(labelId)}
        <button
          type="button"
          class=${trackClasses}
          role="switch"
          aria-checked=${this.value ? 'true' : 'false'}
          aria-labelledby=${labelId || undefined}
          aria-describedby=${describedBy || undefined}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-disabled=${this.disabled ? 'true' : 'false'}
          ?disabled=${this.disabled}
          tabindex=${this.disabled ? -1 : 0}
          @click=${this.handleToggle}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          @keydown=${this.handleKeydown}
        >
          <span class="glass-track-highlight" aria-hidden="true"></span>
          <span class="glass-thumb"></span>
        </button>
        ${this.renderError(errorId)}
        ${this.renderHelper(helperId)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], ToggleSwitchMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], ToggleSwitchMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], ToggleSwitchMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], ToggleSwitchMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'disabled' })
], ToggleSwitchMolecule.prototype, "disabled", void 0);
ToggleSwitchMolecule = __decorate([
    customElement('groupenterboolean--ml-toggle-switch')
], ToggleSwitchMolecule);
export { ToggleSwitchMolecule };
