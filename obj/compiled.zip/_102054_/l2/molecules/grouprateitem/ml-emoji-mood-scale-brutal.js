var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// EMOJI MOOD SCALE — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupRateItem
// Herda toda a lógica de EmojiMoodScaleMolecule (mls-102040) e sobrescreve apenas
// o render() com o template brutal. Aparência no .less escopado na tag -brutal.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { EmojiMoodScaleMolecule } from '/_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale.js';
/// **collab_i18n_start**
const message_en = {
    empty: '—',
    required: 'Required',
};
const messages = {
    en: message_en,
};
let EmojiMoodScaleBrutal = class EmojiMoodScaleBrutal extends EmojiMoodScaleMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-emoji-mood-scale-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-label {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-helper {
  color: #666;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-empty {
  color: #999;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-box {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-box:focus-within {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-box.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-box.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-option {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  cursor: pointer;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-option:hover:not(.is-static) {
  background: #eee;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-option:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-option.is-active {
  background: #3b82f6;
  border-color: #000;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-option.is-static {
  cursor: default;
}
grouprateitem--ml-emoji-mood-scale-brutal .brutal-em-view {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000;
}
`);
        this.gMsg = messages.en;
    }
    get internals() {
        return this;
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id="${this.internals.uid}-label" class="brutal-em-label mb-2 text-sm font-bold">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </div>`;
    }
    brutalHelperOrError() {
        const errorMessage = this.internals.getErrorMessage();
        if (errorMessage) {
            return html `<div id="${this.internals.uid}-error" class="brutal-error-text mt-2 text-xs">${unsafeHTML(errorMessage)}</div>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<div id="${this.internals.uid}-helper" class="brutal-helper mt-2 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
        }
        return html ``;
    }
    brutalContainerClasses() {
        return [
            'brutal-em-box w-full p-3',
            this.internals.getHasError() ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalOptionClasses(isActive, isSelected) {
        return [
            'brutal-em-option flex items-center justify-center px-3 py-2 text-xl',
            isActive || isSelected ? 'is-active' : '',
            this.disabled || this.readonly ? 'is-static' : '',
        ].filter(Boolean).join(' ');
    }
    brutalOption(item, index, activeValue) {
        const self = this.internals;
        const isSelected = this.value === item.value;
        const isActive = activeValue === item.value;
        const ariaChecked = isSelected ? 'true' : 'false';
        const label = `Rating ${item.value}`;
        const tabIndex = !this.disabled && !this.readonly && (isSelected || (this.value === null && index === 0)) ? 0 : -1;
        return html `
      <div
        class="${this.brutalOptionClasses(isActive, isSelected)}"
        role="radio"
        aria-checked="${ariaChecked}"
        aria-label="${label}"
        tabindex="${tabIndex}"
        data-index="${index}"
        @focus="${() => self.handleOptionFocus(index)}"
        @blur="${() => self.handleOptionBlur()}"
        @mouseenter="${() => self.handleMouseEnter(item.value)}"
        @mouseleave="${() => self.handleMouseLeave()}"
        @click="${() => self.handleOptionClick(item.value)}"
      >
        ${unsafeHTML(item.label)}
      </div>
    `;
    }
    brutalViewMode(items) {
        const selected = items.find((i) => i.value === this.value);
        return html `
      <div class="flex items-center gap-3">
        ${selected
            ? html `<div class="brutal-em-view px-3 py-2 text-xl">${unsafeHTML(selected.label)}</div>`
            : html `<div class="brutal-em-empty">${this.gMsg.empty}</div>`}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const self = this.internals;
        const items = self.getItems();
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${this.brutalLabel()}
          ${this.brutalViewMode(items)}
        </div>
      `;
        }
        const activeValue = self.getActiveValue();
        const hasError = self.getHasError();
        const describedBy = hasError ? `${self.uid}-error` : this.hasSlot('Helper') ? `${self.uid}-helper` : '';
        return html `
      <div
        class="${this.brutalContainerClasses()}"
        role="radiogroup"
        aria-labelledby="${this.hasSlot('Label') ? `${self.uid}-label` : ''}"
        aria-describedby="${describedBy}"
        aria-invalid="${hasError ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        @keydown="${(e) => self.handleKeydown(e, items)}"
        @mouseleave="${() => self.handleMouseLeave()}"
      >
        ${this.brutalLabel()}
        <div class="flex items-center gap-2">
          ${items.map((item, index) => this.brutalOption(item, index, activeValue))}
        </div>
        ${this.brutalHelperOrError()}
      </div>
    `;
    }
};
EmojiMoodScaleBrutal = __decorate([
    customElement('grouprateitem--ml-emoji-mood-scale-brutal')
], EmojiMoodScaleBrutal);
export { EmojiMoodScaleBrutal };
