var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// EMOJI MOOD SCALE — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de EmojiMoodScaleMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { EmojiMoodScaleMolecule } from '/_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale.js';
let EmojiMoodScaleBrutal = class EmojiMoodScaleBrutal extends EmojiMoodScaleMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-emoji-mood-scale-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-surface: #ffffff;
  --ml-surface-dim: #ffffff;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-label {
  font-family: var(--ml-font-family, monospace);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-helper {
  color: #666666;
  font-family: var(--ml-font-family, monospace);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-text-muted {
  color: #999999;
  font-family: var(--ml-font-family, monospace);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-surface {
  background: var(--ml-surface, #ffffff);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-focus-within:focus-within {
  outline: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  outline-offset: 2px;
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-border {
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-border-error {
  border: var(--ml-border-width, 3px) solid var(--ml-error, #ef4444);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: 3px 3px 0 var(--ml-error, #ef4444);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-surface.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-mood-option:hover {
  background: #eeeeee;
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-mood-option-selected {
  background: var(--ml-primary, #3b82f6);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-focus-ring:focus-visible {
  outline: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  outline-offset: 2px;
}
grouprateitem--ml-emoji-mood-scale-brutal .ml-border:not([role]) {
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
}
`);
    }
};
EmojiMoodScaleBrutal = __decorate([
    customElement('grouprateitem--ml-emoji-mood-scale-brutal')
], EmojiMoodScaleBrutal);
export { EmojiMoodScaleBrutal };
