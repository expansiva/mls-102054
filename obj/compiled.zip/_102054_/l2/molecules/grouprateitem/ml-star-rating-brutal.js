var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouprateitem/ml-star-rating-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// STAR RATING — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupRateItem
// Herda toda a lógica de MlStarRatingMolecule (mls-102040) e sobrescreve apenas
// o render() com o template brutal. Aparência no .less escopado na tag -brutal.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlStarRatingMolecule } from '/_102040_/l2/molecules/grouprateitem/ml-star-rating.js';
let StarRatingBrutal = class StarRatingBrutal extends MlStarRatingMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-star-rating-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-label {
  color: #000;
  display: block;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
grouprateitem--ml-star-rating-brutal .brutal-helper {
  color: #666;
}
grouprateitem--ml-star-rating-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-empty {
  color: #999;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-box {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  width: fit-content;
  box-shadow: 3px 3px 0 #000;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-box:focus-within {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-box.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-box.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-option {
  background: transparent;
  border: none;
  border-radius: 0;
  cursor: pointer;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-option:hover:not(.is-disabled) {
  background: #eee;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-option:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-option.is-selected {
  background: #eee;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-option.is-disabled {
  cursor: not-allowed;
  opacity: 0.4;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-star {
  color: #ccc;
}
grouprateitem--ml-star-rating-brutal .brutal-sr-star.is-active {
  color: #000;
}
`);
    }
    get internals() {
        return this;
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.internals.getLabelId() || ''}" class="brutal-sr-label mb-1 text-sm font-bold">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    brutalHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.internals.getHelpId() || ''}" class="brutal-error-text mt-1 text-xs">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.internals.getHelpId() || ''}" class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalHiddenInput() {
        if (!this.name)
            return html ``;
        const val = this.value === null || this.value === undefined ? '' : String(this.value);
        return html `<input type="hidden" name="${this.name}" value="${val}" />`;
    }
    brutalStarIcon(isActive) {
        const iconClasses = ['brutal-sr-star w-5 h-5', isActive ? 'is-active' : ''].filter(Boolean).join(' ');
        return html `
      <svg class="${iconClasses}" viewBox="0 0 20 20" aria-hidden="true">
        ${svg `<path fill="currentColor" d="M10 15.27l-5.18 3.05 1.64-5.81L1 7.97l6.02-.52L10 2l2.98 5.45 6.02.52-5.46 4.54 1.64 5.81z" />`}
      </svg>
    `;
    }
    brutalOption(item, activeValue, isTabbable) {
        const self = this.internals;
        const isActive = self.isItemActive(item.value, activeValue);
        const isSelected = this.value === item.value;
        const optionClasses = [
            'brutal-sr-option inline-flex items-center justify-center p-1',
            this.disabled ? 'is-disabled' : '',
            isSelected ? 'is-selected' : '',
        ].filter(Boolean).join(' ');
        const ariaChecked = isSelected ? 'true' : 'false';
        const label = item.label ? item.label : `Rating ${item.value}`;
        return html `
      <button
        class="${optionClasses}"
        type="button"
        role="radio"
        aria-checked="${ariaChecked}"
        aria-label="${label}"
        data-role="rating-option"
        data-value="${item.value}"
        ?disabled="${this.disabled}"
        ?tabindex="${isTabbable}"
        @focus="${() => self.handleOptionFocus()}"
        @blur="${() => self.handleOptionBlur()}"
        @mouseenter="${() => self.handleOptionMouseEnter(item.value)}"
        @mouseleave="${() => self.handleOptionMouseLeave()}"
        @click="${() => self.handleOptionClick(item.value)}"
        @keydown="${(e) => self.handleOptionKeydown(e, item.value)}"
      >
        ${item.label ? html `${unsafeHTML(item.label)}` : this.brutalStarIcon(isActive)}
      </button>
    `;
    }
    brutalEditMode(items) {
        const self = this.internals;
        const activeValue = self.getActiveValue();
        const labelId = self.getLabelId();
        const helpId = self.getHelpId();
        const isInvalid = self.getIsInvalid();
        const containerClasses = [
            'brutal-sr-box flex items-center gap-1 px-2 py-1',
            isInvalid ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
        const defaultTabValue = this.value !== null ? this.value : (items[0]?.value ?? 0);
        return html `
      <div
        class="${containerClasses}"
        role="radiogroup"
        aria-labelledby="${labelId || ''}"
        aria-describedby="${helpId || ''}"
        aria-invalid="${isInvalid ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        @mouseleave="${() => self.handleOptionMouseLeave()}"
      >
        ${items.map((item) => this.brutalOption(item, activeValue, item.value === defaultTabValue))}
      </div>
      ${this.brutalHiddenInput()}
      ${this.brutalHelperOrError()}
    `;
    }
    brutalViewMode(items) {
        const self = this.internals;
        const labelId = self.getLabelId();
        const selected = items.find((i) => i.value === this.value);
        const content = this.value === null
            ? html `<span class="brutal-sr-empty">—</span>`
            : selected && selected.label
                ? html `${unsafeHTML(selected.label)}`
                : html `
          <div class="flex items-center gap-1" aria-labelledby="${labelId || ''}">
            ${items.map((item) => this.brutalStarIcon(self.isItemActive(item.value, this.value)))}
          </div>
        `;
        return html `
      <div class="flex items-center gap-2">
        ${content}
        ${this.brutalHiddenInput()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const items = this.internals.getRatingItems();
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        ${this.isEditing ? this.brutalEditMode(items) : this.brutalViewMode(items)}
      </div>
    `;
    }
};
StarRatingBrutal = __decorate([
    customElement('grouprateitem--ml-star-rating-brutal')
], StarRatingBrutal);
export { StarRatingBrutal };
