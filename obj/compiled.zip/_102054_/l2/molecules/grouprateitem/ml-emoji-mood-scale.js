var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// EMOJI MOOD SCALE MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupRateItem
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    empty: '—',
    required: 'Required',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let moodScaleId = 0;
let EmojiMoodScaleMolecule = class EmojiMoodScaleMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-emoji-mood-scale {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
grouprateitem--ml-emoji-mood-scale .glass-em-label {
  color: rgba(255, 255, 255, 0.7);
}
grouprateitem--ml-emoji-mood-scale .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
grouprateitem--ml-emoji-mood-scale .glass-error-text {
  color: #ffb4ab;
}
grouprateitem--ml-emoji-mood-scale .glass-em-empty {
  color: rgba(255, 255, 255, 0.45);
}
grouprateitem--ml-emoji-mood-scale .glass-em-box {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
grouprateitem--ml-emoji-mood-scale .glass-em-box:focus-within {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
}
grouprateitem--ml-emoji-mood-scale .glass-em-box.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
grouprateitem--ml-emoji-mood-scale .glass-em-box.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
grouprateitem--ml-emoji-mood-scale .glass-em-option {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 10px;
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, transform 0.12s ease;
}
grouprateitem--ml-emoji-mood-scale .glass-em-option:hover:not(.is-static) {
  background: rgba(255, 255, 255, 0.12);
  transform: translateY(-1px);
}
grouprateitem--ml-emoji-mood-scale .glass-em-option:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
grouprateitem--ml-emoji-mood-scale .glass-em-option.is-active {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
}
grouprateitem--ml-emoji-mood-scale .glass-em-option.is-static {
  cursor: default;
}
grouprateitem--ml-emoji-mood-scale .glass-em-view {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 10px;
}
`);
        this.msg = messages.en;
        this.uid = `mood-scale-${moodScaleId++}`;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.hoverValue = null;
        this.focusedIndex = -1;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleOptionClick(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.value = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleOptionFocus(index) {
        if (!this.isEditing)
            return;
        this.focusedIndex = index;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleOptionBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleMouseEnter(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = value;
    }
    handleMouseLeave() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    handleKeydown(e, items) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        if (items.length === 0)
            return;
        const currentIndex = this.focusedIndex >= 0 ? this.focusedIndex : this.getSelectedIndex(items);
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            const nextIndex = (currentIndex + 1) % items.length;
            this.focusItem(nextIndex);
            return;
        }
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            const prevIndex = (currentIndex - 1 + items.length) % items.length;
            this.focusItem(prevIndex);
            return;
        }
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            const index = currentIndex >= 0 ? currentIndex : 0;
            const item = items[index];
            if (item)
                this.handleOptionClick(item.value);
        }
    }
    focusItem(index) {
        const el = this.querySelector(`[data-index="${index}"]`);
        if (el) {
            this.focusedIndex = index;
            el.focus();
        }
    }
    // ==========================================================================
    // DATA HELPERS
    // ==========================================================================
    getSelectedIndex(items) {
        if (this.value === null)
            return 0;
        const idx = items.findIndex((i) => i.value === this.value);
        return idx >= 0 ? idx : 0;
    }
    getItems() {
        if (this.hasSlot('Item')) {
            return this.getSlots('Item').map((el) => ({
                value: Number(el.getAttribute('value')),
                label: el.innerHTML,
            }));
        }
        const items = [];
        for (let v = this.min; v <= this.max; v += this.step) {
            items.push({ value: v, label: String(v) });
        }
        return items;
    }
    getActiveValue() {
        return this.hoverValue !== null ? this.hoverValue : this.value;
    }
    getHasError() {
        return Boolean(this.getErrorMessage());
    }
    getErrorMessage() {
        if (this.error && this.error.trim() !== '')
            return this.error;
        if (this.required && this.value === null)
            return this.msg.required;
        return '';
    }
    // ==========================================================================
    // RENDER HELPERS (glass)
    // ==========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id="${this.uid}-label" class="glass-em-label mb-2 text-sm font-medium">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </div>`;
    }
    renderHelperOrError() {
        const errorMessage = this.getErrorMessage();
        if (errorMessage) {
            return html `<div id="${this.uid}-error" class="glass-error-text mt-2 text-xs">${unsafeHTML(errorMessage)}</div>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<div id="${this.uid}-helper" class="glass-helper mt-2 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
        }
        return html ``;
    }
    getContainerClasses() {
        return [
            'glass-em-box w-full p-3',
            this.getHasError() ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionClasses(isActive, isSelected) {
        return [
            'glass-em-option flex items-center justify-center px-3 py-2 text-xl',
            isActive || isSelected ? 'is-active' : '',
            this.disabled || this.readonly ? 'is-static' : '',
        ].filter(Boolean).join(' ');
    }
    renderOption(item, index, activeValue) {
        const isSelected = this.value === item.value;
        const isActive = activeValue === item.value;
        const ariaChecked = isSelected ? 'true' : 'false';
        const label = `Rating ${item.value}`;
        const tabIndex = !this.disabled && !this.readonly && (isSelected || (this.value === null && index === 0)) ? 0 : -1;
        return html `
      <div
        class="${this.getOptionClasses(isActive, isSelected)}"
        role="radio"
        aria-checked="${ariaChecked}"
        aria-label="${label}"
        tabindex="${tabIndex}"
        data-index="${index}"
        @focus="${() => this.handleOptionFocus(index)}"
        @blur="${this.handleOptionBlur}"
        @mouseenter="${() => this.handleMouseEnter(item.value)}"
        @mouseleave="${this.handleMouseLeave}"
        @click="${() => this.handleOptionClick(item.value)}"
      >
        ${unsafeHTML(item.label)}
      </div>
    `;
    }
    renderViewMode(items) {
        const selected = items.find((i) => i.value === this.value);
        return html `
      <div class="flex items-center gap-3">
        ${selected
            ? html `<div class="glass-em-view px-3 py-2 text-xl">${unsafeHTML(selected.label)}</div>`
            : html `<div class="glass-em-empty">${this.msg.empty}</div>`}
      </div>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.getItems();
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${this.renderLabel()}
          ${this.renderViewMode(items)}
        </div>
      `;
        }
        const activeValue = this.getActiveValue();
        const hasError = this.getHasError();
        const describedBy = hasError ? `${this.uid}-error` : this.hasSlot('Helper') ? `${this.uid}-helper` : '';
        return html `
      <div
        class="${this.getContainerClasses()}"
        role="radiogroup"
        aria-labelledby="${this.hasSlot('Label') ? `${this.uid}-label` : ''}"
        aria-describedby="${describedBy}"
        aria-invalid="${hasError ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        @keydown="${(e) => this.handleKeydown(e, items)}"
        @mouseleave="${this.handleMouseLeave}"
      >
        ${this.renderLabel()}
        <div class="flex items-center gap-2">
          ${items.map((item, index) => this.renderOption(item, index, activeValue))}
        </div>
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], EmojiMoodScaleMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EmojiMoodScaleMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EmojiMoodScaleMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EmojiMoodScaleMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EmojiMoodScaleMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EmojiMoodScaleMolecule.prototype, "required", void 0);
__decorate([
    state()
], EmojiMoodScaleMolecule.prototype, "hoverValue", void 0);
__decorate([
    state()
], EmojiMoodScaleMolecule.prototype, "focusedIndex", void 0);
EmojiMoodScaleMolecule = __decorate([
    customElement('grouprateitem--ml-emoji-mood-scale')
], EmojiMoodScaleMolecule);
export { EmojiMoodScaleMolecule };
