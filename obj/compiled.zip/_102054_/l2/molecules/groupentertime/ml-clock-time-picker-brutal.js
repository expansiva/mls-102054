var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CLOCK TIME PICKER — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: enter + time
// Herda toda a lógica de ClockTimePickerMolecule (mls-102040): parsing de hora,
// stages hour/minute/second, 12/24h + AM/PM, minute step, range min/max,
// confirm/clear, outside-click e estado reativo (isOpen/stage/selected*/amPm).
// Sobrescreve apenas render()/painel com classes brutal. A formatação de exibição
// é refeita localmente (i18n próprio) para não depender do `msg` privado do pai.
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { ClockTimePickerMolecule } from '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select time',
    loading: 'Loading...',
    clear: 'Clear',
    confirm: 'Confirm',
    hour: 'Hour',
    minute: 'Minute',
    second: 'Second',
    am: 'AM',
    pm: 'PM',
    emptyView: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecionar hora',
        loading: 'Carregando...',
        clear: 'Limpar',
        confirm: 'Confirmar',
        hour: 'Hora',
        minute: 'Minuto',
        second: 'Segundo',
        am: 'AM',
        pm: 'PM',
        emptyView: '—',
    },
};
let ClockTimePickerBrutal = class ClockTimePickerBrutal extends ClockTimePickerMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertime--ml-clock-time-picker-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  display: block;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-req {
  color: #ef4444;
}
groupentertime--ml-clock-time-picker-brutal .brutal-helper {
  color: #666;
}
groupentertime--ml-clock-time-picker-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-view {
  color: #000;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-loading {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-step {
  color: #000;
  font-weight: 700;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-input {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  outline: none;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-input::placeholder {
  color: #999;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-input:focus {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-input.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-input.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-clock {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 1.25rem;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-clock:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-panel {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 6px 6px 0 #000;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-option {
  border-radius: 0;
  border: 2px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  font-weight: 700;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-option:hover:not(.is-disabled):not(.is-selected) {
  background: #f0f0f0;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-option.is-selected {
  background: #000;
  border-color: #000;
  color: #fff;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-option.is-disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-ampm {
  border-radius: 0;
  border: 2px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-ampm.is-active {
  background: #000;
  border-color: #000;
  color: #fff;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-clear {
  background: #fff;
  border: 2px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-clear:hover {
  background: #000;
  color: #fff;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-clear:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-confirm {
  border-radius: 0;
  border: 2px solid #000;
  background: #3b82f6;
  color: #fff;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-confirm:hover {
  background: #2563eb;
}
groupentertime--ml-clock-time-picker-brutal .brutal-tp-confirm:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
`);
        this.bMsg = messages.en;
    }
    get x() {
        return this;
    }
    // --- formatação de exibição (própria, i18n local) ---
    brutalFormatTime(value) {
        if (!value)
            return this.bMsg.emptyView;
        const parsed = this.x.parseTime(value);
        if (!parsed)
            return this.bMsg.emptyView;
        const locale = this.locale || undefined;
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        };
        const date = new Date();
        date.setHours(parsed.hour, parsed.minute, parsed.second || 0, 0);
        return new Intl.DateTimeFormat(locale, options).format(date);
    }
    brutalStepLabel() {
        if (this.x.stage === 'hour')
            return this.bMsg.hour;
        if (this.x.stage === 'minute')
            return this.bMsg.minute;
        return this.bMsg.second;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalInputClasses() {
        const hasError = !!this.error;
        return [
            'brutal-tp-input w-full px-3 py-2 text-sm',
            hasError ? 'is-error' : '',
            this.disabled || this.readonly ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalOptionClasses(selected, disabled) {
        return [
            'brutal-tp-option w-10 h-10 flex items-center justify-center text-sm',
            selected ? 'is-selected' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const requiredMark = this.required ? html `<span class="brutal-tp-req">*</span>` : nothing;
        return html `
      <label class="brutal-tp-label mb-1 text-sm font-medium">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${requiredMark}
      </label>
    `;
    }
    brutalHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.x.getErrorId()}" class="brutal-error-text mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.x.getHelperId()}" class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalClockOptions() {
        const x = this.x;
        if (x.stage === 'hour') {
            const hours = x.getHourOptions();
            return html `
        <div class="grid grid-cols-6 gap-2">
          ${hours.map((h) => {
                const hour24 = this.hour12 ? x.convertTo24Hour(h, x.amPm) : h;
                const selected = x.selectedHour === hour24;
                const disabled = x.isHourDisabled(h);
                return html `
              <button class="${this.brutalOptionClasses(selected, disabled)}" ?disabled=${disabled} @click=${() => x.onSelectHour(h)} aria-label="${h}">
                ${String(h).padStart(2, '0')}
              </button>
            `;
            })}
        </div>
      `;
        }
        if (x.stage === 'minute') {
            const minutes = x.getMinuteOptions();
            return html `
        <div class="grid grid-cols-6 gap-2">
          ${minutes.map((m) => {
                const selected = x.selectedMinute === m;
                const disabled = x.isMinuteDisabled(x.selectedHour, m);
                return html `
              <button class="${this.brutalOptionClasses(selected, disabled)}" ?disabled=${disabled} @click=${() => x.onSelectMinute(m)} aria-label="${m}">
                ${String(m).padStart(2, '0')}
              </button>
            `;
            })}
        </div>
      `;
        }
        const seconds = x.getSecondOptions();
        return html `
      <div class="grid grid-cols-6 gap-2">
        ${seconds.map((s) => {
            const selected = x.selectedSecond === s;
            const disabled = x.isSecondDisabled(x.selectedHour, x.selectedMinute, s);
            return html `
            <button class="${this.brutalOptionClasses(selected, disabled)}" ?disabled=${disabled} @click=${() => x.onSelectSecond(s)} aria-label="${s}">
              ${String(s).padStart(2, '0')}
            </button>
          `;
        })}
      </div>
    `;
    }
    brutalAmPm() {
        const x = this.x;
        if (!this.hour12)
            return html ``;
        const amClasses = ['brutal-tp-ampm px-3 py-1 text-xs', x.amPm === 'AM' ? 'is-active' : ''].filter(Boolean).join(' ');
        const pmClasses = ['brutal-tp-ampm px-3 py-1 text-xs', x.amPm === 'PM' ? 'is-active' : ''].filter(Boolean).join(' ');
        return html `
      <div class="flex items-center gap-2">
        <button class="${amClasses}" @click=${() => x.onToggleAmPm('AM')}>${this.bMsg.am}</button>
        <button class="${pmClasses}" @click=${() => x.onToggleAmPm('PM')}>${this.bMsg.pm}</button>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — lógica/estado herdados via this.x
    // ===========================================================================
    render() {
        const x = this.x;
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${this.brutalLabel()}
          <div class="brutal-tp-view text-sm">${this.brutalFormatTime(this.value)}</div>
        </div>
      `;
        }
        const displayValue = this.value ? this.brutalFormatTime(this.value) : '';
        const placeholder = this.placeholder || this.bMsg.placeholder;
        const ariaDescribedBy = this.error ? x.getErrorId() : (this.hasSlot('Helper') ? x.getHelperId() : undefined);
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        <div class="relative">
          <input
            class="${this.brutalInputClasses()}"
            name="${this.name}"
            .value=${displayValue}
            placeholder="${placeholder}"
            readonly
            @click=${() => x.onToggleOpen()}
            @focus=${() => x.onInputFocus()}
            @blur=${() => x.onInputBlur()}
            aria-invalid=${this.error ? 'true' : 'false'}
            aria-required=${this.required ? 'true' : 'false'}
            aria-describedby=${ariaDescribedBy || nothing}
            aria-labelledby=${this.hasSlot('Label') ? x.getLabelId() : nothing}
            aria-label=${displayValue || placeholder}
          />
          <button
            class="brutal-tp-clock absolute right-2 top-1/2 -translate-y-1/2"
            @click=${() => x.onToggleOpen()}
            ?disabled=${!x.canInteract()}
            aria-label="${this.bMsg.hour}"
          >
            &#9200;
          </button>
        </div>

        ${this.loading ? html `<div class="brutal-tp-loading mt-2 text-xs">${this.bMsg.loading}</div>` : nothing}

        ${x.isOpen && !this.loading
            ? html `
              <div class="brutal-tp-panel mt-2 p-3" role="dialog" aria-modal="true">
                <div class="flex items-center justify-between mb-3">
                  <span class="brutal-tp-step text-xs uppercase tracking-wide">${this.brutalStepLabel()}</span>
                  ${this.brutalAmPm()}
                </div>
                ${this.brutalClockOptions()}
                <div class="mt-3 flex items-center justify-between">
                  <button class="brutal-tp-clear text-xs" @click=${() => x.onClear()}>${this.bMsg.clear}</button>
                  <button class="brutal-tp-confirm px-3 py-1 text-xs" @click=${() => x.onConfirm()}>${this.bMsg.confirm}</button>
                </div>
              </div>
            `
            : nothing}

        ${this.brutalHelperOrError()}
      </div>
    `;
    }
};
ClockTimePickerBrutal = __decorate([
    customElement('groupentertime--ml-clock-time-picker-brutal')
], ClockTimePickerBrutal);
export { ClockTimePickerBrutal };
