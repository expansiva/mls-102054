var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CLOCK TIME PICKER — BRUTALISM (mls-102054)
// =============================================================================
// Skill Group: enter + time
// Casca (estratégia D): herda tudo de ClockTimePickerMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// brutal vem do .less irmão, escopado sob esta tag. Sem portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ClockTimePickerMolecule } from '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker.js';
let ClockTimePickerBrutal = class ClockTimePickerBrutal extends ClockTimePickerMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertime--ml-clock-time-picker-brutal {
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 6px 6px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupentertime--ml-clock-time-picker-brutal .ml-label {
  display: block;
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertime--ml-clock-time-picker-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupentertime--ml-clock-time-picker-brutal p.ml-error-text {
  font-weight: 700;
  text-transform: uppercase;
}
groupentertime--ml-clock-time-picker-brutal .ml-helper {
  color: #666;
}
groupentertime--ml-clock-time-picker-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupentertime--ml-clock-time-picker-brutal div.ml-text-muted {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertime--ml-clock-time-picker-brutal span.ml-text-muted {
  color: var(--ml-on-surface, #000000);
  font-weight: 700;
}
groupentertime--ml-clock-time-picker-brutal button.ml-text-muted {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 1.25rem;
  color: var(--ml-on-surface, #000000);
  transition: none;
}
groupentertime--ml-clock-time-picker-brutal button.ml-text-muted:disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker-brutal .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: 3px 3px 0 #000000;
  transition: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  outline: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
}
groupentertime--ml-clock-time-picker-brutal .ml-input:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupentertime--ml-clock-time-picker-brutal .ml-input-container-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupentertime--ml-clock-time-picker-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-input-container.ml-disabled {
  border-color: #999;
  box-shadow: 3px 3px 0 #999;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 6px 6px 0 #000000);
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-number {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border: 2px solid #000000;
  border-radius: var(--ml-radius-sm, 0);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: 700;
  transition: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-number:hover:not(.ml-disabled):not(.ml-clock-number-selected) {
  background: var(--ml-surface-dim, #f0f0f0);
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-number-selected {
  background: #000000;
  border-color: #000000;
  color: #ffffff;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-number.ml-disabled {
  opacity: 0.3;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-ampm {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border: 2px solid #000000;
  border-radius: var(--ml-radius-sm, 0);
  cursor: pointer;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: 700;
  text-transform: uppercase;
  transition: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-ampm-selected {
  background: #000000;
  border-color: #000000;
  color: #ffffff;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-action {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border: 2px solid #000000;
  border-radius: var(--ml-radius-sm, 0);
  cursor: pointer;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-action:hover {
  background: #000000;
  color: #ffffff;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-action:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-confirm {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border: 2px solid #000000;
  border-radius: var(--ml-radius-sm, 0);
  cursor: pointer;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-confirm:hover {
  background: #2563eb;
}
groupentertime--ml-clock-time-picker-brutal .ml-clock-confirm:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
`);
    }
};
ClockTimePickerBrutal = __decorate([
    customElement('groupentertime--ml-clock-time-picker-brutal')
], ClockTimePickerBrutal);
export { ClockTimePickerBrutal };
