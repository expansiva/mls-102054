var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertime/ml-clock-time-picker.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CLOCK TIME PICKER MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: enter + time
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select time',
    loading: 'Loading...',
    clear: 'Clear',
    confirm: 'Confirm',
    hour: 'Hour',
    minute: 'Minute',
    second: 'Second',
    am: 'AM',
    pm: 'PM',
    emptyView: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecionar hora',
        loading: 'Carregando...',
        clear: 'Limpar',
        confirm: 'Confirmar',
        hour: 'Hora',
        minute: 'Minuto',
        second: 'Segundo',
        am: 'AM',
        pm: 'PM',
        emptyView: '—',
    },
};
/// **collab_i18n_end**
let ClockTimePickerMolecule = class ClockTimePickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertime--ml-clock-time-picker {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupentertime--ml-clock-time-picker .glass-tp-label {
  color: rgba(255, 255, 255, 0.7);
  display: block;
}
groupentertime--ml-clock-time-picker .glass-tp-req {
  color: #ffb4ab;
}
groupentertime--ml-clock-time-picker .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupentertime--ml-clock-time-picker .glass-error-text {
  color: #ffb4ab;
}
groupentertime--ml-clock-time-picker .glass-tp-view {
  color: #fff;
}
groupentertime--ml-clock-time-picker .glass-tp-loading {
  color: rgba(255, 255, 255, 0.6);
}
groupentertime--ml-clock-time-picker .glass-tp-step {
  color: rgba(255, 255, 255, 0.6);
}
groupentertime--ml-clock-time-picker .glass-tp-input {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  color: #fff;
  outline: none;
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupentertime--ml-clock-time-picker .glass-tp-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupentertime--ml-clock-time-picker .glass-tp-input:focus {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
}
groupentertime--ml-clock-time-picker .glass-tp-input.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupentertime--ml-clock-time-picker .glass-tp-input.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker .glass-tp-clock {
  background: transparent;
  border: none;
  cursor: pointer;
}
groupentertime--ml-clock-time-picker .glass-tp-clock:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker .glass-tp-panel {
  background: rgba(30, 27, 75, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 14px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
}
groupentertime--ml-clock-time-picker .glass-tp-option {
  border-radius: 9999px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.06);
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupentertime--ml-clock-time-picker .glass-tp-option:hover:not(.is-disabled):not(.is-selected) {
  background: rgba(255, 255, 255, 0.12);
}
groupentertime--ml-clock-time-picker .glass-tp-option.is-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupentertime--ml-clock-time-picker .glass-tp-option.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker .glass-tp-ampm {
  border-radius: 8px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.06);
  color: rgba(255, 255, 255, 0.85);
  cursor: pointer;
}
groupentertime--ml-clock-time-picker .glass-tp-ampm.is-active {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupentertime--ml-clock-time-picker .glass-tp-clear {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
}
groupentertime--ml-clock-time-picker .glass-tp-clear:hover {
  color: #fff;
}
groupentertime--ml-clock-time-picker .glass-tp-confirm {
  border-radius: 8px;
  border: 1px solid rgba(199, 210, 254, 0.6);
  background: rgba(129, 140, 248, 0.85);
  color: #fff;
  cursor: pointer;
  transition: background 0.12s ease;
}
groupentertime--ml-clock-time-picker .glass-tp-confirm:hover {
  background: #818cf8;
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Helper'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.isOpen = false;
        this.stage = 'hour';
        this.selectedHour = null;
        this.selectedMinute = null;
        this.selectedSecond = null;
        this.amPm = 'AM';
        this.onOutsideClick = (e) => {
            const path = e.composedPath();
            if (!path.includes(this)) {
                this.isOpen = false;
                this.detachOutsideClick();
            }
        };
    }
    // =========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.syncSelectionFromValue(value);
        }
        this.requestUpdate();
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.syncSelectionFromValue(this.value);
    }
    disconnectedCallback() {
        this.detachOutsideClick();
        super.disconnectedCallback();
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    onToggleOpen() {
        if (!this.canInteract())
            return;
        if (this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.stage = 'hour';
            this.attachOutsideClick();
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
        else {
            this.detachOutsideClick();
        }
    }
    onInputFocus() {
        if (!this.canInteract())
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    onInputBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    onSelectHour(hour) {
        if (!this.canInteract())
            return;
        if (this.isHourDisabled(hour))
            return;
        const normalized = this.hour12 ? this.convertTo24Hour(hour, this.amPm) : hour;
        this.selectedHour = normalized;
        this.stage = 'minute';
    }
    onSelectMinute(minute) {
        if (!this.canInteract())
            return;
        if (this.isMinuteDisabled(this.selectedHour, minute))
            return;
        this.selectedMinute = minute;
        if (this.showSeconds) {
            this.stage = 'second';
        }
    }
    onSelectSecond(second) {
        if (!this.canInteract())
            return;
        if (this.isSecondDisabled(this.selectedHour, this.selectedMinute, second))
            return;
        this.selectedSecond = second;
    }
    onConfirm() {
        if (!this.canInteract())
            return;
        if (!this.isSelectionComplete())
            return;
        const value = this.buildValueString();
        this.value = value;
        this.isOpen = false;
        this.detachOutsideClick();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
    }
    onClear() {
        if (!this.canInteract())
            return;
        this.value = null;
        this.selectedHour = null;
        this.selectedMinute = null;
        this.selectedSecond = null;
        this.stage = 'hour';
        this.isOpen = false;
        this.detachOutsideClick();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: null },
        }));
    }
    onToggleAmPm(value) {
        if (!this.canInteract())
            return;
        this.amPm = value;
        if (this.selectedHour !== null) {
            const displayHour = this.convertTo12Hour(this.selectedHour).hour;
            this.selectedHour = this.convertTo24Hour(displayHour, value);
        }
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    canInteract() {
        return this.isEditing && !this.disabled && !this.readonly && !this.loading;
    }
    syncSelectionFromValue(value) {
        if (!value) {
            this.selectedHour = null;
            this.selectedMinute = null;
            this.selectedSecond = null;
            return;
        }
        const parsed = this.parseTime(value);
        if (!parsed)
            return;
        this.selectedHour = parsed.hour;
        this.selectedMinute = parsed.minute;
        this.selectedSecond = parsed.second;
        if (this.hour12) {
            this.amPm = parsed.hour >= 12 ? 'PM' : 'AM';
        }
    }
    parseTime(value) {
        const parts = value.split(':').map((p) => Number(p));
        if (parts.length < 2)
            return null;
        const hour = parts[0];
        const minute = parts[1];
        const second = parts.length > 2 ? parts[2] : null;
        if (Number.isNaN(hour) || Number.isNaN(minute))
            return null;
        return { hour, minute, second };
    }
    formatTime(value) {
        if (!value)
            return this.msg.emptyView;
        const parsed = this.parseTime(value);
        if (!parsed)
            return this.msg.emptyView;
        const locale = this.locale || undefined;
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        };
        const date = new Date();
        date.setHours(parsed.hour, parsed.minute, parsed.second || 0, 0);
        return new Intl.DateTimeFormat(locale, options).format(date);
    }
    buildValueString() {
        if (!this.isSelectionComplete())
            return null;
        const h = String(this.selectedHour).padStart(2, '0');
        const m = String(this.selectedMinute).padStart(2, '0');
        if (this.showSeconds) {
            const s = String(this.selectedSecond ?? 0).padStart(2, '0');
            return `${h}:${m}:${s}`;
        }
        return `${h}:${m}`;
    }
    isSelectionComplete() {
        if (this.selectedHour === null || this.selectedMinute === null)
            return false;
        if (this.showSeconds && this.selectedSecond === null)
            return false;
        return true;
    }
    convertTo24Hour(hour12, amPm) {
        if (amPm === 'AM')
            return hour12 === 12 ? 0 : hour12;
        return hour12 === 12 ? 12 : hour12 + 12;
    }
    convertTo12Hour(hour24) {
        const period = hour24 >= 12 ? 'PM' : 'AM';
        const hour = hour24 % 12 || 12;
        return { hour, period };
    }
    attachOutsideClick() {
        document.addEventListener('mousedown', this.onOutsideClick);
    }
    detachOutsideClick() {
        document.removeEventListener('mousedown', this.onOutsideClick);
    }
    isHourDisabled(hour) {
        const hour24 = this.hour12 ? this.convertTo24Hour(hour, this.amPm) : hour;
        if (!this.minTime && !this.maxTime)
            return false;
        const min = this.parseTime(this.minTime || '');
        const max = this.parseTime(this.maxTime || '');
        if (!min && !max)
            return false;
        if (min && hour24 < min.hour)
            return true;
        if (max && hour24 > max.hour)
            return true;
        if (min && max && hour24 === min.hour && hour24 === max.hour) {
            return this.getMinuteOptions().every((m) => this.isMinuteDisabled(hour24, m));
        }
        return false;
    }
    isMinuteDisabled(hour, minute) {
        if (hour === null)
            return false;
        const min = this.parseTime(this.minTime || '');
        const max = this.parseTime(this.maxTime || '');
        if (!min && !max)
            return false;
        if (min && hour === min.hour && minute < min.minute)
            return true;
        if (max && hour === max.hour && minute > max.minute)
            return true;
        return false;
    }
    isSecondDisabled(hour, minute, second) {
        if (hour === null || minute === null)
            return false;
        const min = this.parseTime(this.minTime || '');
        const max = this.parseTime(this.maxTime || '');
        if (!min && !max)
            return false;
        if (min && hour === min.hour && minute === min.minute && second < (min.second || 0))
            return true;
        if (max && hour === max.hour && minute === max.minute && second > (max.second || 0))
            return true;
        return false;
    }
    getHourOptions() {
        if (this.hour12) {
            return Array.from({ length: 12 }, (_, i) => i + 1);
        }
        return Array.from({ length: 24 }, (_, i) => i);
    }
    getMinuteOptions() {
        const step = Math.max(1, this.minuteStep || 1);
        const list = [];
        for (let i = 0; i < 60; i += step)
            list.push(i);
        return list;
    }
    getSecondOptions() {
        return Array.from({ length: 60 }, (_, i) => i);
    }
    // =========================================================================
    // CLASS HELPERS (glass)
    // =========================================================================
    getInputClasses() {
        const hasError = !!this.error;
        return [
            'glass-tp-input w-full px-3 py-2 text-sm',
            hasError ? 'is-error' : '',
            this.disabled || this.readonly ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionClasses(selected, disabled) {
        return [
            'glass-tp-option w-10 h-10 flex items-center justify-center text-sm',
            selected ? 'is-selected' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return 'glass-tp-panel mt-2 p-3';
    }
    getLabelClasses() {
        return 'glass-tp-label mb-1 text-sm font-medium';
    }
    getStepLabel() {
        if (this.stage === 'hour')
            return this.msg.hour;
        if (this.stage === 'minute')
            return this.msg.minute;
        return this.msg.second;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const requiredMark = this.required ? html `<span class="glass-tp-req">*</span>` : nothing;
        return html `
      <label class="${this.getLabelClasses()}">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${requiredMark}
      </label>
    `;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.getErrorId()}" class="glass-error-text mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.getHelperId()}" class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderClockOptions() {
        if (this.stage === 'hour') {
            const hours = this.getHourOptions();
            return html `
        <div class="grid grid-cols-6 gap-2">
          ${hours.map((h) => {
                const hour24 = this.hour12 ? this.convertTo24Hour(h, this.amPm) : h;
                const selected = this.selectedHour === hour24;
                const disabled = this.isHourDisabled(h);
                return html `
              <button class="${this.getOptionClasses(selected, disabled)}" ?disabled=${disabled} @click=${() => this.onSelectHour(h)} aria-label="${h}">
                ${String(h).padStart(2, '0')}
              </button>
            `;
            })}
        </div>
      `;
        }
        if (this.stage === 'minute') {
            const minutes = this.getMinuteOptions();
            return html `
        <div class="grid grid-cols-6 gap-2">
          ${minutes.map((m) => {
                const selected = this.selectedMinute === m;
                const disabled = this.isMinuteDisabled(this.selectedHour, m);
                return html `
              <button class="${this.getOptionClasses(selected, disabled)}" ?disabled=${disabled} @click=${() => this.onSelectMinute(m)} aria-label="${m}">
                ${String(m).padStart(2, '0')}
              </button>
            `;
            })}
        </div>
      `;
        }
        const seconds = this.getSecondOptions();
        return html `
      <div class="grid grid-cols-6 gap-2">
        ${seconds.map((s) => {
            const selected = this.selectedSecond === s;
            const disabled = this.isSecondDisabled(this.selectedHour, this.selectedMinute, s);
            return html `
            <button class="${this.getOptionClasses(selected, disabled)}" ?disabled=${disabled} @click=${() => this.onSelectSecond(s)} aria-label="${s}">
              ${String(s).padStart(2, '0')}
            </button>
          `;
        })}
      </div>
    `;
    }
    renderAmPm() {
        if (!this.hour12)
            return html ``;
        const amClasses = ['glass-tp-ampm px-3 py-1 text-xs', this.amPm === 'AM' ? 'is-active' : ''].filter(Boolean).join(' ');
        const pmClasses = ['glass-tp-ampm px-3 py-1 text-xs', this.amPm === 'PM' ? 'is-active' : ''].filter(Boolean).join(' ');
        return html `
      <div class="flex items-center gap-2">
        <button class="${amClasses}" @click=${() => this.onToggleAmPm('AM')}>${this.msg.am}</button>
        <button class="${pmClasses}" @click=${() => this.onToggleAmPm('PM')}>${this.msg.pm}</button>
      </div>
    `;
    }
    getLabelId() {
        return `${this.tagName.toLowerCase()}-label`;
    }
    getHelperId() {
        return `${this.tagName.toLowerCase()}-helper`;
    }
    getErrorId() {
        return `${this.tagName.toLowerCase()}-error`;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${this.renderLabel()}
          <div class="glass-tp-view text-sm">${this.formatTime(this.value)}</div>
        </div>
      `;
        }
        const displayValue = this.value ? this.formatTime(this.value) : '';
        const placeholder = this.placeholder || this.msg.placeholder;
        const ariaDescribedBy = this.error ? this.getErrorId() : (this.hasSlot('Helper') ? this.getHelperId() : undefined);
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        <div class="relative">
          <input
            class="${this.getInputClasses()}"
            name="${this.name}"
            .value=${displayValue}
            placeholder="${placeholder}"
            readonly
            @click=${this.onToggleOpen}
            @focus=${this.onInputFocus}
            @blur=${this.onInputBlur}
            aria-invalid=${this.error ? 'true' : 'false'}
            aria-required=${this.required ? 'true' : 'false'}
            aria-describedby=${ariaDescribedBy || nothing}
            aria-labelledby=${this.hasSlot('Label') ? this.getLabelId() : nothing}
            aria-label=${displayValue || placeholder}
          />
          <button
            class="glass-tp-clock absolute right-2 top-1/2 -translate-y-1/2"
            @click=${this.onToggleOpen}
            ?disabled=${!this.canInteract()}
            aria-label="${this.msg.hour}"
          >
            🕒
          </button>
        </div>

        ${this.loading ? html `<div class="glass-tp-loading mt-2 text-xs">${this.msg.loading}</div>` : nothing}

        ${this.isOpen && !this.loading
            ? html `
              <div class="${this.getPanelClasses()}" role="dialog" aria-modal="true">
                <div class="flex items-center justify-between mb-3">
                  <span class="glass-tp-step text-xs uppercase tracking-wide">${this.getStepLabel()}</span>
                  ${this.renderAmPm()}
                </div>
                ${this.renderClockOptions()}
                <div class="mt-3 flex items-center justify-between">
                  <button class="glass-tp-clear text-xs" @click=${this.onClear}>${this.msg.clear}</button>
                  <button class="glass-tp-confirm px-3 py-1 text-xs" @click=${this.onConfirm}>${this.msg.confirm}</button>
                </div>
              </div>
            `
            : nothing}

        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], ClockTimePickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], ClockTimePickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], ClockTimePickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], ClockTimePickerMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], ClockTimePickerMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], ClockTimePickerMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], ClockTimePickerMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], ClockTimePickerMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], ClockTimePickerMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], ClockTimePickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], ClockTimePickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ClockTimePickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ClockTimePickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ClockTimePickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ClockTimePickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], ClockTimePickerMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], ClockTimePickerMolecule.prototype, "stage", void 0);
__decorate([
    state()
], ClockTimePickerMolecule.prototype, "selectedHour", void 0);
__decorate([
    state()
], ClockTimePickerMolecule.prototype, "selectedMinute", void 0);
__decorate([
    state()
], ClockTimePickerMolecule.prototype, "selectedSecond", void 0);
__decorate([
    state()
], ClockTimePickerMolecule.prototype, "amPm", void 0);
ClockTimePickerMolecule = __decorate([
    customElement('groupentertime--ml-clock-time-picker')
], ClockTimePickerMolecule);
export { ClockTimePickerMolecule };
