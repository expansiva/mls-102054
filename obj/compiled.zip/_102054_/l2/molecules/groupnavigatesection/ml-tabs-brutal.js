var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TABS — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSection
// Herda MlTabsMolecule (mls-102040): parse de slots Tab, tab ativa, roving
// tabindex, click/keyboard e estado (uid). Sobrescreve apenas render() e os
// helpers de aparência (brutal-prefix).
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlTabsMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-tabs.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No tabs available',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhuma aba disponível',
    },
};
let MlTabsBrutal = class MlTabsBrutal extends MlTabsMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-tabs-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupnavigatesection--ml-tabs-brutal .brutal-nav-label {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupnavigatesection--ml-tabs-brutal .brutal-tablist {
  border-bottom: 3px solid #000;
}
groupnavigatesection--ml-tabs-brutal .brutal-tab {
  border: 3px solid #000;
  border-bottom: none;
  background: #eee;
  color: #000;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-right: -3px;
}
groupnavigatesection--ml-tabs-brutal .brutal-tab.is-active {
  background: #000;
  color: #fff;
}
groupnavigatesection--ml-tabs-brutal .brutal-tab:not(.is-active):not(.is-disabled):hover {
  background: #ddd;
}
groupnavigatesection--ml-tabs-brutal .brutal-tab:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupnavigatesection--ml-tabs-brutal .brutal-tab.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupnavigatesection--ml-tabs-brutal .brutal-tab-panel {
  border-radius: 0;
  border: 3px solid #000;
  border-top: none;
  background: #fff;
  color: #000;
  box-shadow: 3px 3px 0 #000;
}
groupnavigatesection--ml-tabs-brutal .brutal-nav-box {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #666;
  box-shadow: 3px 3px 0 #000;
}
groupnavigatesection--ml-tabs-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // HELPERS DE APARÊNCIA (brutal)
    // ===========================================================================
    brutalTabClasses(isActive, isDisabled) {
        return ['brutal-tab', 'inline-flex items-center gap-2 px-4 py-2 text-sm font-bold', isActive ? 'is-active' : '', isDisabled ? 'is-disabled' : '']
            .filter(Boolean)
            .join(' ');
    }
    brutalTabListClasses() {
        return 'brutal-tablist flex flex-wrap gap-0';
    }
    brutalPanelClasses() {
        return 'brutal-tab-panel mt-0 p-4';
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id="${this.x.uid}-label" class="brutal-nav-label mb-2 text-sm font-bold">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    brutalLoading() {
        return html `<div class="brutal-nav-box p-4 text-sm">${this.gMsg.loading}</div>`;
    }
    brutalError() {
        if (!this.error)
            return html ``;
        return html `<p class="brutal-error-text mt-2 text-xs">${unsafeHTML(String(this.error))}</p>`;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        if (this.loading) {
            return html `<div class="w-full">${this.brutalLabel()} ${this.brutalLoading()}</div>`;
        }
        const tabs = x.parseTabs();
        if (tabs.length === 0) {
            return html `
        <div class="w-full">${this.brutalLabel()}<div class="brutal-nav-box p-4 text-sm">${this.gMsg.empty}</div></div>
      `;
        }
        const activeValue = x.getActiveValue(tabs);
        const activeTab = tabs.find((t) => t.value === activeValue) || null;
        const labelId = this.hasSlot('Label') ? `${x.uid}-label` : undefined;
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        <div class="${this.brutalTabListClasses()}" role="tablist" aria-labelledby="${labelId || nothing}" @keydown="${(e) => x.handleKeyDown(e)}">
          ${tabs.map((tab) => {
            const isActive = tab.value === activeValue;
            const isDisabled = this.disabled || this.loading || tab.disabled;
            const tabId = `${x.uid}-tab-${x.toSafeId(tab.value)}`;
            const panelId = `${x.uid}-panel-${x.toSafeId(tab.value)}`;
            return html `
              <button
                id="${tabId}"
                data-tab-button
                data-value="${tab.value}"
                class="${this.brutalTabClasses(isActive, isDisabled)}"
                role="tab"
                type="button"
                aria-selected="${isActive ? 'true' : 'false'}"
                aria-disabled="${isDisabled ? 'true' : 'false'}"
                aria-controls="${panelId}"
                tabindex="${isActive ? '0' : '-1'}"
                @click="${() => x.handleTabClick(tab, activeValue)}"
              >
                ${tab.icon ? html `<span class="text-base">${unsafeHTML(tab.icon)}</span>` : nothing}
                <span>${unsafeHTML(tab.title)}</span>
              </button>
            `;
        })}
        </div>

        ${activeTab
            ? html `
              <div
                id="${x.uid}-panel-${x.toSafeId(activeTab.value)}"
                class="${this.brutalPanelClasses()}"
                role="tabpanel"
                aria-labelledby="${x.uid}-tab-${x.toSafeId(activeTab.value)}"
              >
                ${unsafeHTML(activeTab.content)}
              </div>
            `
            : html ``}
        ${this.brutalError()}
      </div>
    `;
    }
};
MlTabsBrutal = __decorate([
    customElement('groupnavigatesection--ml-tabs-brutal')
], MlTabsBrutal);
export { MlTabsBrutal };
