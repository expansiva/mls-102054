var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NAVIGATE PILLS — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSection
// Herda NavigatePillsMolecule (mls-102040): parse de slots Tab, índice ativo,
// click/keyboard e estado (instanceId/lastActiveIndex). Sobrescreve apenas
// render() e os helpers de aparência (brutal-prefix).
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { NavigatePillsMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
    },
};
let NavigatePillsBrutal = class NavigatePillsBrutal extends NavigatePillsMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-navigate-pills-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-nav-label {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-pill {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-pill.is-active {
  background: #000;
  color: #fff;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-pill:not(.is-disabled):not(.is-active):hover {
  background: #eee;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-pill:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-pill.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-pill-panel {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  box-shadow: 3px 3px 0 #000;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-nav-loading {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #666;
  box-shadow: 3px 3px 0 #000;
}
groupnavigatesection--ml-navigate-pills-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // HELPERS DE APARÊNCIA (brutal)
    // ===========================================================================
    brutalTabClasses(isActive, isDisabled) {
        return ['brutal-pill', 'flex items-center gap-2 px-4 py-2 text-sm font-bold whitespace-nowrap', isActive ? 'is-active' : '', isDisabled || this.disabled || this.loading ? 'is-disabled' : '']
            .filter(Boolean)
            .join(' ');
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        return html `<div class="brutal-nav-label mb-2 text-sm font-bold">${unsafeHTML(labelContent)}</div>`;
    }
    brutalLoading() {
        return html `
      <div class="space-y-2">
        ${this.brutalLabel()}
        <div class="brutal-nav-loading flex items-center gap-2 px-4 py-3 text-sm">${this.gMsg.loading}</div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        if (this.loading) {
            return this.brutalLoading();
        }
        const tabs = x.getTabs();
        const activeIndex = x.getActiveIndex(tabs);
        x.lastActiveIndex = activeIndex;
        const activeTab = activeIndex >= 0 ? tabs[activeIndex] : null;
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        <div
          class="flex gap-2 overflow-x-auto pb-1"
          role="tablist"
          aria-label="${this.hasSlot('Label') ? this.getSlotContent('Label') : 'Navigation'}"
        >
          ${tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const isDisabled = tab.disabled;
            const tabId = `${x.instanceId}-tab-${index}`;
            const panelId = `${x.instanceId}-panel-${index}`;
            return html `
              <button
                class="${this.brutalTabClasses(isActive, isDisabled)}"
                role="tab"
                aria-selected="${isActive ? 'true' : 'false'}"
                aria-disabled="${isDisabled || this.disabled || this.loading ? 'true' : 'false'}"
                aria-controls="${panelId}"
                id="${tabId}"
                data-tab-index="${index}"
                ?disabled=${isDisabled || this.disabled || this.loading}
                @click=${() => x.handleTabClick(tab)}
                @keydown=${(e) => x.handleKeyDown(e, index, tabs)}
              >
                ${tab.icon ? html `<span class="text-base">${unsafeHTML(tab.icon)}</span>` : html ``}
                <span>${unsafeHTML(tab.title)}</span>
              </button>
            `;
        })}
        </div>
        ${activeTab
            ? html `
              <div
                class="brutal-pill-panel mt-0 p-4"
                role="tabpanel"
                id="${x.instanceId}-panel-${activeIndex}"
                aria-labelledby="${x.instanceId}-tab-${activeIndex}"
              >
                ${unsafeHTML(activeTab.content)}
              </div>
            `
            : html ``}
        ${this.error ? html `<p class="brutal-error-text mt-2 text-xs">${unsafeHTML(this.error)}</p>` : html ``}
      </div>
    `;
    }
};
NavigatePillsBrutal = __decorate([
    customElement('groupnavigatesection--ml-navigate-pills-brutal')
], NavigatePillsBrutal);
export { NavigatePillsBrutal };
