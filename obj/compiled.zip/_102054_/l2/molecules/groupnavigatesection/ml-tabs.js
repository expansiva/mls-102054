/// <mls fileReference="_102054_/l2/molecules/groupnavigatesection/ml-tabs.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// GROUP NAVIGATE SECTION — TABS MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSection
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No tabs available',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhuma aba disponível',
    },
};
let MlTabsMolecule = class MlTabsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-tabs {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnavigatesection--ml-tabs .glass-nav-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesection--ml-tabs .glass-tablist {
  border-bottom: 1px solid rgba(255, 255, 255, 0.18);
}
groupnavigatesection--ml-tabs .glass-tab {
  border: none;
  border-bottom: 2px solid transparent;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: color 200ms ease, border-color 200ms ease;
  margin-bottom: -1px;
}
groupnavigatesection--ml-tabs .glass-tab.is-active {
  border-bottom-color: #c7d2fe;
  color: #fff;
}
groupnavigatesection--ml-tabs .glass-tab:not(.is-active):not(.is-disabled):hover {
  color: #fff;
}
groupnavigatesection--ml-tabs .glass-tab:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.5);
  border-radius: 6px;
}
groupnavigatesection--ml-tabs .glass-tab.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupnavigatesection--ml-tabs .glass-tab-panel {
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: rgba(255, 255, 255, 0.9);
}
groupnavigatesection--ml-tabs .glass-nav-box {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatesection--ml-tabs .glass-error-text {
  color: #ffb4ab;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Tab'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.uid = `tabs-${Math.random().toString(36).slice(2, 10)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTabClick(tab, activeValue) {
        if (this.disabled || this.loading || tab.disabled)
            return;
        if (activeValue === tab.value)
            return;
        this.value = tab.value;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: tab.value, title: tab.title } }));
    }
    handleKeyDown(event) {
        if (this.disabled || this.loading)
            return;
        const tabs = this.parseTabs();
        if (tabs.length === 0)
            return;
        const activeValue = this.getActiveValue(tabs);
        const enabledTabs = tabs.filter((t) => !t.disabled);
        if (enabledTabs.length === 0)
            return;
        const buttons = Array.from(this.querySelectorAll('[data-tab-button]'));
        const enabledButtons = buttons.filter((btn) => btn.getAttribute('aria-disabled') !== 'true');
        const currentIndexByFocus = enabledButtons.indexOf(document.activeElement);
        const currentIndexByActive = enabledTabs.findIndex((t) => t.value === activeValue);
        const currentIndex = currentIndexByFocus >= 0 ? currentIndexByFocus : currentIndexByActive;
        if (event.key === 'ArrowRight') {
            event.preventDefault();
            const nextIndex = (currentIndex + 1 + enabledButtons.length) % enabledButtons.length;
            enabledButtons[nextIndex]?.focus();
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            const prevIndex = (currentIndex - 1 + enabledButtons.length) % enabledButtons.length;
            enabledButtons[prevIndex]?.focus();
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            const focused = document.activeElement;
            if (!focused)
                return;
            const tabValue = focused.getAttribute('data-value');
            const tab = tabs.find((t) => t.value === tabValue);
            if (tab)
                this.handleTabClick(tab, activeValue);
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseTabs() {
        return this.getSlots('Tab').map((el) => ({
            value: el.getAttribute('value') || '',
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML,
        }));
    }
    getActiveValue(tabs) {
        if (tabs.length === 0)
            return null;
        const found = tabs.find((t) => t.value === this.value);
        if (found && !found.disabled)
            return found.value;
        const firstEnabled = tabs.find((t) => !t.disabled);
        return firstEnabled ? firstEnabled.value : null;
    }
    toSafeId(value) {
        return value.replace(/[^a-zA-Z0-9_-]/g, '-');
    }
    // aparência = classes glass; layout = Tailwind
    getTabClasses(isActive, isDisabled) {
        return [
            'glass-tab',
            'inline-flex items-center gap-2 px-4 py-2 text-sm font-medium',
            isActive ? 'is-active' : '',
            isDisabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getTabListClasses() {
        return 'glass-tablist flex flex-wrap gap-2';
    }
    getPanelClasses() {
        return 'glass-tab-panel mt-4 p-4';
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id="${this.uid}-label" class="glass-nav-label mb-2 text-sm font-semibold">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderLoading() {
        return html `<div class="glass-nav-box p-4 text-sm">${this.msg.loading}</div>`;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `<p class="glass-error-text mt-2 text-xs">${unsafeHTML(String(this.error))}</p>`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `<div class="w-full">${this.renderLabel()} ${this.renderLoading()}</div>`;
        }
        const tabs = this.parseTabs();
        if (tabs.length === 0) {
            return html `
        <div class="w-full">${this.renderLabel()}<div class="glass-nav-box p-4 text-sm">${this.msg.empty}</div></div>
      `;
        }
        const activeValue = this.getActiveValue(tabs);
        const activeTab = tabs.find((t) => t.value === activeValue) || null;
        const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        <div class="${this.getTabListClasses()}" role="tablist" aria-labelledby="${labelId || nothing}" @keydown="${this.handleKeyDown}">
          ${tabs.map((tab) => {
            const isActive = tab.value === activeValue;
            const isDisabled = this.disabled || this.loading || tab.disabled;
            const tabId = `${this.uid}-tab-${this.toSafeId(tab.value)}`;
            const panelId = `${this.uid}-panel-${this.toSafeId(tab.value)}`;
            return html `
              <button
                id="${tabId}"
                data-tab-button
                data-value="${tab.value}"
                class="${this.getTabClasses(isActive, isDisabled)}"
                role="tab"
                type="button"
                aria-selected="${isActive ? 'true' : 'false'}"
                aria-disabled="${isDisabled ? 'true' : 'false'}"
                aria-controls="${panelId}"
                tabindex="${isActive ? '0' : '-1'}"
                @click="${() => this.handleTabClick(tab, activeValue)}"
              >
                ${tab.icon ? html `<span class="text-base">${unsafeHTML(tab.icon)}</span>` : nothing}
                <span>${unsafeHTML(tab.title)}</span>
              </button>
            `;
        })}
        </div>

        ${activeTab
            ? html `
              <div
                id="${this.uid}-panel-${this.toSafeId(activeTab.value)}"
                class="${this.getPanelClasses()}"
                role="tabpanel"
                aria-labelledby="${this.uid}-tab-${this.toSafeId(activeTab.value)}"
              >
                ${unsafeHTML(activeTab.content)}
              </div>
            `
            : html ``}
        ${this.renderError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTabsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTabsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTabsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTabsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTabsMolecule.prototype, "uid", void 0);
MlTabsMolecule = __decorate([
    customElement('groupnavigatesection--ml-tabs')
], MlTabsMolecule);
export { MlTabsMolecule };
