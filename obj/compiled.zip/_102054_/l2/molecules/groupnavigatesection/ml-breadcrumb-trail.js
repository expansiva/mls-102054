var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BREADCRUMB TRAIL MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNavigateSection
// Mesma molécula/contrato do mls-102040. Lógica intacta (corrigido um typo de
// binding `@click` no item). Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    overflow: 'More levels',
};
const messages = {
    en: message_en,
};
let BreadcrumbTrailMolecule = class BreadcrumbTrailMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-breadcrumb-trail {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-label {
  color: rgba(255, 255, 255, 0.65);
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-item {
  border-radius: 8px;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.65);
  transition: background 150ms ease, color 150ms ease;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-item.is-active {
  color: #fff;
  font-weight: 500;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-item.is-interactive {
  cursor: pointer;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-item.is-interactive:hover {
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-item:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-item.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-sep {
  color: rgba(255, 255, 255, 0.4);
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-overflow-btn {
  border-radius: 8px;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.65);
  cursor: pointer;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-overflow-btn:hover {
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-overflow-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-menu {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(30, 27, 75, 0.85);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.45);
}
groupnavigatesection--ml-breadcrumb-trail .glass-bc-panel {
  color: rgba(255, 255, 255, 0.9);
}
groupnavigatesection--ml-breadcrumb-trail .glass-error-text {
  color: #ffb4ab;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Tab'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOverflowOpen = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.addEventListener('keydown', this.handleKeyDown);
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getTabs() {
        const elements = this.getSlots('Tab');
        return elements.map((el, index) => ({
            value: el.getAttribute('value') || '',
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML || '',
            index,
            isLast: index === elements.length - 1,
        }));
    }
    getActiveValue(tabs) {
        if (this.value && tabs.find((tab) => tab.value === this.value)) {
            return this.value;
        }
        const firstActive = tabs.find((tab) => !tab.disabled);
        return firstActive ? firstActive.value : tabs[0]?.value || null;
    }
    getTabClasses(isActive, disabled, interactive) {
        return [
            'glass-bc-item',
            'inline-flex items-center gap-1 px-1.5 py-0.5 text-sm whitespace-nowrap',
            isActive ? 'is-active' : '',
            interactive ? 'is-interactive' : '',
            disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getDelimiterClasses() {
        return 'glass-bc-sep mx-1 select-none';
    }
    getOverflowButtonClasses() {
        return [
            'glass-bc-overflow-btn',
            'inline-flex items-center px-1.5 py-0.5 text-sm whitespace-nowrap',
            this.disabled || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getPanelClasses() {
        return 'glass-bc-panel pt-2 text-sm';
    }
    getLabelClasses() {
        return 'glass-bc-label block text-xs font-medium mb-1';
    }
    getErrorClasses() {
        return 'glass-error-text pt-1 text-xs';
    }
    renderTab(tab, activeValue) {
        const isActive = tab.value === activeValue;
        const interactive = !tab.isLast && !tab.disabled && !this.disabled && !this.loading;
        if (tab.isLast) {
            return html `
        <span class="${this.getTabClasses(isActive, tab.disabled, false)}" role="tab" aria-selected="${isActive}" aria-disabled="true">
          ${tab.icon ? html `<span class="text-base">${tab.icon}</span>` : ''}
          <span>${tab.title}</span>
        </span>
      `;
        }
        return html `
      <button
        class="${this.getTabClasses(isActive, tab.disabled || this.disabled || this.loading, interactive)}"
        role="tab"
        aria-selected="${isActive}"
        aria-disabled="${tab.disabled || this.disabled || this.loading}"
        ?disabled=${tab.disabled || this.disabled || this.loading}
        data-tab-button="true"
        @click=${() => this.handleTabClick(tab)}
      >
        ${tab.icon ? html `<span class="text-base">${tab.icon}</span>` : ''}
        <span>${tab.title}</span>
      </button>
    `;
    }
    renderOverflowMenu(hiddenTabs, activeValue) {
        if (!hiddenTabs.length)
            return html ``;
        return html `
      <div class="relative inline-flex items-center">
        <button
          class="${this.getOverflowButtonClasses()}"
          aria-label="${this.msg.overflow}"
          ?disabled=${this.disabled || this.loading}
          @click=${this.handleOverflowToggle}
        >
          ...
        </button>
        ${this.isOverflowOpen
            ? html `
              <div class="glass-bc-menu absolute left-0 top-full mt-1 w-48 z-10">
                <div class="p-1">
                  ${hiddenTabs.map((tab) => html `
                      <button
                        class="${this.getTabClasses(tab.value === activeValue, tab.disabled || this.disabled || this.loading, !tab.disabled)} w-full justify-start"
                        role="tab"
                        aria-selected="${tab.value === activeValue}"
                        aria-disabled="${tab.disabled || this.disabled || this.loading}"
                        ?disabled=${tab.disabled || this.disabled || this.loading}
                        data-tab-button="true"
                        @click=${() => this.handleTabClick(tab, true)}
                      >
                        ${tab.icon ? html `<span class="text-base">${tab.icon}</span>` : ''}
                        <span>${tab.title}</span>
                      </button>
                    `)}
                </div>
              </div>
            `
            : ''}
      </div>
    `;
    }
    renderTrail(tabs, activeValue) {
        if (!tabs.length)
            return html ``;
        const first = tabs[0];
        const last = tabs[tabs.length - 1];
        const middle = tabs.slice(1, tabs.length - 1);
        return html `
      <div class="flex items-center whitespace-nowrap" role="tablist">
        <div class="flex items-center sm:hidden">
          ${this.renderTab(first, activeValue)}
          <span class="${this.getDelimiterClasses()}">/</span>
          ${this.renderOverflowMenu(middle, activeValue)}
          <span class="${this.getDelimiterClasses()}">/</span>
          ${this.renderTab(last, activeValue)}
        </div>
        <div class="hidden sm:flex items-center">
          ${tabs.map((tab, index) => html `
              ${index > 0 ? html `<span class="${this.getDelimiterClasses()}">/</span>` : ''} ${this.renderTab(tab, activeValue)}
            `)}
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTabClick(tab, closeOverflow = false) {
        if (this.loading || this.disabled)
            return;
        if (tab.disabled || tab.isLast)
            return;
        this.value = tab.value;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: tab.value, title: tab.title } }));
        if (closeOverflow) {
            this.isOverflowOpen = false;
        }
    }
    handleOverflowToggle() {
        if (this.loading || this.disabled)
            return;
        this.isOverflowOpen = !this.isOverflowOpen;
    }
    handleKeyDown(e) {
        if (this.loading || this.disabled)
            return;
        const keys = ['ArrowLeft', 'ArrowRight', 'Enter', ' '];
        if (!keys.includes(e.key))
            return;
        const buttons = Array.from(this.querySelectorAll('button[data-tab-button="true"]')).filter((btn) => !btn.disabled);
        if (!buttons.length)
            return;
        const current = document.activeElement;
        const currentIndex = buttons.findIndex((btn) => btn === current);
        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            e.preventDefault();
            const dir = e.key === 'ArrowRight' ? 1 : -1;
            const nextIndex = (currentIndex + dir + buttons.length) % buttons.length;
            buttons[nextIndex].focus();
        }
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            current?.click();
        }
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const tabs = this.getTabs();
        const activeValue = this.getActiveValue(tabs);
        const activeTab = tabs.find((tab) => tab.value === activeValue) || tabs[0];
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const activeContent = activeTab ? activeTab.content : '';
        return html `
      <div class="w-full">
        ${labelContent ? html `<span class="${this.getLabelClasses()}">${unsafeHTML(labelContent)}</span>` : ''}
        <div class="relative">
          ${this.loading ? html `<div class="glass-bc-muted text-sm">${this.msg.loading}</div>` : this.renderTrail(tabs, activeValue)}
        </div>
        <div class="${this.getPanelClasses()}" role="tabpanel">${activeContent ? unsafeHTML(activeContent) : ''}</div>
        ${this.error ? html `<div class="${this.getErrorClasses()}">${unsafeHTML(this.error)}</div>` : ''}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], BreadcrumbTrailMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], BreadcrumbTrailMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], BreadcrumbTrailMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], BreadcrumbTrailMolecule.prototype, "loading", void 0);
__decorate([
    state()
], BreadcrumbTrailMolecule.prototype, "isOverflowOpen", void 0);
BreadcrumbTrailMolecule = __decorate([
    customElement('groupnavigatesection--ml-breadcrumb-trail')
], BreadcrumbTrailMolecule);
export { BreadcrumbTrailMolecule };
