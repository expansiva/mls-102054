var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML VERTICAL CARD — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupViewCard
// Herda MlVerticalCardMolecule (mls-102040): estados (clickable/selected/disabled/
// loading), evento 'cardClick', modo de edicao propagado a filhos (lifecycle).
// Sobrescreve so render() + helpers presentacionais brutal.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlVerticalCardMolecule } from '/_102040_/l2/molecules/groupviewcard/ml-vertical-card.js';
let MlVerticalCardBrutal = class MlVerticalCardBrutal extends MlVerticalCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-vertical-card-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupviewcard--ml-vertical-card-brutal .brutal-card {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  box-shadow: 4px 4px 0 #000;
  color: #000;
}
groupviewcard--ml-vertical-card-brutal .brutal-card.is-interactive {
  cursor: pointer;
}
groupviewcard--ml-vertical-card-brutal .brutal-card.is-interactive:hover {
  box-shadow: 2px 2px 0 #000;
  transform: translate(2px, 2px);
}
groupviewcard--ml-vertical-card-brutal .brutal-card.is-interactive:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupviewcard--ml-vertical-card-brutal .brutal-card.is-selected {
  background: #dbeafe;
  border-color: #3b82f6;
  box-shadow: 4px 4px 0 #3b82f6;
}
groupviewcard--ml-vertical-card-brutal .brutal-card.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: 2px 2px 0 #999;
  border-color: #999;
}
groupviewcard--ml-vertical-card-brutal .brutal-card-text,
groupviewcard--ml-vertical-card-brutal .brutal-card-title {
  color: #000;
  text-transform: uppercase;
  font-weight: 900;
  letter-spacing: 0.03em;
}
groupviewcard--ml-vertical-card-brutal .brutal-card-desc {
  color: #555;
}
groupviewcard--ml-vertical-card-brutal .brutal-card-content {
  color: #333;
}
groupviewcard--ml-vertical-card-brutal .brutal-card-footer {
  color: #777;
}
groupviewcard--ml-vertical-card-brutal .brutal-card-action {
  border-top: 3px solid #000;
}
groupviewcard--ml-vertical-card-brutal .brutal-skeleton {
  border-radius: 0;
  background: #e5e5e5;
  border: 2px solid #ccc;
  animation: brutal-card-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-card-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
    }
    get x() {
        return this;
    }
    // ---- helpers presentacionais (brutal) ----
    brutalRootClasses() {
        return [
            'brutal-card',
            'w-full p-4 flex flex-col gap-4',
            this.selected ? 'is-selected' : '',
            this.x.isInteractive() ? 'is-interactive' : '',
            this.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalHeader() {
        const hasHeader = this.hasSlot('CardHeader');
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        if (!hasHeader && !hasTitle && !hasDescription) {
            return html ``;
        }
        if (hasHeader) {
            return html `<div class="flex flex-col gap-1 brutal-card-text">${unsafeHTML(this.getSlotContent('CardHeader'))}</div>`;
        }
        return html `
      <div class="flex flex-col gap-1">
        ${hasTitle ? html `<div class="brutal-card-title text-base font-bold">${unsafeHTML(this.getSlotContent('CardTitle'))}</div>` : html ``}
        ${hasDescription ? html `<div class="brutal-card-desc text-sm">${unsafeHTML(this.getSlotContent('CardDescription'))}</div>` : html ``}
      </div>
    `;
    }
    brutalContent() {
        if (!this.hasSlot('CardContent'))
            return html ``;
        return html `<div class="brutal-card-content text-sm">${unsafeHTML(this.getSlotContent('CardContent'))}</div>`;
    }
    brutalFooter() {
        if (!this.hasSlot('CardFooter'))
            return html ``;
        return html `<div class="brutal-card-footer text-xs">${unsafeHTML(this.getSlotContent('CardFooter'))}</div>`;
    }
    brutalAction() {
        if (!this.hasSlot('CardAction'))
            return html ``;
        return html `<div class="brutal-card-action pt-3">${unsafeHTML(this.getSlotContent('CardAction'))}</div>`;
    }
    brutalLoading() {
        return html `
      <div class="flex flex-col gap-4">
        <div class="brutal-skeleton h-4 w-2/3"></div>
        <div class="brutal-skeleton h-3 w-1/2"></div>
        <div class="brutal-skeleton h-20 w-full"></div>
        <div class="brutal-skeleton h-3 w-1/3"></div>
        <div class="brutal-skeleton h-9 w-28"></div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — logica/estado herdados via this.x
    // ===========================================================================
    render() {
        const x = this.x;
        const interactive = x.isInteractive();
        return html `
      <div
        class=${this.brutalRootClasses()}
        role=${ifDefined(interactive ? 'button' : undefined)}
        tabindex=${ifDefined(interactive ? '0' : undefined)}
        aria-disabled=${ifDefined(this.disabled ? 'true' : undefined)}
        aria-selected=${ifDefined(this.selected ? 'true' : undefined)}
        @click=${() => x.handleCardClick()}
        @keydown=${(e) => x.handleKeyDown(e)}
      >
        ${this.loading
            ? this.brutalLoading()
            : html ` ${this.brutalHeader()} ${this.brutalContent()} ${this.brutalFooter()} ${this.brutalAction()} `}
      </div>
    `;
    }
};
MlVerticalCardBrutal = __decorate([
    customElement('groupviewcard--ml-vertical-card-brutal')
], MlVerticalCardBrutal);
export { MlVerticalCardBrutal };
