var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewcard/ml-profile-card.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML PROFILE CARD MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupViewCard
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MlProfileCardMolecule = class MlProfileCardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-profile-card {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupviewcard--ml-profile-card .glass-card {
  position: relative;
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.09);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.28), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  color: rgba(255, 255, 255, 0.92);
  transition: background 200ms ease, border-color 200ms ease, transform 150ms ease;
}
groupviewcard--ml-profile-card .glass-card.is-interactive {
  cursor: pointer;
}
groupviewcard--ml-profile-card .glass-card.is-interactive:hover {
  background: rgba(255, 255, 255, 0.14);
  transform: translateY(-2px);
}
groupviewcard--ml-profile-card .glass-card.is-interactive:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.5);
}
groupviewcard--ml-profile-card .glass-card.is-selected {
  background: rgba(99, 102, 241, 0.34);
  border-color: rgba(199, 210, 254, 0.8);
}
groupviewcard--ml-profile-card .glass-card.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupviewcard--ml-profile-card .glass-card-text,
groupviewcard--ml-profile-card .glass-card-title {
  color: #fff;
}
groupviewcard--ml-profile-card .glass-card-desc {
  color: rgba(255, 255, 255, 0.68);
}
groupviewcard--ml-profile-card .glass-card-content {
  color: rgba(255, 255, 255, 0.88);
}
groupviewcard--ml-profile-card .glass-card-footer {
  color: rgba(255, 255, 255, 0.6);
}
groupviewcard--ml-profile-card .glass-skeleton {
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.12);
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        this.syncEditingAttribute();
    }
    updated(changedProperties) {
        if (changedProperties.has('isEditing')) {
            this.syncEditingAttribute();
        }
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleCardClick() {
        if (!this.isInteractive())
            return;
        this.dispatchEvent(new CustomEvent('cardClick', { bubbles: true, composed: true, detail: {} }));
    }
    handleCardKeydown(event) {
        if (!this.isInteractive())
            return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleCardClick();
        }
    }
    // ==========================================================================
    // HELPERS  (aparência = classes glass)
    // ==========================================================================
    isInteractive() {
        return this.clickable && !this.disabled && !this.loading;
    }
    getCardClasses() {
        return [
            'glass-card',
            'w-full p-4',
            this.selected ? 'is-selected' : '',
            this.isInteractive() ? 'is-interactive' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    syncEditingAttribute() {
        const elements = Array.from(this.querySelectorAll('*'));
        for (const el of elements) {
            if (!el.tagName.includes('-'))
                continue;
            if (this.isEditing) {
                el.setAttribute('is-editing', '');
            }
            else {
                el.removeAttribute('is-editing');
            }
        }
    }
    renderHeader() {
        const hasHeader = this.hasSlot('CardHeader');
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        if (!hasHeader && !hasTitle && !hasDescription)
            return nothing;
        if (hasHeader) {
            return html `<div class="card-header glass-card-text">${unsafeHTML(this.getSlotContent('CardHeader'))}</div>`;
        }
        return html `
      <div class="card-header">
        ${hasTitle ? html `<div class="glass-card-title text-lg font-semibold">${unsafeHTML(this.getSlotContent('CardTitle'))}</div>` : nothing}
        ${hasDescription ? html `<div class="glass-card-desc mt-1 text-sm">${unsafeHTML(this.getSlotContent('CardDescription'))}</div>` : nothing}
      </div>
    `;
    }
    renderContent() {
        if (!this.hasSlot('CardContent'))
            return nothing;
        return html `<div class="card-content glass-card-content">${unsafeHTML(this.getSlotContent('CardContent'))}</div>`;
    }
    renderFooter() {
        if (!this.hasSlot('CardFooter'))
            return nothing;
        return html `<div class="card-footer glass-card-footer">${unsafeHTML(this.getSlotContent('CardFooter'))}</div>`;
    }
    renderAction() {
        if (!this.hasSlot('CardAction'))
            return nothing;
        return html `<div class="card-action flex flex-wrap items-center gap-2">${unsafeHTML(this.getSlotContent('CardAction'))}</div>`;
    }
    renderLoadingSkeleton() {
        return html `
      <div class="animate-pulse space-y-4">
        <div class="space-y-2">
          <div class="glass-skeleton h-4 w-2/3"></div>
          <div class="glass-skeleton h-3 w-1/2"></div>
        </div>
        <div class="glass-skeleton h-16 w-full"></div>
        <div class="flex gap-2">
          <div class="glass-skeleton h-8 w-24"></div>
          <div class="glass-skeleton h-8 w-20"></div>
        </div>
      </div>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const roleAttr = this.isInteractive() ? 'button' : nothing;
        const tabIndexAttr = this.isInteractive() ? 0 : nothing;
        const ariaDisabled = this.disabled || this.loading ? 'true' : nothing;
        const ariaSelected = this.selected ? 'true' : nothing;
        return html `
      <div
        class="${this.getCardClasses()}"
        role=${roleAttr}
        tabindex=${tabIndexAttr}
        aria-disabled=${ariaDisabled}
        aria-selected=${ariaSelected}
        @click=${this.handleCardClick}
        @keydown=${this.handleCardKeydown}
      >
        ${this.loading
            ? this.renderLoadingSkeleton()
            : html `
              <div class="space-y-4">
                ${this.renderHeader()} ${this.renderContent()} ${this.renderFooter()} ${this.renderAction()}
              </div>
            `}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlProfileCardMolecule.prototype, "isEditing", void 0);
MlProfileCardMolecule = __decorate([
    customElement('groupviewcard--ml-profile-card')
], MlProfileCardMolecule);
export { MlProfileCardMolecule };
