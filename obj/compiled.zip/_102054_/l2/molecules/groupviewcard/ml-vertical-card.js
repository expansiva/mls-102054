var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewcard/ml-vertical-card.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML VERTICAL CARD MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupViewCard
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MlVerticalCardMolecule = class MlVerticalCardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-vertical-card {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupviewcard--ml-vertical-card .glass-card {
  position: relative;
  border-radius: 18px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.09);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.28), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  color: rgba(255, 255, 255, 0.92);
  transition: background 200ms ease, border-color 200ms ease, transform 150ms ease;
}
groupviewcard--ml-vertical-card .glass-card.is-interactive {
  cursor: pointer;
}
groupviewcard--ml-vertical-card .glass-card.is-interactive:hover {
  background: rgba(255, 255, 255, 0.14);
  transform: translateY(-2px);
}
groupviewcard--ml-vertical-card .glass-card.is-interactive:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.5);
}
groupviewcard--ml-vertical-card .glass-card.is-selected {
  background: rgba(99, 102, 241, 0.34);
  border-color: rgba(199, 210, 254, 0.8);
}
groupviewcard--ml-vertical-card .glass-card.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupviewcard--ml-vertical-card .glass-card-text,
groupviewcard--ml-vertical-card .glass-card-title {
  color: #fff;
}
groupviewcard--ml-vertical-card .glass-card-desc {
  color: rgba(255, 255, 255, 0.68);
}
groupviewcard--ml-vertical-card .glass-card-content {
  color: rgba(255, 255, 255, 0.88);
}
groupviewcard--ml-vertical-card .glass-card-footer {
  color: rgba(255, 255, 255, 0.6);
}
groupviewcard--ml-vertical-card .glass-card-action {
  border-top: 1px solid rgba(255, 255, 255, 0.15);
}
groupviewcard--ml-vertical-card .glass-skeleton {
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.12);
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    updated(changed) {
        if (changed.has('isEditing')) {
            this.applyEditingAttribute();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleCardClick() {
        if (!this.isInteractive())
            return;
        this.dispatchEvent(new CustomEvent('cardClick', { bubbles: true, composed: true, detail: {} }));
    }
    handleKeyDown(e) {
        if (!this.isInteractive())
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleCardClick();
        }
    }
    // ===========================================================================
    // INTERNAL HELPERS  (aparência = classes glass)
    // ===========================================================================
    isInteractive() {
        return this.clickable && !this.disabled && !this.loading;
    }
    applyEditingAttribute() {
        const elements = Array.from(this.querySelectorAll('*'));
        elements.forEach((el) => {
            const tag = el.tagName.toLowerCase();
            if (!tag.includes('-'))
                return;
            if (this.isEditing) {
                el.setAttribute('is-editing', '');
            }
            else {
                el.removeAttribute('is-editing');
            }
        });
    }
    getRootClasses() {
        return [
            'glass-card',
            'w-full p-4 flex flex-col gap-4',
            this.selected ? 'is-selected' : '',
            this.isInteractive() ? 'is-interactive' : '',
            this.disabled ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderHeader() {
        const hasHeader = this.hasSlot('CardHeader');
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        if (!hasHeader && !hasTitle && !hasDescription) {
            return html ``;
        }
        if (hasHeader) {
            return html `<div class="flex flex-col gap-1 glass-card-text">${unsafeHTML(this.getSlotContent('CardHeader'))}</div>`;
        }
        return html `
      <div class="flex flex-col gap-1">
        ${hasTitle ? html `<div class="glass-card-title text-base font-semibold">${unsafeHTML(this.getSlotContent('CardTitle'))}</div>` : html ``}
        ${hasDescription ? html `<div class="glass-card-desc text-sm">${unsafeHTML(this.getSlotContent('CardDescription'))}</div>` : html ``}
      </div>
    `;
    }
    renderContent() {
        if (!this.hasSlot('CardContent'))
            return html ``;
        return html `<div class="glass-card-content text-sm">${unsafeHTML(this.getSlotContent('CardContent'))}</div>`;
    }
    renderFooter() {
        if (!this.hasSlot('CardFooter'))
            return html ``;
        return html `<div class="glass-card-footer text-xs">${unsafeHTML(this.getSlotContent('CardFooter'))}</div>`;
    }
    renderAction() {
        if (!this.hasSlot('CardAction'))
            return html ``;
        return html `<div class="glass-card-action pt-3">${unsafeHTML(this.getSlotContent('CardAction'))}</div>`;
    }
    renderLoading() {
        return html `
      <div class="flex flex-col gap-4 animate-pulse">
        <div class="glass-skeleton h-4 w-2/3"></div>
        <div class="glass-skeleton h-3 w-1/2"></div>
        <div class="glass-skeleton h-20 w-full"></div>
        <div class="glass-skeleton h-3 w-1/3"></div>
        <div class="glass-skeleton h-9 w-28"></div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const interactive = this.isInteractive();
        return html `
      <div
        class=${this.getRootClasses()}
        role=${ifDefined(interactive ? 'button' : undefined)}
        tabindex=${ifDefined(interactive ? '0' : undefined)}
        aria-disabled=${ifDefined(this.disabled ? 'true' : undefined)}
        aria-selected=${ifDefined(this.selected ? 'true' : undefined)}
        @click=${this.handleCardClick}
        @keydown=${this.handleKeyDown}
      >
        ${this.loading
            ? this.renderLoading()
            : html ` ${this.renderHeader()} ${this.renderContent()} ${this.renderFooter()} ${this.renderAction()} `}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlVerticalCardMolecule.prototype, "isEditing", void 0);
MlVerticalCardMolecule = __decorate([
    customElement('groupviewcard--ml-vertical-card')
], MlVerticalCardMolecule);
export { MlVerticalCardMolecule };
