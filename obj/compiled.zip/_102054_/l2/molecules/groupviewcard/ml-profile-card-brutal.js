var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML PROFILE CARD — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupViewCard
// Herda MlProfileCardMolecule (mls-102040): estados (clickable/selected/disabled/
// loading), evento 'cardClick', modo de edicao propagado a filhos (lifecycle).
// Sobrescreve so render() + helpers presentacionais brutal.
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlProfileCardMolecule } from '/_102040_/l2/molecules/groupviewcard/ml-profile-card.js';
let MlProfileCardBrutal = class MlProfileCardBrutal extends MlProfileCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-profile-card-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupviewcard--ml-profile-card-brutal .brutal-card {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  box-shadow: 4px 4px 0 #000;
  color: #000;
}
groupviewcard--ml-profile-card-brutal .brutal-card.is-interactive {
  cursor: pointer;
}
groupviewcard--ml-profile-card-brutal .brutal-card.is-interactive:hover {
  box-shadow: 2px 2px 0 #000;
  transform: translate(2px, 2px);
}
groupviewcard--ml-profile-card-brutal .brutal-card.is-interactive:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupviewcard--ml-profile-card-brutal .brutal-card.is-selected {
  background: #dbeafe;
  border-color: #3b82f6;
  box-shadow: 4px 4px 0 #3b82f6;
}
groupviewcard--ml-profile-card-brutal .brutal-card.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: 2px 2px 0 #999;
  border-color: #999;
}
groupviewcard--ml-profile-card-brutal .brutal-card-text,
groupviewcard--ml-profile-card-brutal .brutal-card-title {
  color: #000;
  text-transform: uppercase;
  font-weight: 900;
  letter-spacing: 0.03em;
}
groupviewcard--ml-profile-card-brutal .brutal-card-desc {
  color: #555;
}
groupviewcard--ml-profile-card-brutal .brutal-card-content {
  color: #333;
}
groupviewcard--ml-profile-card-brutal .brutal-card-footer {
  color: #777;
}
groupviewcard--ml-profile-card-brutal .brutal-skeleton {
  border-radius: 0;
  background: #e5e5e5;
  border: 2px solid #ccc;
  animation: brutal-profile-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-profile-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
    }
    get x() {
        return this;
    }
    // ---- helpers presentacionais (brutal) ----
    brutalCardClasses() {
        return [
            'brutal-card',
            'w-full p-4',
            this.selected ? 'is-selected' : '',
            this.x.isInteractive() ? 'is-interactive' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    brutalHeader() {
        const hasHeader = this.hasSlot('CardHeader');
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        if (!hasHeader && !hasTitle && !hasDescription)
            return nothing;
        if (hasHeader) {
            return html `<div class="card-header brutal-card-text">${unsafeHTML(this.getSlotContent('CardHeader'))}</div>`;
        }
        return html `
      <div class="card-header">
        ${hasTitle ? html `<div class="brutal-card-title text-lg font-bold">${unsafeHTML(this.getSlotContent('CardTitle'))}</div>` : nothing}
        ${hasDescription ? html `<div class="brutal-card-desc mt-1 text-sm">${unsafeHTML(this.getSlotContent('CardDescription'))}</div>` : nothing}
      </div>
    `;
    }
    brutalContent() {
        if (!this.hasSlot('CardContent'))
            return nothing;
        return html `<div class="card-content brutal-card-content">${unsafeHTML(this.getSlotContent('CardContent'))}</div>`;
    }
    brutalFooter() {
        if (!this.hasSlot('CardFooter'))
            return nothing;
        return html `<div class="card-footer brutal-card-footer">${unsafeHTML(this.getSlotContent('CardFooter'))}</div>`;
    }
    brutalAction() {
        if (!this.hasSlot('CardAction'))
            return nothing;
        return html `<div class="card-action flex flex-wrap items-center gap-2">${unsafeHTML(this.getSlotContent('CardAction'))}</div>`;
    }
    brutalLoadingSkeleton() {
        return html `
      <div class="space-y-4">
        <div class="space-y-2">
          <div class="brutal-skeleton h-4 w-2/3"></div>
          <div class="brutal-skeleton h-3 w-1/2"></div>
        </div>
        <div class="brutal-skeleton h-16 w-full"></div>
        <div class="flex gap-2">
          <div class="brutal-skeleton h-8 w-24"></div>
          <div class="brutal-skeleton h-8 w-20"></div>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — logica/estado herdados via this.x
    // ===========================================================================
    render() {
        const x = this.x;
        const roleAttr = x.isInteractive() ? 'button' : nothing;
        const tabIndexAttr = x.isInteractive() ? 0 : nothing;
        const ariaDisabled = this.disabled || this.loading ? 'true' : nothing;
        const ariaSelected = this.selected ? 'true' : nothing;
        return html `
      <div
        class="${this.brutalCardClasses()}"
        role=${roleAttr}
        tabindex=${tabIndexAttr}
        aria-disabled=${ariaDisabled}
        aria-selected=${ariaSelected}
        @click=${() => x.handleCardClick()}
        @keydown=${(e) => x.handleCardKeydown(e)}
      >
        ${this.loading
            ? this.brutalLoadingSkeleton()
            : html `
              <div class="space-y-4">
                ${this.brutalHeader()} ${this.brutalContent()} ${this.brutalFooter()} ${this.brutalAction()}
              </div>
            `}
      </div>
    `;
    }
};
MlProfileCardBrutal = __decorate([
    customElement('groupviewcard--ml-profile-card-brutal')
], MlProfileCardBrutal);
export { MlProfileCardBrutal };
