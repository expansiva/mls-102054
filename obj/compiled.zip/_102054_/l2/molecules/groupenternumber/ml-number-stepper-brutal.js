var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMBER STEPPER — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterNumber
// Herda NumberStepperMolecule (mls-102040): parse/format, clamp, increment/decrement,
// estado (rawValue). Sobrescreve só render().
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { NumberStepperMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-number-stepper.js';
/// **collab_i18n_start**
const message_en = { increment: 'Increment', decrement: 'Decrement', loading: 'Loading...', required: 'Required', emptyValue: '—' };
const messages = {
    en: message_en,
    pt: { increment: 'Incrementar', decrement: 'Decrementar', loading: 'Carregando...', required: 'Obrigatório', emptyValue: '—' },
};
let NumberStepperBrutal = class NumberStepperBrutal extends NumberStepperMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenternumber--ml-number-stepper-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-affix {
  color: #000;
  font-weight: 700;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-input {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  box-shadow: 3px 3px 0 #000;
  transition: none;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-input::placeholder {
  color: #999;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-input:focus {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-input.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-input.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
  border-color: #999;
  box-shadow: 2px 2px 0 #999;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-input.is-readonly {
  cursor: default;
  background: #f5f5f5;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-btn {
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  color: #000;
  font-weight: 900;
  cursor: pointer;
  box-shadow: 2px 2px 0 #000;
  transition: none;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-btn:hover:not(:disabled) {
  background: #f0f0f0;
  box-shadow: 1px 1px 0 #000;
  transform: translate(1px, 1px);
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-btn:active:not(:disabled) {
  box-shadow: 0 0 0 #000;
  transform: translate(2px, 2px);
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-btn:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
  border-color: #999;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-view {
  color: #000;
  font-weight: 700;
}
groupenternumber--ml-number-stepper-brutal .brutal-ns-loading {
  color: #666;
}
groupenternumber--ml-number-stepper-brutal .brutal-helper {
  color: #666;
}
groupenternumber--ml-number-stepper-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
`);
        this.gMsg = messages.en;
        this.gUid = `ns-brutal-${Math.random().toString(36).slice(2, 9)}`;
    }
    get gLabelId() { return `${this.gUid}-label`; }
    get gHelperId() { return `${this.gUid}-helper`; }
    get gErrorId() { return `${this.gUid}-error`; }
    get gInputId() { return `${this.gUid}-input`; }
    get x() {
        return this;
    }
    brutalInputClasses(hasError) {
        return [
            'brutal-ns-input w-full flex-1 px-3 py-2 text-sm outline-none',
            hasError ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalButtonClasses() {
        return 'brutal-ns-btn h-9 w-9 inline-flex items-center justify-center text-sm';
    }
    brutalContainerClasses() {
        return ['w-full', this.disabled || this.loading ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id="${this.gLabelId}" class="brutal-ns-label mb-1 block text-sm">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    brutalHelperOrError(effectiveError) {
        if (String(effectiveError).length > 0) {
            return html `<p id="${this.gErrorId}" class="brutal-error-text mt-1 text-xs">${unsafeHTML(String(effectiveError))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.gHelperId}" class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<span class="brutal-ns-affix text-sm">${unsafeHTML(this.getSlotContent('Prefix'))}</span>`;
    }
    brutalSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `<span class="brutal-ns-affix text-sm">${unsafeHTML(this.getSlotContent('Suffix'))}</span>`;
    }
    brutalViewMode() {
        const display = this.value === null || this.value === undefined ? this.gMsg.emptyValue : this.x.formatToDisplay(this.value);
        return html `
      <div class="${this.brutalContainerClasses()}">
        ${this.brutalLabel()}
        <div class="brutal-ns-view flex items-center gap-2 text-sm">
          ${this.brutalPrefix()}<span>${display}</span>${this.brutalSuffix()}
        </div>
      </div>
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (!this.isEditing)
            return this.brutalViewMode();
        const effectiveError = this.error || (this.required && (this.value === null || this.value === undefined) ? this.gMsg.required : '');
        const hasError = String(effectiveError).length > 0;
        const ariaDescribedBy = hasError ? this.gErrorId : this.hasSlot('Helper') ? this.gHelperId : undefined;
        const placeholder = this.placeholder || '';
        return html `
      <div class="${this.brutalContainerClasses()}">
        ${this.brutalLabel()}
        <div class="flex items-center gap-2">
          ${this.brutalPrefix()}
          <input
            id="${this.gInputId}"
            class="${this.brutalInputClasses(hasError)}"
            type="text"
            inputmode="${this.decimals > 0 ? 'decimal' : 'numeric'}"
            .value=${this.x.rawValue}
            placeholder="${this.value === null ? placeholder : ''}"
            ?disabled=${this.disabled || this.loading}
            ?readonly=${this.readonly}
            aria-labelledby="${this.hasSlot('Label') ? this.gLabelId : nothing}"
            aria-describedby="${ariaDescribedBy || nothing}"
            aria-invalid="${hasError ? 'true' : 'false'}"
            aria-required="${this.required ? 'true' : 'false'}"
            @input=${(e) => this.x.handleInput(e)}
            @blur=${() => this.x.handleBlur()}
            @focus=${() => this.x.handleFocus()}
          />
          ${this.brutalSuffix()}
          <button type="button" class="${this.brutalButtonClasses()}" aria-label="${this.gMsg.decrement}" ?disabled=${this.disabled || this.readonly || this.loading} @click=${() => this.x.decrement()}>−</button>
          <button type="button" class="${this.brutalButtonClasses()}" aria-label="${this.gMsg.increment}" ?disabled=${this.disabled || this.readonly || this.loading} @click=${() => this.x.increment()}>+</button>
        </div>
        ${this.loading ? html `<div class="brutal-ns-loading mt-2 text-xs">${this.gMsg.loading}</div>` : this.brutalHelperOrError(effectiveError)}
      </div>
    `;
    }
};
NumberStepperBrutal = __decorate([
    customElement('groupenternumber--ml-number-stepper-brutal')
], NumberStepperBrutal);
export { NumberStepperBrutal };
