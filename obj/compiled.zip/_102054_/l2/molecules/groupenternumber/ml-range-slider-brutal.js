var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RANGE SLIDER — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterNumber
// Herda RangeSliderMolecule (mls-102040): dual-range, clampPair, bounds, formatação,
// estado. Sobrescreve só render().
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { RangeSliderMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-range-slider.js';
/// **collab_i18n_start**
const message_en = { placeholder: 'Select a range', empty: '—', loading: 'Loading...', rangeSeparator: '–' };
const messages = {
    en: message_en,
    pt: { placeholder: 'Selecione um intervalo', empty: '—', loading: 'Carregando...', rangeSeparator: '–' },
};
let RangeSliderBrutal = class RangeSliderBrutal extends RangeSliderMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenternumber--ml-range-slider-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupenternumber--ml-range-slider-brutal .brutal-rs-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupenternumber--ml-range-slider-brutal .brutal-rs-affix {
  color: #666;
  font-weight: 700;
}
groupenternumber--ml-range-slider-brutal .brutal-rs-value {
  color: #000;
  font-weight: 800;
}
groupenternumber--ml-range-slider-brutal .brutal-rs-sep {
  color: #999;
  font-weight: 700;
}
groupenternumber--ml-range-slider-brutal .brutal-rs-view {
  color: #000;
  font-weight: 700;
}
groupenternumber--ml-range-slider-brutal .brutal-rs-loading {
  color: #666;
}
groupenternumber--ml-range-slider-brutal .brutal-helper {
  color: #666;
}
groupenternumber--ml-range-slider-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
}
groupenternumber--ml-range-slider-brutal .brutal-range {
  -webkit-appearance: none;
  appearance: none;
  height: 0.5rem;
  border-radius: 0;
  background: #e5e5e5;
  border: 2px solid #000;
  outline: none;
  cursor: pointer;
}
groupenternumber--ml-range-slider-brutal .brutal-range.is-error {
  border-color: #ef4444;
}
groupenternumber--ml-range-slider-brutal .brutal-range.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenternumber--ml-range-slider-brutal .brutal-range.is-readonly {
  opacity: 0.7;
}
groupenternumber--ml-range-slider-brutal .brutal-range::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 1.2rem;
  height: 1.2rem;
  border-radius: 0;
  background: #000;
  border: 2px solid #000;
  box-shadow: 2px 2px 0 #000;
  cursor: pointer;
}
groupenternumber--ml-range-slider-brutal .brutal-range::-moz-range-thumb {
  width: 1.2rem;
  height: 1.2rem;
  border-radius: 0;
  background: #000;
  border: 2px solid #000;
  box-shadow: 2px 2px 0 #000;
  cursor: pointer;
}
groupenternumber--ml-range-slider-brutal .brutal-range:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
`);
        this.gMsg = messages.en;
        this.gUid = `rs-brutal-${Math.random().toString(36).slice(2, 8)}`;
    }
    get gLabelId() { return `${this.gUid}-label`; }
    get gErrorId() { return `${this.gUid}-error`; }
    get gHelperId() { return `${this.gUid}-helper`; }
    get x() {
        return this;
    }
    brutalInputClasses() {
        return [
            'brutal-range w-full',
            this.error ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id=${this.gLabelId} class="brutal-rs-label mb-1 text-sm">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    brutalPrefixSuffix(content) {
        const prefix = this.hasSlot('Prefix') ? unsafeHTML(this.getSlotContent('Prefix')) : null;
        const suffix = this.hasSlot('Suffix') ? unsafeHTML(this.getSlotContent('Suffix')) : null;
        return html `
      <span class="inline-flex items-center gap-1">
        ${prefix ? html `<span class="brutal-rs-affix">${prefix}</span>` : html ``}
        <span class="brutal-rs-value">${content}</span>
        ${suffix ? html `<span class="brutal-rs-affix">${suffix}</span>` : html ``}
      </span>
    `;
    }
    brutalHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id=${this.gErrorId} class="brutal-error-text mt-1 text-xs">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${this.gHelperId} class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalLoading() {
        if (!this.loading)
            return html ``;
        return html `<div class="brutal-rs-loading mt-2 text-xs">${this.gMsg.loading}</div>`;
    }
    brutalEditMode() {
        const { min, max } = this.x.getBounds();
        const display = this.x.getValueDisplay();
        const ariaDescribedBy = this.error ? this.gErrorId : this.hasSlot('Helper') ? this.gHelperId : undefined;
        const ariaLabelledBy = this.hasSlot('Label') ? this.gLabelId : undefined;
        return html `
      <div class="flex flex-col">
        ${this.brutalLabel()}
        <div class="brutal-rs-row mb-2 flex items-center justify-between text-sm">
          ${this.brutalPrefixSuffix(display.low)}
          <span class="brutal-rs-sep">${this.gMsg.rangeSeparator}</span>
          ${this.brutalPrefixSuffix(display.high)}
        </div>
        <div class="grid gap-3">
          <input
            type="range"
            class=${this.brutalInputClasses()}
            min=${min} max=${max} step=${this.step}
            .value=${String(this.value ?? min)}
            aria-labelledby=${ariaLabelledBy || ''}
            aria-describedby=${ariaDescribedBy || ''}
            aria-required=${this.required ? 'true' : 'false'}
            aria-invalid=${this.error ? 'true' : 'false'}
            aria-valuemin=${min} aria-valuemax=${max} aria-valuenow=${this.value ?? min}
            aria-readonly=${this.readonly ? 'true' : 'false'}
            ?disabled=${this.disabled || this.loading}
            @input=${(e) => this.x.handleLowInput(e)}
            @change=${() => this.x.handleLowChange()}
            @focus=${() => this.x.handleFocus()}
            @blur=${() => this.x.handleBlur()}
          />
          <input
            type="range"
            class=${this.brutalInputClasses()}
            min=${min} max=${max} step=${this.step}
            .value=${String(this.valueHigh ?? max)}
            aria-labelledby=${ariaLabelledBy || ''}
            aria-describedby=${ariaDescribedBy || ''}
            aria-required=${this.required ? 'true' : 'false'}
            aria-invalid=${this.error ? 'true' : 'false'}
            aria-valuemin=${min} aria-valuemax=${max} aria-valuenow=${this.valueHigh ?? max}
            aria-readonly=${this.readonly ? 'true' : 'false'}
            ?disabled=${this.disabled || this.loading}
            @input=${(e) => this.x.handleHighInput(e)}
            @change=${() => this.x.handleHighChange()}
            @focus=${() => this.x.handleFocus()}
            @blur=${() => this.x.handleBlur()}
          />
        </div>
        ${this.brutalHelperOrError()} ${this.brutalLoading()}
      </div>
    `;
    }
    brutalViewMode() {
        const display = this.x.getValueDisplay();
        const content = this.x.isIntervalUnset() ? this.gMsg.empty : `${display.low} ${this.gMsg.rangeSeparator} ${display.high}`;
        return html `
      <div class="flex flex-col">${this.brutalLabel()}<div class="brutal-rs-view text-sm">${this.brutalPrefixSuffix(content)}</div></div>
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (!this.isEditing)
            return this.brutalViewMode();
        return this.brutalEditMode();
    }
};
RangeSliderBrutal = __decorate([
    customElement('groupenternumber--ml-range-slider-brutal')
], RangeSliderBrutal);
export { RangeSliderBrutal };
