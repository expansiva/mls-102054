var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RANGE SLIDER — BRUTALISM (mls-102054)
// =============================================================================
// Skill Group: groupEnterNumber
// Casca (estratégia D): herda tudo de RangeSliderMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { RangeSliderMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-range-slider.js';
let RangeSliderBrutal = class RangeSliderBrutal extends RangeSliderMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenternumber--ml-range-slider-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-surface: #e5e5e5;
  --ml-border-width: 2px;
  --ml-outline-variant: #000000;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #666666;
  --ml-error: #ef4444;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupenternumber--ml-range-slider-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenternumber--ml-range-slider-brutal span.ml-text {
  color: var(--ml-on-surface, #000000);
  font-weight: 800;
}
groupenternumber--ml-range-slider-brutal div.ml-text {
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupenternumber--ml-range-slider-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #666666);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupenternumber--ml-range-slider-brutal div.ml-text-muted > span.ml-text-muted {
  color: #999999;
}
groupenternumber--ml-range-slider-brutal div.ml-text-muted.mt-2 {
  color: var(--ml-on-surface-muted, #666666);
  font-weight: normal;
}
groupenternumber--ml-range-slider-brutal .ml-helper {
  color: var(--ml-on-surface-muted, #666666);
}
groupenternumber--ml-range-slider-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupenternumber--ml-range-slider-brutal .ml-slider-track {
  -webkit-appearance: none;
  appearance: none;
  background: var(--ml-surface, #e5e5e5);
  border: var(--ml-border-width, 2px) solid var(--ml-outline-variant, #000000);
  border-radius: 0;
  outline: none;
  transition: none;
}
groupenternumber--ml-range-slider-brutal .ml-slider-track::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 1.2rem;
  height: 1.2rem;
  border-radius: 0;
  background: #000000;
  border: 2px solid #000000;
  box-shadow: 2px 2px 0 #000000;
  cursor: pointer;
}
groupenternumber--ml-range-slider-brutal .ml-slider-track::-moz-range-thumb {
  width: 1.2rem;
  height: 1.2rem;
  border-radius: 0;
  background: #000000;
  border: 2px solid #000000;
  box-shadow: 2px 2px 0 #000000;
  cursor: pointer;
}
groupenternumber--ml-range-slider-brutal .ml-slider-track:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupenternumber--ml-range-slider-brutal .ml-slider-track.ml-input-container-error {
  border-color: var(--ml-error, #ef4444);
}
groupenternumber--ml-range-slider-brutal .ml-slider-track[aria-readonly='true'] {
  opacity: 0.7;
}
groupenternumber--ml-range-slider-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
RangeSliderBrutal = __decorate([
    customElement('groupenternumber--ml-range-slider-brutal')
], RangeSliderBrutal);
export { RangeSliderBrutal };
