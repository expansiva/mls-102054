var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-floating-text-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML FLOATING TEXT INPUT MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupEnterText
// Mesma molécula/contrato do mls-102040. Lógica intacta (máscara, label flutuante,
// prefix/suffix, view mode, loading). A aparência (vidro) vive no .less, escopada
// sob a tag. Layout/posicionamento permanece em Tailwind.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MlFloatingTextInputMolecule = class MlFloatingTextInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawDisplay = '';
        this.isFocused = false;
        this.uid = `ml-floating-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER (derived values)
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const maskAttr = this.getAttribute('mask');
        const inputTypeAttr = this.getAttribute('input-type');
        if (valueAttr === `{{${key}}}` || maskAttr === `{{${key}}}` || inputTypeAttr === `{{${key}}}`) {
            this.rawDisplay = this.getMaskedDisplayValue(this.value, this.mask, this.inputType);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    updated(changedProps) {
        if (changedProps.has('value') || changedProps.has('mask') || changedProps.has('inputType')) {
            this.rawDisplay = this.getMaskedDisplayValue(this.value, this.mask, this.inputType);
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const input = e.target;
        const incomingValue = input.value ?? '';
        let nextRaw = incomingValue;
        let nextDisplay = incomingValue;
        if (this.shouldUseMask()) {
            nextRaw = this.extractRawFromInput(incomingValue, this.mask);
            if (this.maxLength !== null) {
                nextRaw = nextRaw.slice(0, this.maxLength);
            }
            nextDisplay = this.applyMaskToRaw(nextRaw, this.mask);
            input.value = nextDisplay;
            this.rawDisplay = nextDisplay;
        }
        else {
            if (this.maxLength !== null && incomingValue.length > this.maxLength) {
                nextRaw = incomingValue.slice(0, this.maxLength);
                input.value = nextRaw;
            }
        }
        this.value = nextRaw;
        this.dispatchEvent(new CustomEvent('input', { bubbles: true, composed: true, detail: { value: this.value } }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('change', { bubbles: true, composed: true, detail: { value: this.value } }));
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // MASK HELPERS
    // ===========================================================================
    shouldUseMask() {
        return Boolean(this.mask) && this.inputType !== 'password';
    }
    getMaskedDisplayValue(value, mask, inputType) {
        if (!mask || inputType === 'password')
            return value ?? '';
        return this.applyMaskToRaw(value ?? '', mask);
    }
    applyMaskToRaw(raw, mask) {
        if (!mask)
            return raw;
        let result = '';
        let rawIndex = 0;
        for (let i = 0; i < mask.length; i += 1) {
            const maskChar = mask[i];
            if (this.isMaskToken(maskChar)) {
                if (rawIndex >= raw.length)
                    break;
                result += raw[rawIndex];
                rawIndex += 1;
            }
            else {
                if (rawIndex > 0 && rawIndex <= raw.length) {
                    result += maskChar;
                }
            }
        }
        return result;
    }
    extractRawFromInput(input, mask) {
        if (!mask)
            return input;
        const tokens = mask.split('').filter((ch) => this.isMaskToken(ch));
        let raw = '';
        let tokenIndex = 0;
        for (let i = 0; i < input.length; i += 1) {
            if (tokenIndex >= tokens.length)
                break;
            const token = tokens[tokenIndex];
            const ch = input[i];
            if (this.isCharValidForToken(ch, token)) {
                raw += ch;
                tokenIndex += 1;
            }
        }
        return raw;
    }
    isMaskToken(ch) {
        return ch === '#' || ch === 'A' || ch === '*';
    }
    isCharValidForToken(ch, token) {
        if (token === '#')
            return /\d/.test(ch);
        if (token === 'A')
            return /[a-zA-Z]/.test(ch);
        return true;
    }
    // ===========================================================================
    // RENDER HELPERS  (aparência via classes glass; layout via Tailwind)
    // ===========================================================================
    getLabelText() {
        if (this.hasSlot('Label')) {
            return this.getSlotContent('Label');
        }
        return this.placeholder || '';
    }
    getInputPlaceholder(labelText) {
        return labelText ? '' : this.placeholder;
    }
    getViewValue() {
        if (this.inputType === 'password')
            return '••••••••';
        if (!this.value)
            return '—';
        if (this.shouldUseMask())
            return this.getMaskedDisplayValue(this.value, this.mask, this.inputType);
        return this.value;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<div class="glass-input-affix">${unsafeHTML(this.getSlotContent('Prefix'))}</div>`;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix') && !this.loading)
            return html ``;
        return html `
      <div class="glass-input-affix flex items-center gap-2">
        ${this.hasSlot('Suffix') ? unsafeHTML(this.getSlotContent('Suffix')) : html ``}
        ${this.loading ? html `<span class="glass-input-spinner inline-block h-4 w-4 animate-spin rounded-full"></span>` : html ``}
      </div>
    `;
    }
    renderFeedback(labelId) {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${labelId}-error" class="glass-input-error mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${labelId}-helper" class="glass-input-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderInlineLabel(labelText, labelId) {
        if (!labelText)
            return html ``;
        const labelClasses = [
            // posição (layout): desloca para não sobrepor o prefix.
            this.hasSlot('Prefix') ? 'left-10' : 'left-3',
            'glass-input-inline-label',
            'absolute pointer-events-none top-1/2 -translate-y-1/2 text-sm transition-all',
            this.disabled || this.loading ? 'opacity-50' : '',
        ]
            .filter(Boolean)
            .join(' ');
        return html `<label id="${labelId}" class="${labelClasses}">${unsafeHTML(labelText)}</label>`;
    }
    renderFloatingLabel(labelText, labelId) {
        if (!labelText)
            return html ``;
        return html `<label id="${labelId}" class="glass-input-floating-label mb-1 block text-xs">${unsafeHTML(labelText)}</label>`;
    }
    getContainerClasses(hasInlineLabel) {
        return [
            'glass-input-container',
            'relative flex w-full items-center gap-2',
            hasInlineLabel ? 'pt-4 pb-1 px-3' : 'py-2 px-3',
            this.error ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getInputClasses() {
        return [
            'glass-input-field',
            'flex-1 bg-transparent outline-none text-sm',
            this.readonly ? 'is-readonly' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const labelText = this.getLabelText();
        const labelId = `${this.uid}-label`;
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${labelText ? html `<div class="glass-input-view-label mb-1 text-sm">${unsafeHTML(labelText)}</div>` : html ``}
          <div class="glass-input-view-value flex items-center gap-2 text-sm">
            ${this.renderPrefix()}
            <span>${this.getViewValue()}</span>
            ${this.renderSuffix()}
          </div>
        </div>
      `;
        }
        const floating = this.isFocused || Boolean(this.value);
        const showFloatingLabel = Boolean(labelText) && floating;
        const showInlineLabel = Boolean(labelText) && !floating;
        const inputValue = this.shouldUseMask() ? this.rawDisplay : this.value;
        const inputPlaceholder = this.getInputPlaceholder(labelText);
        const inputDisabled = this.disabled || this.loading;
        const describedBy = this.error ? `${labelId}-error` : this.hasSlot('Helper') ? `${labelId}-helper` : undefined;
        return html `
      <div class="w-full">
        <div class="min-h-[1rem]">
          <!-- Reserva espaço vertical para o label flutuante e evita layout shift -->
          ${showFloatingLabel ? this.renderFloatingLabel(labelText, labelId) : html ``}
        </div>
        <div class="${this.getContainerClasses(showInlineLabel)}">
          ${showInlineLabel ? this.renderInlineLabel(labelText, labelId) : html ``} ${this.renderPrefix()}
          <input
            class="${this.getInputClasses()}"
            type="${this.inputType}"
            .value="${inputValue}"
            placeholder="${inputPlaceholder}"
            maxlength=${ifDefined(this.maxLength ?? undefined)}
            minlength=${ifDefined(this.minLength ?? undefined)}
            name="${this.name}"
            autocomplete="${this.autocomplete}"
            ?disabled=${inputDisabled}
            ?readonly=${this.readonly}
            ?required=${this.required}
            aria-labelledby=${ifDefined(labelText ? labelId : undefined)}
            aria-describedby=${ifDefined(describedBy)}
            aria-invalid=${this.error ? 'true' : 'false'}
            aria-required=${this.required ? 'true' : 'false'}
            @input=${this.handleInput}
            @blur=${this.handleBlur}
            @focus=${this.handleFocus}
          />
          ${this.renderSuffix()}
        </div>
        ${this.renderFeedback(labelId)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MlFloatingTextInputMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MlFloatingTextInputMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'rows' })
], MlFloatingTextInputMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], MlFloatingTextInputMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlFloatingTextInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlFloatingTextInputMolecule.prototype, "rawDisplay", void 0);
__decorate([
    state()
], MlFloatingTextInputMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], MlFloatingTextInputMolecule.prototype, "uid", void 0);
MlFloatingTextInputMolecule = __decorate([
    customElement('groupentertext--ml-floating-text-input')
], MlFloatingTextInputMolecule);
export { MlFloatingTextInputMolecule };
