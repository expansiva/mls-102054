var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-tag-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TAG INPUT — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterText
// Herda MlTagInputMolecule (mls-102040): parsing de tags, add/remove, dedup,
// modo multilinha, estado. Sobrescreve só render().
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlTagInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-tag-input.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Type and press Enter to add tags',
    noValue: '—',
    removeTag: 'Remove tag',
    charactersRemaining: 'characters remaining',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Digite e pressione Enter para adicionar tags',
        noValue: '—',
        removeTag: 'Remover tag',
        charactersRemaining: 'caracteres restantes',
    },
};
let MlTagInputBrutal = class MlTagInputBrutal extends MlTagInputMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-tag-input-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupentertext--ml-tag-input-brutal .brutal-tag-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-tag-input-brutal .brutal-tag-req {
  color: #ef4444;
}
groupentertext--ml-tag-input-brutal .brutal-tag-view {
  color: #000;
}
groupentertext--ml-tag-input-brutal .brutal-tag-affix {
  color: #000;
}
groupentertext--ml-tag-input-brutal .brutal-tag-counter {
  color: #666;
}
groupentertext--ml-tag-input-brutal .brutal-helper {
  color: #666;
}
groupentertext--ml-tag-input-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertext--ml-tag-input-brutal .brutal-tag-loading {
  background: rgba(255, 255, 255, 0.85);
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
}
groupentertext--ml-tag-input-brutal .brutal-tag-box {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000;
  cursor: text;
}
groupentertext--ml-tag-input-brutal .brutal-tag-box.is-focused {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupentertext--ml-tag-input-brutal .brutal-tag-box.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupentertext--ml-tag-input-brutal .brutal-tag-box.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupentertext--ml-tag-input-brutal .brutal-tag-box.is-readonly {
  cursor: default;
  background: #f5f5f5;
}
groupentertext--ml-tag-input-brutal .brutal-tag-input {
  background: transparent;
  border: none;
  outline: none;
  color: #000;
  font-family: inherit;
}
groupentertext--ml-tag-input-brutal .brutal-tag-input::placeholder {
  color: #999;
}
groupentertext--ml-tag-input-brutal .brutal-tag-input.is-disabled {
  cursor: not-allowed;
}
groupentertext--ml-tag-input-brutal .brutal-tag-input.is-readonly {
  cursor: default;
}
groupentertext--ml-tag-input-brutal .brutal-tag {
  background: #000;
  color: #fff;
  border: 2px solid #000;
  border-radius: 0;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-tag-input-brutal .brutal-tag-remove {
  color: #fff;
  border-radius: 0;
  cursor: pointer;
}
groupentertext--ml-tag-input-brutal .brutal-tag-remove:hover {
  background: #ef4444;
  color: #fff;
}
groupentertext--ml-tag-input-brutal .brutal-tag-remove:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupentertext--ml-tag-input-brutal .brutal-tag-remove.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    brutalContainerClasses() {
        const hasError = this.error && this.error.length > 0;
        return [
            'brutal-tag-box w-full',
            hasError ? 'is-error' : '',
            this.x.isFocused && this.x.isInteractive ? 'is-focused' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalInputClasses() {
        return [
            'brutal-tag-input flex-1 min-w-[120px] text-sm',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalRemoveClasses() {
        return ['brutal-tag-remove inline-flex items-center justify-center w-4 h-4', !this.x.isInteractive ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label class="brutal-tag-label block text-sm font-medium mb-1">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="brutal-tag-req ml-0.5">*</span>` : ''}
      </label>
    `;
    }
    brutalPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<span class="brutal-tag-affix flex-shrink-0">${unsafeHTML(this.getSlotContent('Prefix'))}</span>`;
    }
    brutalSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `<span class="brutal-tag-affix flex-shrink-0">${unsafeHTML(this.getSlotContent('Suffix'))}</span>`;
    }
    brutalTag(tag, index) {
        return html `
      <span class="brutal-tag inline-flex items-center gap-1 px-2 py-1 text-sm">
        <span class="max-w-[150px] truncate">${tag}</span>
        ${this.x.isInteractive ? html `
          <button
            type="button"
            class="${this.brutalRemoveClasses()}"
            @click=${(e) => { e.stopPropagation(); this.x.removeTagByIndex(index); }}
            aria-label="${this.gMsg.removeTag}: ${tag}"
            ?disabled=${!this.x.isInteractive}
          >
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        ` : ''}
      </span>
    `;
    }
    brutalTags() {
        if (this.x.tags.length === 0)
            return html ``;
        return html `${this.x.tags.map((tag, index) => this.brutalTag(tag, index))}`;
    }
    brutalInput() {
        const placeholderText = this.placeholder || this.gMsg.placeholder;
        return html `
      <input
        type="${this.inputType}"
        class="${this.brutalInputClasses()}"
        .value=${this.x.currentInput}
        placeholder=${this.x.tags.length === 0 ? placeholderText : ''}
        ?disabled=${this.disabled || this.loading}
        ?readonly=${this.readonly}
        autocomplete=${this.autocomplete || 'off'}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        @input=${(e) => this.x.handleInput(e)}
        @keydown=${(e) => this.x.handleKeyDown(e)}
        @focus=${() => this.x.handleFocus()}
        @blur=${() => this.x.handleBlur()}
      />
    `;
    }
    brutalTextarea() {
        const placeholderText = this.placeholder || this.gMsg.placeholder;
        const currentLength = this.value?.length || 0;
        return html `
      <textarea
        class="${this.brutalInputClasses()} w-full resize-none py-2"
        .value=${this.value || ''}
        placeholder=${placeholderText}
        rows=${this.rows}
        ?disabled=${this.disabled || this.loading}
        ?readonly=${this.readonly}
        autocomplete=${this.autocomplete || 'off'}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        @input=${(e) => this.x.handleInput(e)}
        @focus=${() => this.x.handleFocus()}
        @blur=${() => this.x.handleBlur()}
      ></textarea>
      ${this.maxLength !== null ? html `
        <div class="brutal-tag-counter text-xs text-right mt-1" aria-live="polite">${currentLength} / ${this.maxLength}</div>
      ` : ''}
    `;
    }
    brutalEditMode() {
        if (this.x.isMultiLine) {
            return html `<div class="${this.brutalContainerClasses()} p-2">${this.brutalPrefix()} ${this.brutalTextarea()} ${this.brutalSuffix()}</div>`;
        }
        return html `
      <div class="${this.brutalContainerClasses()} p-2 min-h-[42px]" @click=${(e) => this.x.handleContainerClick(e)}>
        <div class="flex flex-wrap items-center gap-2">
          ${this.brutalPrefix()} ${this.brutalTags()} ${this.brutalInput()} ${this.brutalSuffix()}
        </div>
      </div>
    `;
    }
    brutalViewMode() {
        const displayValue = this.value && this.value.trim() !== '' ? this.value : this.gMsg.noValue;
        return html `
      <div class="brutal-tag-view flex items-center gap-2 py-2 text-sm">
        ${this.brutalPrefix()}<span>${displayValue}</span>${this.brutalSuffix()}
      </div>
    `;
    }
    brutalHelper() {
        if (!this.isEditing)
            return html ``;
        if (this.error && this.error.length > 0) {
            return html `<p class="brutal-error-text mt-1 text-xs" role="alert">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<div class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
        }
        return html ``;
    }
    brutalLoading() {
        if (!this.loading)
            return html ``;
        return html `
      <div class="brutal-tag-loading absolute inset-0 flex items-center justify-center">
        <svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        return html `
      <div class="w-full">
        ${this.brutalLabel()}
        <div class="relative">
          ${this.isEditing ? this.brutalEditMode() : this.brutalViewMode()}
          ${this.brutalLoading()}
        </div>
        ${this.brutalHelper()}
      </div>
    `;
    }
};
MlTagInputBrutal = __decorate([
    customElement('groupentertext--ml-tag-input-brutal')
], MlTagInputBrutal);
export { MlTagInputBrutal };
