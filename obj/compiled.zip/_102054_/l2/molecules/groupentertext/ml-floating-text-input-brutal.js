var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML FLOATING TEXT INPUT — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterText
// Herda MlFloatingTextInputMolecule (mls-102040): máscara, label flutuante,
// prefix/suffix, view mode, estado (rawDisplay/isFocused). Sobrescreve só render().
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement } from 'lit/decorators.js';
import { MlFloatingTextInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-floating-text-input.js';
let MlFloatingTextInputBrutal = class MlFloatingTextInputBrutal extends MlFloatingTextInputMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-floating-text-input-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-container {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  box-shadow: 3px 3px 0 #000;
  cursor: text;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-container:focus-within:not(.is-error) {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-container.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-container.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-field {
  color: #000;
  caret-color: #3b82f6;
  font-family: inherit;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-field::placeholder {
  color: #999;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-field.is-readonly {
  cursor: default;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-inline-label {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-floating-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-affix {
  color: #000;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-spinner {
  border: 3px solid #ccc;
  border-top-color: #000;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-error {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-helper {
  color: #666;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-view-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-floating-text-input-brutal .brutal-input-view-value {
  color: #000;
}
`);
        this.gUid = `flt-brutal-${Math.random().toString(36).slice(2, 9)}`;
    }
    get x() {
        return this;
    }
    // ---- helpers presentacionais (brutal) — nomes próprios p/ não colidir com os private do pai ----
    brutalPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<div class="brutal-input-affix">${unsafeHTML(this.getSlotContent('Prefix'))}</div>`;
    }
    brutalSuffix() {
        if (!this.hasSlot('Suffix') && !this.loading)
            return html ``;
        return html `
      <div class="brutal-input-affix flex items-center gap-2">
        ${this.hasSlot('Suffix') ? unsafeHTML(this.getSlotContent('Suffix')) : html ``}
        ${this.loading ? html `<span class="brutal-input-spinner inline-block h-4 w-4 animate-spin"></span>` : html ``}
      </div>
    `;
    }
    brutalFeedback(labelId) {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${labelId}-error" class="brutal-input-error mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${labelId}-helper" class="brutal-input-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalInlineLabel(labelText, labelId) {
        if (!labelText)
            return html ``;
        const labelClasses = [
            this.hasSlot('Prefix') ? 'left-10' : 'left-3',
            'brutal-input-inline-label',
            'absolute pointer-events-none top-1/2 -translate-y-1/2 text-sm',
            this.disabled || this.loading ? 'opacity-40' : '',
        ].filter(Boolean).join(' ');
        return html `<label id="${labelId}" class="${labelClasses}">${unsafeHTML(labelText)}</label>`;
    }
    brutalFloatingLabel(labelText, labelId) {
        if (!labelText)
            return html ``;
        return html `<label id="${labelId}" class="brutal-input-floating-label mb-1 block text-xs">${unsafeHTML(labelText)}</label>`;
    }
    brutalContainerClasses(hasInlineLabel) {
        return [
            'brutal-input-container relative flex w-full items-center gap-2',
            hasInlineLabel ? 'pt-4 pb-1 px-3' : 'py-2 px-3',
            this.error ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalInputClasses() {
        return ['brutal-input-field flex-1 bg-transparent outline-none text-sm', this.readonly ? 'is-readonly' : ''].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER (override) — lógica/estado/format herdados via this.x
    // ===========================================================================
    render() {
        const x = this.x;
        const labelText = x.getLabelText();
        const labelId = `${this.gUid}-label`;
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${labelText ? html `<div class="brutal-input-view-label mb-1 text-sm">${unsafeHTML(labelText)}</div>` : html ``}
          <div class="brutal-input-view-value flex items-center gap-2 text-sm">
            ${this.brutalPrefix()}
            <span>${x.getViewValue()}</span>
            ${this.brutalSuffix()}
          </div>
        </div>
      `;
        }
        const floating = x.isFocused || Boolean(this.value);
        const showFloatingLabel = Boolean(labelText) && floating;
        const showInlineLabel = Boolean(labelText) && !floating;
        const inputValue = x.shouldUseMask() ? x.rawDisplay : this.value;
        const inputPlaceholder = x.getInputPlaceholder(labelText);
        const inputDisabled = this.disabled || this.loading;
        const describedBy = this.error ? `${labelId}-error` : this.hasSlot('Helper') ? `${labelId}-helper` : undefined;
        return html `
      <div class="w-full">
        <div class="min-h-[1rem]">${showFloatingLabel ? this.brutalFloatingLabel(labelText, labelId) : html ``}</div>
        <div class="${this.brutalContainerClasses(showInlineLabel)}">
          ${showInlineLabel ? this.brutalInlineLabel(labelText, labelId) : html ``} ${this.brutalPrefix()}
          <input
            class="${this.brutalInputClasses()}"
            type="${this.inputType}"
            .value="${inputValue}"
            placeholder="${inputPlaceholder}"
            maxlength=${ifDefined(this.maxLength ?? undefined)}
            minlength=${ifDefined(this.minLength ?? undefined)}
            name="${this.name}"
            autocomplete="${this.autocomplete}"
            ?disabled=${inputDisabled}
            ?readonly=${this.readonly}
            ?required=${this.required}
            aria-labelledby=${ifDefined(labelText ? labelId : undefined)}
            aria-describedby=${ifDefined(describedBy)}
            aria-invalid=${this.error ? 'true' : 'false'}
            aria-required=${this.required ? 'true' : 'false'}
            @input=${(e) => x.handleInput(e)}
            @blur=${() => x.handleBlur()}
            @focus=${() => x.handleFocus()}
          />
          ${this.brutalSuffix()}
        </div>
        ${this.brutalFeedback(labelId)}
      </div>
    `;
    }
};
MlFloatingTextInputBrutal = __decorate([
    customElement('groupentertext--ml-floating-text-input-brutal')
], MlFloatingTextInputBrutal);
export { MlFloatingTextInputBrutal };
