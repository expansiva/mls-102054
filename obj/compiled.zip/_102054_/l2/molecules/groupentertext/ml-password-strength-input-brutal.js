var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PASSWORD STRENGTH INPUT — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupEnterText
// Herda PasswordStrengthInputMolecule (mls-102040): máscara, visibilidade,
// cálculo de força/critérios, estado. Sobrescreve só render().
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { PasswordStrengthInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-password-strength-input.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Enter password',
    emptyValue: '—',
    maskedValue: '••••••••',
    showPassword: 'Show password',
    hidePassword: 'Hide password',
    strengthWeak: 'Weak',
    strengthMedium: 'Medium',
    strengthStrong: 'Strong',
    strengthVeryStrong: 'Very Strong',
    criteriaMinLength: 'Minimum length',
    criteriaUppercase: 'Uppercase letter',
    criteriaNumber: 'Number',
    criteriaSymbol: 'Symbol',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Digite a senha',
        emptyValue: '—',
        maskedValue: '••••••••',
        showPassword: 'Mostrar senha',
        hidePassword: 'Ocultar senha',
        strengthWeak: 'Fraca',
        strengthMedium: 'Média',
        strengthStrong: 'Forte',
        strengthVeryStrong: 'Muito Forte',
        criteriaMinLength: 'Comprimento mínimo',
        criteriaUppercase: 'Letra maiúscula',
        criteriaNumber: 'Número',
        criteriaSymbol: 'Símbolo',
        loading: 'Carregando...',
    },
};
let PasswordStrengthInputBrutal = class PasswordStrengthInputBrutal extends PasswordStrengthInputMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-password-strength-input-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupentertext--ml-password-strength-input-brutal.is-disabled,
groupentertext--ml-password-strength-input-brutal .brutal-pw.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-req {
  color: #ef4444;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-view {
  color: #000;
  letter-spacing: 0.15em;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-affix {
  color: #000;
}
groupentertext--ml-password-strength-input-brutal .brutal-helper {
  color: #666;
}
groupentertext--ml-password-strength-input-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-loading {
  color: #000;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-wrapper {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-wrapper.is-focused {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-wrapper.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-wrapper.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-wrapper.is-readonly {
  background: #f5f5f5;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-input {
  background: transparent;
  border: none;
  outline: none;
  color: #000;
  font-family: inherit;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-input::placeholder {
  color: #999;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-input.is-disabled {
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-toggle {
  background: transparent;
  border: none;
  border-left: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-toggle:hover:not(.is-disabled) {
  background: #000;
  color: #fff;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-toggle.is-disabled {
  border-color: #999;
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-track {
  background: #e5e5e5;
  border: 2px solid #000;
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-bar {
  height: 0.5rem;
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-bar.is-weak {
  width: 25%;
  background: #ef4444;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-bar.is-medium {
  width: 50%;
  background: #f59e0b;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-bar.is-strong {
  width: 75%;
  background: #22c55e;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-bar.is-veryStrong {
  width: 100%;
  background: #000;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-strength-text {
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-strength-text.is-weak {
  color: #ef4444;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-strength-text.is-medium {
  color: #f59e0b;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-strength-text.is-strong {
  color: #22c55e;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-strength-text.is-veryStrong {
  color: #000;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-criteria {
  color: #999;
}
groupentertext--ml-password-strength-input-brutal .brutal-pw-criteria.is-met {
  color: #22c55e;
  font-weight: 700;
}
`);
        this.gMsg = messages.en;
    }
    get x() {
        return this;
    }
    strengthLabel(level) {
        switch (level) {
            case 'weak': return this.gMsg.strengthWeak;
            case 'medium': return this.gMsg.strengthMedium;
            case 'strong': return this.gMsg.strengthStrong;
            case 'veryStrong': return this.gMsg.strengthVeryStrong;
        }
    }
    // ---- classes/render brutal (nomes próprios) ----
    brutalContainerClasses() {
        return ['brutal-pw w-full', this.disabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalWrapperClasses() {
        return [
            'brutal-pw-wrapper flex items-center w-full',
            this.error ? 'is-error' : '',
            this.x.isFocused ? 'is-focused' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalInputClasses() {
        return ['brutal-pw-input flex-1 w-full px-3 py-2 text-sm', this.disabled || this.loading ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalToggleClasses() {
        return ['brutal-pw-toggle flex items-center justify-center w-10 h-10', this.disabled || this.loading ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalBarClasses(level) {
        return ['brutal-pw-bar', `is-${level}`].join(' ');
    }
    brutalTextClasses(level) {
        return ['brutal-pw-strength-text text-xs font-medium', `is-${level}`].join(' ');
    }
    brutalCriteriaClasses(isMet) {
        return ['brutal-pw-criteria flex items-center gap-2 text-xs', isMet ? 'is-met' : ''].filter(Boolean).join(' ');
    }
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label class="brutal-pw-label block mb-1.5 text-sm font-medium" id="label-${this.name}">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="brutal-pw-req ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    brutalPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<span class="brutal-pw-affix flex items-center pl-3">${unsafeHTML(this.getSlotContent('Prefix'))}</span>`;
    }
    brutalSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `<span class="brutal-pw-affix flex items-center pr-1">${unsafeHTML(this.getSlotContent('Suffix'))}</span>`;
    }
    brutalToggleButton() {
        if (this.rows > 1 || this.readonly)
            return html ``;
        const iconPath = this.x.isPasswordVisible
            ? 'M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88'
            : 'M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178zM15 12a3 3 0 11-6 0 3 3 0 016 0z';
        return html `
      <button
        type="button"
        class=${this.brutalToggleClasses()}
        @click=${() => this.x.togglePasswordVisibility()}
        ?disabled=${this.disabled || this.loading}
        aria-label=${this.x.isPasswordVisible ? this.gMsg.hidePassword : this.gMsg.showPassword}
        tabindex="-1"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
          <path stroke-linecap="round" stroke-linejoin="round" d=${iconPath} />
        </svg>
      </button>
    `;
    }
    brutalInput() {
        const placeholderText = this.placeholder || this.gMsg.placeholder;
        const inputType = this.x.isPasswordVisible ? 'text' : 'password';
        const displayValue = this.mask ? this.x.rawDisplay : this.value;
        return html `
      <div class=${this.brutalWrapperClasses()}>
        ${this.brutalPrefix()}
        <input
          type=${inputType}
          class=${this.brutalInputClasses()}
          .value=${displayValue}
          placeholder=${placeholderText}
          ?disabled=${this.disabled || this.loading}
          ?readonly=${this.readonly}
          ?required=${this.required}
          name=${this.name}
          autocomplete=${this.autocomplete || 'off'}
          aria-labelledby=${this.hasSlot('Label') ? `label-${this.name}` : ''}
          aria-describedby=${this.error ? `error-${this.name}` : ''}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          @input=${(e) => this.x.handleInput(e)}
          @focus=${() => this.x.handleFocus()}
          @blur=${() => this.x.handleBlur()}
        />
        ${this.brutalSuffix()} ${this.brutalToggleButton()}
      </div>
    `;
    }
    brutalStrengthIndicator() {
        if (this.loading)
            return html ``;
        const criteria = this.x.getCriteriaStatus();
        const level = this.x.getStrengthLevel(criteria);
        return html `
      <div class="mt-3 space-y-2">
        <div class="flex items-center gap-3">
          <div class="brutal-pw-track flex-1 h-2 overflow-hidden">
            <div class=${this.brutalBarClasses(level)}></div>
          </div>
          <span class=${this.brutalTextClasses(level)}> ${this.strengthLabel(level)} </span>
        </div>
        <div class="grid grid-cols-2 gap-1">
          ${this.brutalCriteriaItem(criteria.minLength, this.minLength !== null ? `${this.gMsg.criteriaMinLength} (${this.minLength})` : this.gMsg.criteriaMinLength)}
          ${this.brutalCriteriaItem(criteria.uppercase, this.gMsg.criteriaUppercase)}
          ${this.brutalCriteriaItem(criteria.number, this.gMsg.criteriaNumber)}
          ${this.brutalCriteriaItem(criteria.symbol, this.gMsg.criteriaSymbol)}
        </div>
      </div>
    `;
    }
    brutalCriteriaItem(isMet, label) {
        const iconPath = isMet ? 'M4.5 12.75l6 6 9-13.5' : 'M6 18L18 6M6 6l12 12';
        return html `
      <div class=${this.brutalCriteriaClasses(isMet)}>
        <svg class="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d=${iconPath} />
        </svg>
        <span>${label}</span>
      </div>
    `;
    }
    brutalHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<p class="brutal-helper mt-1.5 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
    }
    brutalErrorMsg() {
        if (!this.error)
            return html ``;
        return html `<p class="brutal-error-text mt-1.5 text-xs" id="error-${this.name}" role="alert">${unsafeHTML(String(this.error))}</p>`;
    }
    brutalLoading() {
        return html `
      <div class="brutal-pw-loading flex items-center justify-center py-4">
        <svg class="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span class="ml-2 text-sm">${this.gMsg.loading}</span>
      </div>
    `;
    }
    brutalViewMode() {
        const displayValue = this.value ? this.gMsg.maskedValue : this.gMsg.emptyValue;
        return html `
      <div class="flex items-center gap-2">
        ${this.brutalPrefix()}
        <span class="brutal-pw-view text-sm">${displayValue}</span>
        ${this.brutalSuffix()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (!this.isEditing) {
            return html `<div class=${this.brutalContainerClasses()}>${this.brutalLabel()} ${this.brutalViewMode()}</div>`;
        }
        if (this.loading) {
            return html `<div class=${this.brutalContainerClasses()}>${this.brutalLabel()} ${this.brutalLoading()}</div>`;
        }
        return html `
      <div class=${this.brutalContainerClasses()}>
        ${this.brutalLabel()} ${this.brutalInput()} ${this.brutalStrengthIndicator()}
        ${this.error ? this.brutalErrorMsg() : this.brutalHelper()}
      </div>
    `;
    }
};
PasswordStrengthInputBrutal = __decorate([
    customElement('groupentertext--ml-password-strength-input-brutal')
], PasswordStrengthInputBrutal);
export { PasswordStrengthInputBrutal };
