/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-password-strength-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PASSWORD STRENGTH INPUT MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupEnterText
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Enter password',
    emptyValue: '—',
    maskedValue: '••••••••',
    showPassword: 'Show password',
    hidePassword: 'Hide password',
    strengthWeak: 'Weak',
    strengthMedium: 'Medium',
    strengthStrong: 'Strong',
    strengthVeryStrong: 'Very Strong',
    criteriaMinLength: 'Minimum length',
    criteriaUppercase: 'Uppercase letter',
    criteriaNumber: 'Number',
    criteriaSymbol: 'Symbol',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Digite a senha',
        emptyValue: '—',
        maskedValue: '••••••••',
        showPassword: 'Mostrar senha',
        hidePassword: 'Ocultar senha',
        strengthWeak: 'Fraca',
        strengthMedium: 'Média',
        strengthStrong: 'Forte',
        strengthVeryStrong: 'Muito Forte',
        criteriaMinLength: 'Comprimento mínimo',
        criteriaUppercase: 'Letra maiúscula',
        criteriaNumber: 'Número',
        criteriaSymbol: 'Símbolo',
        loading: 'Carregando...',
    },
};
let PasswordStrengthInputMolecule = class PasswordStrengthInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-password-strength-input {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupentertext--ml-password-strength-input.is-disabled,
groupentertext--ml-password-strength-input .glass-pw.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input .glass-pw-label {
  color: rgba(255, 255, 255, 0.85);
}
groupentertext--ml-password-strength-input .glass-pw-req {
  color: #ffb4ab;
}
groupentertext--ml-password-strength-input .glass-pw-view {
  color: #fff;
  letter-spacing: 0.15em;
}
groupentertext--ml-password-strength-input .glass-pw-affix {
  color: rgba(255, 255, 255, 0.6);
}
groupentertext--ml-password-strength-input .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupentertext--ml-password-strength-input .glass-error-text {
  color: #ffb4ab;
}
groupentertext--ml-password-strength-input .glass-pw-loading {
  color: rgba(255, 255, 255, 0.7);
}
groupentertext--ml-password-strength-input .glass-pw-wrapper {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  transition: border-color 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupentertext--ml-password-strength-input .glass-pw-wrapper.is-focused {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
  background: rgba(255, 255, 255, 0.12);
}
groupentertext--ml-password-strength-input .glass-pw-wrapper.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupentertext--ml-password-strength-input .glass-pw-wrapper.is-disabled {
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input .glass-pw-wrapper.is-readonly {
  background: rgba(255, 255, 255, 0.04);
}
groupentertext--ml-password-strength-input .glass-pw-input {
  background: transparent;
  border: none;
  outline: none;
  color: #fff;
}
groupentertext--ml-password-strength-input .glass-pw-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupentertext--ml-password-strength-input .glass-pw-input.is-disabled {
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input .glass-pw-toggle {
  background: transparent;
  border: none;
  border-radius: 0 12px 12px 0;
  color: rgba(255, 255, 255, 0.6);
  cursor: pointer;
  transition: color 0.15s ease;
}
groupentertext--ml-password-strength-input .glass-pw-toggle:hover:not(.is-disabled) {
  color: #fff;
}
groupentertext--ml-password-strength-input .glass-pw-toggle.is-disabled {
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input .glass-pw-track {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 9999px;
}
groupentertext--ml-password-strength-input .glass-pw-bar {
  height: 0.5rem;
  border-radius: 9999px;
  transition: all 0.3s ease;
}
groupentertext--ml-password-strength-input .glass-pw-bar.is-weak {
  width: 25%;
  background: #f87171;
}
groupentertext--ml-password-strength-input .glass-pw-bar.is-medium {
  width: 50%;
  background: #fbbf24;
}
groupentertext--ml-password-strength-input .glass-pw-bar.is-strong {
  width: 75%;
  background: #4ade80;
}
groupentertext--ml-password-strength-input .glass-pw-bar.is-veryStrong {
  width: 100%;
  background: #34d399;
}
groupentertext--ml-password-strength-input .glass-pw-strength-text.is-weak {
  color: #fca5a5;
}
groupentertext--ml-password-strength-input .glass-pw-strength-text.is-medium {
  color: #fcd34d;
}
groupentertext--ml-password-strength-input .glass-pw-strength-text.is-strong {
  color: #86efac;
}
groupentertext--ml-password-strength-input .glass-pw-strength-text.is-veryStrong {
  color: #6ee7b7;
}
groupentertext--ml-password-strength-input .glass-pw-criteria {
  color: rgba(255, 255, 255, 0.55);
}
groupentertext--ml-password-strength-input .glass-pw-criteria.is-met {
  color: #86efac;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'password';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isPasswordVisible = false;
        this.isFocused = false;
        this.rawDisplay = '';
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.rawDisplay = this.applyMask(this.value);
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.rawDisplay = this.applyMask(value || '');
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // MASK LOGIC
    // ===========================================================================
    applyMask(rawValue) {
        if (!this.mask || !rawValue)
            return rawValue;
        let result = '';
        let rawIndex = 0;
        for (let i = 0; i < this.mask.length && rawIndex < rawValue.length; i++) {
            const maskChar = this.mask[i];
            const inputChar = rawValue[rawIndex];
            if (maskChar === '#') {
                if (/\d/.test(inputChar)) {
                    result += inputChar;
                    rawIndex++;
                }
                else {
                    rawIndex++;
                    i--;
                }
            }
            else if (maskChar === 'A') {
                if (/[a-zA-Z]/.test(inputChar)) {
                    result += inputChar;
                    rawIndex++;
                }
                else {
                    rawIndex++;
                    i--;
                }
            }
            else if (maskChar === '*') {
                result += inputChar;
                rawIndex++;
            }
            else {
                result += maskChar;
            }
        }
        return result;
    }
    extractRawValue(maskedValue) {
        if (!this.mask)
            return maskedValue;
        let raw = '';
        let maskIndex = 0;
        for (let i = 0; i < maskedValue.length && maskIndex < this.mask.length; i++) {
            const maskChar = this.mask[maskIndex];
            const inputChar = maskedValue[i];
            if (maskChar === '#' || maskChar === 'A' || maskChar === '*') {
                raw += inputChar;
                maskIndex++;
            }
            else {
                if (inputChar === maskChar) {
                    maskIndex++;
                }
            }
        }
        return raw;
    }
    // ===========================================================================
    // STRENGTH CALCULATION
    // ===========================================================================
    getCriteriaStatus() {
        const val = this.value || '';
        return {
            minLength: this.minLength === null || val.length >= this.minLength,
            uppercase: /[A-Z]/.test(val),
            number: /\d/.test(val),
            symbol: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~`]/.test(val),
        };
    }
    getStrengthLevel(criteria) {
        const metCount = Object.values(criteria).filter(Boolean).length;
        if (metCount <= 1)
            return 'weak';
        if (metCount === 2)
            return 'medium';
        if (metCount === 3)
            return 'strong';
        return 'veryStrong';
    }
    getStrengthLabel(level) {
        switch (level) {
            case 'weak':
                return this.msg.strengthWeak;
            case 'medium':
                return this.msg.strengthMedium;
            case 'strong':
                return this.msg.strengthStrong;
            case 'veryStrong':
                return this.msg.strengthVeryStrong;
        }
    }
    getStrengthBarClasses(level) {
        return ['glass-pw-bar', `is-${level}`].join(' ');
    }
    getStrengthTextClasses(level) {
        return ['glass-pw-strength-text text-xs font-medium', `is-${level}`].join(' ');
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        let newValue = input.value;
        if (this.mask) {
            const rawValue = this.extractRawValue(newValue);
            if (this.maxLength !== null && rawValue.length > this.maxLength) {
                return;
            }
            this.value = rawValue;
            this.rawDisplay = this.applyMask(rawValue);
        }
        else {
            if (this.maxLength !== null && newValue.length > this.maxLength) {
                newValue = newValue.slice(0, this.maxLength);
            }
            this.value = newValue;
            this.rawDisplay = newValue;
        }
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleFocus() {
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.isFocused = false;
        this.handleChange();
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    togglePasswordVisibility() {
        if (this.disabled || this.loading)
            return;
        this.isPasswordVisible = !this.isPasswordVisible;
    }
    // ===========================================================================
    // CSS CLASSES (glass)
    // ===========================================================================
    getContainerClasses() {
        return ['glass-pw w-full', this.disabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    getInputWrapperClasses() {
        const hasError = !!this.error;
        return [
            'glass-pw-wrapper flex items-center w-full',
            hasError ? 'is-error' : '',
            this.isFocused ? 'is-focused' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getInputClasses() {
        return [
            'glass-pw-input flex-1 w-full px-3 py-2 text-sm',
            this.disabled || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getToggleButtonClasses() {
        return [
            'glass-pw-toggle flex items-center justify-center w-10 h-10',
            this.disabled || this.loading ? 'is-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCriteriaItemClasses(isMet) {
        return ['glass-pw-criteria flex items-center gap-2 text-xs', isMet ? 'is-met' : ''].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label class="glass-pw-label block mb-1.5 text-sm font-medium" id="label-${this.name}">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="glass-pw-req ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
      <span class="glass-pw-affix flex items-center pl-3">${unsafeHTML(this.getSlotContent('Prefix'))}</span>
    `;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
      <span class="glass-pw-affix flex items-center pr-1">${unsafeHTML(this.getSlotContent('Suffix'))}</span>
    `;
    }
    renderToggleButton() {
        if (this.rows > 1 || this.readonly)
            return html ``;
        const iconPath = this.isPasswordVisible
            ? 'M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88'
            : 'M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178zM15 12a3 3 0 11-6 0 3 3 0 016 0z';
        return html `
      <button
        type="button"
        class=${this.getToggleButtonClasses()}
        @click=${this.togglePasswordVisibility}
        ?disabled=${this.disabled || this.loading}
        aria-label=${this.isPasswordVisible ? this.msg.hidePassword : this.msg.showPassword}
        tabindex="-1"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
          <path stroke-linecap="round" stroke-linejoin="round" d=${iconPath} />
        </svg>
      </button>
    `;
    }
    renderInput() {
        const placeholderText = this.placeholder || this.msg.placeholder;
        const inputType = this.isPasswordVisible ? 'text' : 'password';
        const displayValue = this.mask ? this.rawDisplay : this.value;
        return html `
      <div class=${this.getInputWrapperClasses()}>
        ${this.renderPrefix()}
        <input
          type=${inputType}
          class=${this.getInputClasses()}
          .value=${displayValue}
          placeholder=${placeholderText}
          ?disabled=${this.disabled || this.loading}
          ?readonly=${this.readonly}
          ?required=${this.required}
          name=${this.name}
          autocomplete=${this.autocomplete || 'off'}
          aria-labelledby=${this.hasSlot('Label') ? `label-${this.name}` : ''}
          aria-describedby=${this.error ? `error-${this.name}` : ''}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          @input=${this.handleInput}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
        />
        ${this.renderSuffix()} ${this.renderToggleButton()}
      </div>
    `;
    }
    renderStrengthIndicator() {
        if (this.loading)
            return html ``;
        const criteria = this.getCriteriaStatus();
        const level = this.getStrengthLevel(criteria);
        return html `
      <div class="mt-3 space-y-2">
        <div class="flex items-center gap-3">
          <div class="glass-pw-track flex-1 h-2 overflow-hidden">
            <div class=${this.getStrengthBarClasses(level)}></div>
          </div>
          <span class=${this.getStrengthTextClasses(level)}> ${this.getStrengthLabel(level)} </span>
        </div>
        <div class="grid grid-cols-2 gap-1">
          ${this.renderCriteriaItem(criteria.minLength, this.minLength !== null ? `${this.msg.criteriaMinLength} (${this.minLength})` : this.msg.criteriaMinLength)}
          ${this.renderCriteriaItem(criteria.uppercase, this.msg.criteriaUppercase)}
          ${this.renderCriteriaItem(criteria.number, this.msg.criteriaNumber)}
          ${this.renderCriteriaItem(criteria.symbol, this.msg.criteriaSymbol)}
        </div>
      </div>
    `;
    }
    renderCriteriaItem(isMet, label) {
        const iconPath = isMet ? 'M4.5 12.75l6 6 9-13.5' : 'M6 18L18 6M6 6l12 12';
        return html `
      <div class=${this.getCriteriaItemClasses(isMet)}>
        <svg class="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d=${iconPath} />
        </svg>
        <span>${label}</span>
      </div>
    `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<p class="glass-helper mt-1.5 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `
      <p class="glass-error-text mt-1.5 text-xs" id="error-${this.name}" role="alert">
        ${unsafeHTML(String(this.error))}
      </p>
    `;
    }
    renderLoading() {
        return html `
      <div class="glass-pw-loading flex items-center justify-center py-4">
        <svg class="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path
            class="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          ></path>
        </svg>
        <span class="ml-2 text-sm">${this.msg.loading}</span>
      </div>
    `;
    }
    renderViewMode() {
        const displayValue = this.value ? this.msg.maskedValue : this.msg.emptyValue;
        return html `
      <div class="flex items-center gap-2">
        ${this.renderPrefix()}
        <span class="glass-pw-view text-sm">${displayValue}</span>
        ${this.renderSuffix()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `<div class=${this.getContainerClasses()}>${this.renderLabel()} ${this.renderViewMode()}</div>`;
        }
        if (this.loading) {
            return html `<div class=${this.getContainerClasses()}>${this.renderLabel()} ${this.renderLoading()}</div>`;
        }
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()} ${this.renderInput()} ${this.renderStrengthIndicator()}
        ${this.error ? this.renderError() : this.renderHelper()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], PasswordStrengthInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], PasswordStrengthInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], PasswordStrengthInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], PasswordStrengthInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], PasswordStrengthInputMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], PasswordStrengthInputMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number })
], PasswordStrengthInputMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], PasswordStrengthInputMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], PasswordStrengthInputMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], PasswordStrengthInputMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], PasswordStrengthInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PasswordStrengthInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PasswordStrengthInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PasswordStrengthInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PasswordStrengthInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], PasswordStrengthInputMolecule.prototype, "isPasswordVisible", void 0);
__decorate([
    state()
], PasswordStrengthInputMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], PasswordStrengthInputMolecule.prototype, "rawDisplay", void 0);
PasswordStrengthInputMolecule = __decorate([
    customElement('groupentertext--ml-password-strength-input')
], PasswordStrengthInputMolecule);
export { PasswordStrengthInputMolecule };
