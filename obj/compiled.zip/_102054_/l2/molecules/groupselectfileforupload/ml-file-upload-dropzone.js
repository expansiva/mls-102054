/// <mls fileReference="_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FILE UPLOAD DROPZONE MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: select + fileForUpload
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    defaultTriggerTitle: 'Drag and drop files here',
    defaultTriggerSubtitle: 'or click to select files',
    loading: 'Uploading...',
    remove: 'Remove',
    noFiles: 'No files selected',
    ariaZone: 'File upload drop zone',
};
const messages = {
    en: message_en,
    pt: {
        defaultTriggerTitle: 'Arraste e solte arquivos aqui',
        defaultTriggerSubtitle: 'ou clique para selecionar arquivos',
        loading: 'Enviando...',
        remove: 'Remover',
        noFiles: 'Nenhum arquivo selecionado',
        ariaZone: 'Área de upload de arquivos',
    },
};
/// **collab_i18n_end**
let MlFileUploadDropzoneMolecule = class MlFileUploadDropzoneMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-file-upload-dropzone {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-label {
  color: rgba(255, 255, 255, 0.85);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-error-text {
  color: #ffb4ab;
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-loading {
  color: rgba(255, 255, 255, 0.6);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-title {
  color: rgba(255, 255, 255, 0.9);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-subtitle {
  color: rgba(255, 255, 255, 0.55);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-trigger-slot {
  color: rgba(255, 255, 255, 0.7);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-zone {
  background: rgba(255, 255, 255, 0.05);
  border: 1px dashed rgba(255, 255, 255, 0.3);
  border-radius: 14px;
  color: #fff;
  cursor: pointer;
  transition: border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-zone:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.4);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-zone.is-dragging {
  border-color: rgba(199, 210, 254, 0.9);
  background: rgba(199, 210, 254, 0.12);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-zone.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-zone.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-icon {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: rgba(255, 255, 255, 0.85);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-file {
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-file-name {
  color: #fff;
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-file-size {
  color: rgba(255, 255, 255, 0.55);
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-remove {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: color 0.12s ease;
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-remove:hover {
  color: #fff;
}
groupselectfileforupload--ml-file-upload-dropzone .glass-dz-remove:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        this.inputId = `file-upload-input-${Math.random().toString(36).slice(2)}`;
        this.labelId = `file-upload-label-${Math.random().toString(36).slice(2)}`;
        this.errorId = `file-upload-error-${Math.random().toString(36).slice(2)}`;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = [];
        this.error = '';
        this.multiple = false;
        this.accept = '';
        this.maxSizeKb = 0;
        this.maxFiles = 0;
        this.disabled = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.isDragging = false;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleZoneClick() {
        if (this.disabled || this.loading)
            return;
        const input = this.getInputElement();
        if (input)
            input.click();
    }
    handleZoneKeydown(e) {
        if (this.disabled || this.loading)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleZoneClick();
        }
    }
    handleDragOver(e) {
        if (this.disabled || this.loading)
            return;
        e.preventDefault();
        this.isDragging = true;
    }
    handleDragLeave() {
        if (this.disabled || this.loading)
            return;
        this.isDragging = false;
    }
    handleDrop(e) {
        if (this.disabled || this.loading)
            return;
        e.preventDefault();
        this.isDragging = false;
        const files = Array.from(e.dataTransfer?.files || []);
        this.processFiles(files);
    }
    handleInputChange(e) {
        if (this.disabled || this.loading)
            return;
        const input = e.target;
        const files = Array.from(input.files || []);
        this.processFiles(files);
        input.value = '';
    }
    handleRemoveFile(index) {
        if (this.disabled || this.loading)
            return;
        const next = [...this.value];
        next.splice(index, 1);
        this.value = next;
    }
    // =========================================================================
    // FILE PROCESSING
    // =========================================================================
    processFiles(files) {
        if (!files.length)
            return;
        const currentValue = this.multiple ? [...this.value] : [];
        const currentCount = this.multiple ? currentValue.length : 0;
        const { valid, rejects } = this.validateFiles(files, currentCount);
        rejects.forEach((r) => {
            if (r.files.length > 0) {
                this.dispatchEvent(new CustomEvent('reject', {
                    bubbles: true,
                    composed: true,
                    detail: { files: r.files, reason: r.reason },
                }));
            }
        });
        if (!valid.length)
            return;
        if (this.multiple) {
            this.value = currentValue.concat(valid);
        }
        else {
            this.value = [valid[0]];
        }
    }
    validateFiles(files, currentCount) {
        const typeRejected = [];
        const sizeRejected = [];
        const candidates = [];
        files.forEach((file) => {
            if (!this.isFileTypeAccepted(file)) {
                typeRejected.push(file);
                return;
            }
            if (this.maxSizeKb > 0 && file.size / 1024 > this.maxSizeKb) {
                sizeRejected.push(file);
                return;
            }
            candidates.push(file);
        });
        const available = this.getAvailableSlots(currentCount);
        let valid = [];
        const countRejected = [];
        if (available <= 0) {
            countRejected.push(...candidates);
        }
        else if (candidates.length > available) {
            valid = candidates.slice(0, available);
            countRejected.push(...candidates.slice(available));
        }
        else {
            valid = candidates;
        }
        return {
            valid,
            rejects: [
                { files: typeRejected, reason: 'type' },
                { files: sizeRejected, reason: 'size' },
                { files: countRejected, reason: 'count' },
            ],
        };
    }
    getAvailableSlots(currentCount) {
        if (!this.multiple)
            return 1;
        if (this.maxFiles > 0)
            return Math.max(this.maxFiles - currentCount, 0);
        return Number.POSITIVE_INFINITY;
    }
    isFileTypeAccepted(file) {
        const accept = (this.accept || '').trim();
        if (!accept)
            return true;
        const tokens = accept
            .split(',')
            .map((t) => t.trim().toLowerCase())
            .filter(Boolean);
        if (!tokens.length)
            return true;
        const fileName = file.name.toLowerCase();
        const fileType = (file.type || '').toLowerCase();
        return tokens.some((token) => {
            if (token.startsWith('.')) {
                return fileName.endsWith(token);
            }
            if (token.endsWith('/*')) {
                const prefix = token.replace('/*', '');
                return fileType.startsWith(prefix);
            }
            return fileType === token;
        });
    }
    formatFileSize(size) {
        if (size < 1024)
            return `${size} B`;
        const kb = size / 1024;
        if (kb < 1024)
            return `${kb.toFixed(1)} KB`;
        const mb = kb / 1024;
        return `${mb.toFixed(1)} MB`;
    }
    getInputElement() {
        return this.querySelector(`#${this.inputId}`);
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasError = !!this.error;
        const hasLabel = this.hasSlot('Label');
        const hasHelper = this.hasSlot('Helper');
        const containerClasses = ['w-full', 'space-y-2'].join(' ');
        const dropzoneClasses = [
            'glass-dz-zone w-full p-6',
            hasError ? 'is-error' : '',
            this.isDragging ? 'is-dragging' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
        return html `
      <div class=${containerClasses}>
        ${hasLabel
            ? html `<label id=${this.labelId} class="glass-dz-label text-sm font-medium">
              ${unsafeHTML(this.getSlotContent('Label'))}
            </label>`
            : html ``}

        <div
          class=${dropzoneClasses}
          role="button"
          tabindex=${this.disabled || this.loading ? '-1' : '0'}
          aria-labelledby=${hasLabel ? this.labelId : ''}
          aria-label=${hasLabel ? '' : this.msg.ariaZone}
          aria-invalid=${hasError ? 'true' : 'false'}
          aria-describedby=${hasError ? this.errorId : ''}
          @click=${this.handleZoneClick}
          @keydown=${this.handleZoneKeydown}
          @dragover=${this.handleDragOver}
          @dragleave=${this.handleDragLeave}
          @drop=${this.handleDrop}
        >
          ${this.renderTriggerContent()}
          <input
            id=${this.inputId}
            type="file"
            class="hidden"
            ?multiple=${this.multiple}
            accept=${this.accept}
            @change=${this.handleInputChange}
          />
        </div>

        ${this.renderFileList()}

        ${this.loading
            ? html `<div class="glass-dz-loading text-xs">${this.msg.loading}</div>`
            : html ``}

        ${hasError
            ? html `<p id=${this.errorId} class="glass-error-text text-xs">
              ${unsafeHTML(String(this.error))}
            </p>`
            : hasHelper
                ? html `<p class="glass-helper text-xs">
              ${unsafeHTML(this.getSlotContent('Helper'))}
            </p>`
                : html ``}
      </div>
    `;
    }
    renderTriggerContent() {
        if (this.hasSlot('Trigger')) {
            return html `<div class="glass-dz-trigger-slot text-sm">${unsafeHTML(this.getSlotContent('Trigger'))}</div>`;
        }
        return html `
      <div class="flex flex-col items-center gap-2 text-center">
        <div class="glass-dz-icon flex h-12 w-12 items-center justify-center rounded-full">
          <svg viewBox="0 0 24 24" class="h-6 w-6" aria-hidden="true">
            ${svg `<path fill="currentColor" d="M12 3a1 1 0 0 1 1 1v8.59l2.3-2.3a1 1 0 1 1 1.4 1.42l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 1 1 1.4-1.42L11 12.59V4a1 1 0 0 1 1-1Zm-7 14a1 1 0 0 1 1 1v1h12v-1a1 1 0 1 1 2 0v1a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1a1 1 0 0 1 1-1Z"/>`}
          </svg>
        </div>
        <div class="glass-dz-title text-sm font-medium">${this.msg.defaultTriggerTitle}</div>
        <div class="glass-dz-subtitle text-xs">${this.msg.defaultTriggerSubtitle}</div>
      </div>
    `;
    }
    renderFileList() {
        if (!this.value || this.value.length === 0) {
            return html ``;
        }
        return html `
      <ul class="space-y-2">
        ${this.value.map((file, index) => html `
            <li class="glass-dz-file flex items-center justify-between px-3 py-2">
              <div class="min-w-0">
                <div class="glass-dz-file-name truncate text-sm">${file.name}</div>
                <div class="glass-dz-file-size text-xs">${this.formatFileSize(file.size)}</div>
              </div>
              <button
                type="button"
                class="glass-dz-remove text-xs"
                @click=${() => this.handleRemoveFile(index)}
                ?disabled=${this.disabled || this.loading}
              >
                ${this.msg.remove}
              </button>
            </li>
          `)}
      </ul>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Object })
], MlFileUploadDropzoneMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFileUploadDropzoneMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileUploadDropzoneMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFileUploadDropzoneMolecule.prototype, "accept", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-size-kb' })
], MlFileUploadDropzoneMolecule.prototype, "maxSizeKb", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-files' })
], MlFileUploadDropzoneMolecule.prototype, "maxFiles", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileUploadDropzoneMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileUploadDropzoneMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlFileUploadDropzoneMolecule.prototype, "isDragging", void 0);
MlFileUploadDropzoneMolecule = __decorate([
    customElement('groupselectfileforupload--ml-file-upload-dropzone')
], MlFileUploadDropzoneMolecule);
export { MlFileUploadDropzoneMolecule };
