var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FILE UPLOAD DROPZONE — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupSelectFileForUpload
// Herda MlFileUploadDropzoneMolecule (mls-102040): drag-and-drop, validação por
// type/size/count, eventos reject, value (File[]), estado (isDragging).
// Sobrescreve apenas render() + helpers presentacionais com classes brutal.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlFileUploadDropzoneMolecule } from '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone.js';
/// **collab_i18n_start**
const message_en = {
    defaultTriggerTitle: 'Drag and drop files here',
    defaultTriggerSubtitle: 'or click to select files',
    loading: 'Uploading...',
    remove: 'Remove',
    noFiles: 'No files selected',
    ariaZone: 'File upload drop zone',
};
const messages = {
    en: message_en,
    pt: {
        defaultTriggerTitle: 'Arraste e solte arquivos aqui',
        defaultTriggerSubtitle: 'ou clique para selecionar arquivos',
        loading: 'Enviando...',
        remove: 'Remover',
        noFiles: 'Nenhum arquivo selecionado',
        ariaZone: 'Área de upload de arquivos',
    },
};
let MlFileUploadDropzoneBrutal = class MlFileUploadDropzoneBrutal extends MlFileUploadDropzoneMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-file-upload-dropzone-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-label {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  display: block;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-helper {
  color: #666;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-loading {
  color: #666;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-title {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-subtitle {
  color: #666;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-trigger-slot {
  color: #000;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-zone {
  background: #fff;
  border: 3px dashed #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-zone:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-zone.is-dragging {
  border-style: solid;
  border-color: #3b82f6;
  background: #eff6ff;
  box-shadow: 3px 3px 0 #3b82f6;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-zone.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-zone.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-icon {
  background: #eee;
  border: 3px solid #000;
  color: #000;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-file {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 2px 2px 0 #000;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-file-name {
  color: #000;
  font-weight: 700;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-file-size {
  color: #666;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-remove {
  background: #fff;
  border: 3px solid #000;
  color: #000;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  padding: 0.125rem 0.5rem;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-remove:hover {
  background: #000;
  color: #fff;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .brutal-dz-remove:disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
`);
        this.gMsg = messages.en;
        this.gLabelId = `file-upload-brutal-label-${Math.random().toString(36).slice(2)}`;
        this.gErrorId = `file-upload-brutal-error-${Math.random().toString(36).slice(2)}`;
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalTriggerContent() {
        if (this.hasSlot('Trigger')) {
            return html `<div class="brutal-dz-trigger-slot text-sm">${unsafeHTML(this.getSlotContent('Trigger'))}</div>`;
        }
        return html `
      <div class="flex flex-col items-center gap-2 text-center">
        <div class="brutal-dz-icon flex h-12 w-12 items-center justify-center">
          <svg viewBox="0 0 24 24" class="h-6 w-6" aria-hidden="true">
            ${svg `<path fill="currentColor" d="M12 3a1 1 0 0 1 1 1v8.59l2.3-2.3a1 1 0 1 1 1.4 1.42l-4 4a1 1 0 0 1-1.4 0l-4-4a1 1 0 1 1 1.4-1.42L11 12.59V4a1 1 0 0 1 1-1Zm-7 14a1 1 0 0 1 1 1v1h12v-1a1 1 0 1 1 2 0v1a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1a1 1 0 0 1 1-1Z"/>`}
          </svg>
        </div>
        <div class="brutal-dz-title text-sm font-bold">${this.gMsg.defaultTriggerTitle}</div>
        <div class="brutal-dz-subtitle text-xs">${this.gMsg.defaultTriggerSubtitle}</div>
      </div>
    `;
    }
    brutalFileList() {
        const x = this.x;
        if (!this.value || this.value.length === 0) {
            return html ``;
        }
        return html `
      <ul class="space-y-2">
        ${this.value.map((file, index) => html `
            <li class="brutal-dz-file flex items-center justify-between px-3 py-2">
              <div class="min-w-0">
                <div class="brutal-dz-file-name truncate text-sm">${file.name}</div>
                <div class="brutal-dz-file-size text-xs">${x.formatFileSize(file.size)}</div>
              </div>
              <button
                type="button"
                class="brutal-dz-remove text-xs"
                @click=${() => x.handleRemoveFile(index)}
                ?disabled=${this.disabled || this.loading}
              >
                ${this.gMsg.remove}
              </button>
            </li>
          `)}
      </ul>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        const hasError = !!this.error;
        const hasLabel = this.hasSlot('Label');
        const hasHelper = this.hasSlot('Helper');
        const containerClasses = ['w-full', 'space-y-2'].join(' ');
        const dropzoneClasses = [
            'brutal-dz-zone w-full p-6',
            hasError ? 'is-error' : '',
            x.isDragging ? 'is-dragging' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
        return html `
      <div class=${containerClasses}>
        ${hasLabel
            ? html `<label id=${this.gLabelId} class="brutal-dz-label text-sm font-bold">
              ${unsafeHTML(this.getSlotContent('Label'))}
            </label>`
            : html ``}

        <div
          class=${dropzoneClasses}
          role="button"
          tabindex=${this.disabled || this.loading ? '-1' : '0'}
          aria-labelledby=${hasLabel ? this.gLabelId : ''}
          aria-label=${hasLabel ? '' : this.gMsg.ariaZone}
          aria-invalid=${hasError ? 'true' : 'false'}
          aria-describedby=${hasError ? this.gErrorId : ''}
          @click=${() => x.handleZoneClick()}
          @keydown=${(e) => x.handleZoneKeydown(e)}
          @dragover=${(e) => x.handleDragOver(e)}
          @dragleave=${() => x.handleDragLeave()}
          @drop=${(e) => x.handleDrop(e)}
        >
          ${this.brutalTriggerContent()}
          <input
            id=${x.inputId}
            type="file"
            class="hidden"
            ?multiple=${this.multiple}
            accept=${this.accept}
            @change=${(e) => x.handleInputChange(e)}
          />
        </div>

        ${this.brutalFileList()}

        ${this.loading
            ? html `<div class="brutal-dz-loading text-xs">${this.gMsg.loading}</div>`
            : html ``}

        ${hasError
            ? html `<p id=${this.gErrorId} class="brutal-error-text text-xs">
              ${unsafeHTML(String(this.error))}
            </p>`
            : hasHelper
                ? html `<p class="brutal-helper text-xs">
              ${unsafeHTML(this.getSlotContent('Helper'))}
            </p>`
                : html ``}
      </div>
    `;
    }
};
MlFileUploadDropzoneBrutal = __decorate([
    customElement('groupselectfileforupload--ml-file-upload-dropzone-brutal')
], MlFileUploadDropzoneBrutal);
export { MlFileUploadDropzoneBrutal };
