var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FILE UPLOAD DROPZONE — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlFileUploadDropzoneMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlFileUploadDropzoneMolecule } from '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone.js';
let MlFileUploadDropzoneBrutal = class MlFileUploadDropzoneBrutal extends MlFileUploadDropzoneMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-file-upload-dropzone-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #666666;
  --ml-error: #ef4444;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  font-family: var(--ml-font-family);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-helper {
  color: var(--ml-on-surface-muted, #666666);
  font-family: var(--ml-font-family);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #666666);
  font-family: var(--ml-font-family);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone > .ml-text-muted {
  color: var(--ml-on-surface, #000000);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) dashed var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  color: var(--ml-on-surface, #000000);
  box-shadow: 3px 3px 0 #000000;
  transition: none;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-active {
  border-style: solid;
  border-color: var(--ml-primary, #3b82f6);
  background: #eff6ff;
  box-shadow: 3px 3px 0 #3b82f6;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 var(--ml-error, #ef4444);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-icon {
  background: #eeeeee;
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  color: var(--ml-on-surface, #000000);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-file-item {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: 2px 2px 0 #000000;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-file-remove {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  padding: 0.125rem 0.5rem;
  font-family: var(--ml-font-family);
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-file-remove:hover {
  background: #000000;
  color: #ffffff;
}
groupselectfileforupload--ml-file-upload-dropzone-brutal .ml-dropzone-file-remove:disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  border-color: #999999;
  cursor: not-allowed;
}
`);
    }
};
MlFileUploadDropzoneBrutal = __decorate([
    customElement('groupselectfileforupload--ml-file-upload-dropzone-brutal')
], MlFileUploadDropzoneBrutal);
export { MlFileUploadDropzoneBrutal };
