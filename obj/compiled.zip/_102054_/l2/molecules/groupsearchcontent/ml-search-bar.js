var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupsearchcontent/ml-search-bar.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML-SEARCH-BAR MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupSearchContent
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search',
    loading: 'Loading...',
    noResults: 'No results found',
    clear: 'Clear search',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlSearchBarMolecule = class MlSearchBarMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupsearchcontent--ml-search-bar {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupsearchcontent--ml-search-bar .glass-sb-label {
  color: rgba(255, 255, 255, 0.6);
}
groupsearchcontent--ml-search-bar .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupsearchcontent--ml-search-bar .glass-error-text {
  color: #ffb4ab;
}
groupsearchcontent--ml-search-bar .glass-sb-icon {
  color: rgba(255, 255, 255, 0.55);
}
groupsearchcontent--ml-search-bar .glass-sb-muted {
  color: rgba(255, 255, 255, 0.55);
}
groupsearchcontent--ml-search-bar .glass-sb-input {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  color: #fff;
  outline: none;
  transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupsearchcontent--ml-search-bar .glass-sb-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupsearchcontent--ml-search-bar .glass-sb-input:focus {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
  background: rgba(255, 255, 255, 0.12);
}
groupsearchcontent--ml-search-bar .glass-sb-input.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupsearchcontent--ml-search-bar .glass-sb-input.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupsearchcontent--ml-search-bar .glass-sb-clear {
  color: rgba(255, 255, 255, 0.55);
}
groupsearchcontent--ml-search-bar .glass-sb-clear:hover {
  color: #fff;
}
groupsearchcontent--ml-search-bar .glass-sb-panel {
  background: rgba(30, 27, 75, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 12px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
}
groupsearchcontent--ml-search-bar .glass-sb-option {
  background: transparent;
  border: 1px solid transparent;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupsearchcontent--ml-search-bar .glass-sb-option:hover:not(.is-disabled):not(.is-active) {
  background: rgba(255, 255, 255, 0.08);
}
groupsearchcontent--ml-search-bar .glass-sb-option.is-active {
  background: rgba(199, 210, 254, 0.18);
  color: #e0e7ff;
  border-color: rgba(199, 210, 254, 0.6);
}
groupsearchcontent--ml-search-bar .glass-sb-option.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        this.debounceTimer = null;
        this.componentId = `ml-search-bar-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Suggestion', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.debounce = 300;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.query = '';
        this.isOpen = false;
        this.highlightIndex = -1;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            const stringValue = value ?? '';
            const suggestions = this.getSuggestions();
            const matched = suggestions.find((s) => s.value === stringValue);
            this.query = matched ? matched.labelText : String(stringValue);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.disabled)
            return;
        const input = e.target;
        this.query = input.value;
        this.isOpen = true;
        this.highlightIndex = -1;
        if (!this.query) {
            this.value = null;
            this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
        }
        this.scheduleSearch();
    }
    handleFocus() {
        if (this.disabled)
            return;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        window.setTimeout(() => {
            this.isOpen = false;
            this.highlightIndex = -1;
        }, 100);
    }
    handleKeyDown(e) {
        if (this.disabled)
            return;
        const suggestions = this.getSuggestions();
        const maxIndex = suggestions.length - 1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.isOpen = true;
            this.highlightIndex = Math.min(maxIndex, this.highlightIndex + 1);
            return;
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.isOpen = true;
            this.highlightIndex = Math.max(-1, this.highlightIndex - 1);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (this.highlightIndex >= 0 && suggestions[this.highlightIndex]) {
                this.confirmSuggestion(suggestions[this.highlightIndex]);
            }
            else {
                this.confirmQuery();
            }
            return;
        }
        if (e.key === 'Escape') {
            this.isOpen = false;
            this.highlightIndex = -1;
        }
    }
    handleClearClick() {
        if (this.disabled)
            return;
        this.query = '';
        this.value = null;
        this.isOpen = false;
        this.highlightIndex = -1;
        this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
    }
    handleSuggestionClick(index) {
        if (this.disabled)
            return;
        const suggestions = this.getSuggestions();
        const suggestion = suggestions[index];
        if (suggestion) {
            this.confirmSuggestion(suggestion);
        }
    }
    // ===========================================================================
    // DATA + ACTIONS
    // ===========================================================================
    scheduleSearch() {
        if (this.debounceTimer) {
            window.clearTimeout(this.debounceTimer);
        }
        this.debounceTimer = window.setTimeout(() => {
            if (this.disabled)
                return;
            this.dispatchEvent(new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: { query: this.query },
            }));
        }, this.debounce);
    }
    confirmQuery() {
        if (this.disabled)
            return;
        if (!this.query) {
            this.value = null;
            this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
            return;
        }
        this.value = this.query;
        this.isOpen = false;
        this.highlightIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    confirmSuggestion(suggestion) {
        this.value = suggestion.value;
        this.query = suggestion.labelText;
        this.isOpen = false;
        this.highlightIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // ===========================================================================
    // RENDERING HELPERS (glass)
    // ===========================================================================
    getSuggestions() {
        return this.getSlots('Suggestion').map((el) => ({
            value: el.getAttribute('value') || '',
            labelHtml: el.innerHTML,
            labelText: el.textContent || '',
        }));
    }
    getInputClasses() {
        return [
            'glass-sb-input w-full pl-10 pr-10 py-2 text-sm',
            this.error ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'glass-sb-panel mt-2 p-2 space-y-1',
            this.isOpen ? 'block' : 'hidden',
        ].filter(Boolean).join(' ');
    }
    getSuggestionClasses(isActive) {
        return [
            'glass-sb-option w-full text-left px-3 py-2 text-sm',
            isActive ? 'is-active' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelId = `${this.componentId}-label`;
        return html `
      <label id=${labelId} class="glass-sb-label block mb-1 text-sm">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderHelperOrError() {
        if (this.error) {
            const errorId = `${this.componentId}-error`;
            return html `<p id=${errorId} class="glass-error-text mt-1 text-xs">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            const helperId = `${this.componentId}-helper`;
            return html `<p id=${helperId} class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderSuggestions() {
        const suggestions = this.getSuggestions();
        const hasSuggestions = suggestions.length > 0;
        const showEmpty = !this.loading && !hasSuggestions && this.query;
        return html `
      <div id=${`${this.componentId}-list`} class=${this.getPanelClasses()} role="listbox">
        ${this.loading ? html `
          <div class="glass-sb-muted px-3 py-2 text-sm">
            ${this.msg.loading}
          </div>
        ` : html ``}
        ${hasSuggestions ? suggestions.map((item, index) => html `
          <button
            class=${this.getSuggestionClasses(index === this.highlightIndex)}
            role="option"
            aria-selected=${index === this.highlightIndex}
            ?disabled=${this.disabled}
            @mousedown=${(e) => e.preventDefault()}
            @click=${() => this.handleSuggestionClick(index)}
          >
            ${unsafeHTML(item.labelHtml)}
          </button>
        `) : html ``}
        ${showEmpty ? html `
          <div class="glass-sb-muted px-3 py-2 text-sm">
            ${unsafeHTML(this.getSlotContent('Empty') || this.msg.noResults)}
          </div>
        ` : html ``}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelId = this.hasSlot('Label') ? `${this.componentId}-label` : undefined;
        const errorId = this.error ? `${this.componentId}-error` : undefined;
        const helperId = !this.error && this.hasSlot('Helper') ? `${this.componentId}-helper` : undefined;
        const describedBy = [errorId, helperId].filter(Boolean).join(' ') || undefined;
        const inputPlaceholder = this.placeholder || this.msg.placeholder;
        const showClear = !!this.query && !this.disabled;
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        <div class="relative">
          <span class="glass-sb-icon absolute left-3 top-1/2 -translate-y-1/2">
            <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
              ${svg `<path d="M10.5 3a7.5 7.5 0 1 1-4.24 13.68l-3.97 3.97a1 1 0 1 1-1.42-1.42l3.97-3.97A7.5 7.5 0 0 1 10.5 3zm0 2a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11z" fill="currentColor" />`}
            </svg>
          </span>
          <input
            class=${this.getInputClasses()}
            type="text"
            name=${this.name}
            .placeholder=${inputPlaceholder}
            .value=${this.query}
            ?disabled=${this.disabled}
            role="combobox"
            aria-expanded=${this.isOpen}
            aria-autocomplete="list"
            aria-controls=${`${this.componentId}-list`}
            aria-labelledby=${labelId || ''}
            aria-describedby=${describedBy || ''}
            aria-invalid=${this.error ? 'true' : 'false'}
            @input=${this.handleInput}
            @focus=${this.handleFocus}
            @blur=${this.handleBlur}
            @keydown=${this.handleKeyDown}
          />
          ${showClear ? html `
            <button
              class="glass-sb-clear absolute right-3 top-1/2 -translate-y-1/2"
              aria-label=${this.msg.clear}
              @mousedown=${(e) => e.preventDefault()}
              @click=${this.handleClearClick}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                ${svg `<path d="M6.7 5.3a1 1 0 0 1 1.4 0L12 9.17l3.9-3.88a1 1 0 1 1 1.4 1.42L13.42 10.6l3.88 3.9a1 1 0 0 1-1.42 1.4L12 12.02l-3.9 3.88a1 1 0 1 1-1.4-1.42l3.88-3.9-3.88-3.88a1 1 0 0 1 0-1.4z" fill="currentColor" />`}
              </svg>
            </button>
          ` : html ``}
        </div>
        ${this.renderSuggestions()}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlSearchBarMolecule.prototype, "debounce", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSearchBarMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSearchBarMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSearchBarMolecule.prototype, "query", void 0);
__decorate([
    state()
], MlSearchBarMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlSearchBarMolecule.prototype, "highlightIndex", void 0);
MlSearchBarMolecule = __decorate([
    customElement('groupsearchcontent--ml-search-bar')
], MlSearchBarMolecule);
export { MlSearchBarMolecule };
