var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupsearchcontent/ml-search-bar-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEARCH BAR — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlSearchBarMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSearchBarMolecule } from '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
let MlSearchBarBrutal = class MlSearchBarBrutal extends MlSearchBarMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupsearchcontent--ml-search-bar-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  font-family: var(--ml-font-family);
}
groupsearchcontent--ml-search-bar-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupsearchcontent--ml-search-bar-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family);
}
groupsearchcontent--ml-search-bar-brutal .ml-text-muted {
  color: #666666;
  font-family: var(--ml-font-family);
}
groupsearchcontent--ml-search-bar-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family);
  font-weight: 700;
}
groupsearchcontent--ml-search-bar-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupsearchcontent--ml-search-bar-brutal .ml-search-input {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
  transition: none;
}
groupsearchcontent--ml-search-bar-brutal .ml-search-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
}
groupsearchcontent--ml-search-bar-brutal .ml-search-border {
  border-color: var(--ml-outline-variant, #000000);
}
groupsearchcontent--ml-search-bar-brutal .ml-error-border {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 var(--ml-error, #ef4444);
}
groupsearchcontent--ml-search-bar-brutal .ml-search-focus:focus {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupsearchcontent--ml-search-bar-brutal .ml-search-icon {
  color: #000000;
}
groupsearchcontent--ml-search-bar-brutal .ml-search-clear {
  color: #000000;
}
groupsearchcontent--ml-search-bar-brutal .ml-search-clear:hover {
  color: var(--ml-error, #ef4444);
}
groupsearchcontent--ml-search-bar-brutal .ml-search-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
}
groupsearchcontent--ml-search-bar-brutal [role='option'] {
  background: transparent;
  border-width: 2px;
  border-radius: var(--ml-radius-sm, 0);
  font-family: var(--ml-font-family);
  cursor: pointer;
  transition: none;
}
groupsearchcontent--ml-search-bar-brutal [role='option']:hover:not(.ml-disabled):not(.ml-filter-chip-active) {
  background: var(--ml-surface-dim, #f0f0f0);
  border-color: #000000;
}
groupsearchcontent--ml-search-bar-brutal .ml-text.ml-search-icon {
  color: #666666;
  font-weight: 700;
}
groupsearchcontent--ml-search-bar-brutal .ml-filter-chip-active {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border: 2px solid var(--ml-outline-variant, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
}
`);
    }
};
MlSearchBarBrutal = __decorate([
    customElement('groupsearchcontent--ml-search-bar-brutal')
], MlSearchBarBrutal);
export { MlSearchBarBrutal };
