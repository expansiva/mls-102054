var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterdate/ml-date-picker.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// DATE PICKER MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: enter + date
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select a date',
    clear: 'Clear',
    loading: 'Loading...',
    emptyView: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma data',
        clear: 'Limpar',
        loading: 'Carregando...',
        emptyView: '—',
    },
};
/// **collab_i18n_end**
let MlDatePickerMolecule = class MlDatePickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-date-picker {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupenterdate--ml-date-picker .glass-dp-label {
  color: rgba(255, 255, 255, 0.7);
}
groupenterdate--ml-date-picker .glass-dp-req {
  color: #ffb4ab;
}
groupenterdate--ml-date-picker .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupenterdate--ml-date-picker .glass-error-text {
  color: #ffb4ab;
}
groupenterdate--ml-date-picker .glass-dp-view {
  color: #fff;
}
groupenterdate--ml-date-picker .glass-dp-icon {
  color: rgba(255, 255, 255, 0.6);
}
groupenterdate--ml-date-picker .glass-dp-loading {
  color: rgba(255, 255, 255, 0.6);
}
groupenterdate--ml-date-picker .glass-dp-trigger {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  color: #fff;
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupenterdate--ml-date-picker .glass-dp-trigger:focus-visible {
  outline: none;
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
}
groupenterdate--ml-date-picker .glass-dp-trigger.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupenterdate--ml-date-picker .glass-dp-trigger.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker .glass-dp-trigger.is-readonly {
  cursor: default;
}
groupenterdate--ml-date-picker .glass-dp-value {
  color: rgba(255, 255, 255, 0.45);
}
groupenterdate--ml-date-picker .glass-dp-value.has-value {
  color: #fff;
}
groupenterdate--ml-date-picker .glass-dp-panel {
  background: rgba(30, 27, 75, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 14px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
}
groupenterdate--ml-date-picker .glass-dp-month {
  color: #fff;
}
groupenterdate--ml-date-picker .glass-dp-weekday {
  color: rgba(255, 255, 255, 0.5);
}
groupenterdate--ml-date-picker .glass-dp-weeknum {
  color: rgba(255, 255, 255, 0.4);
}
groupenterdate--ml-date-picker .glass-dp-nav {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.75);
  cursor: pointer;
  transition: background 0.12s ease;
}
groupenterdate--ml-date-picker .glass-dp-nav:hover:not(.is-disabled) {
  background: rgba(255, 255, 255, 0.14);
}
groupenterdate--ml-date-picker .glass-dp-nav.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker .glass-dp-day {
  border-radius: 8px;
  border: 1px solid transparent;
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupenterdate--ml-date-picker .glass-dp-day:hover:not(.is-disabled):not(.is-selected) {
  background: rgba(255, 255, 255, 0.1);
}
groupenterdate--ml-date-picker .glass-dp-day.is-today {
  border-color: rgba(199, 210, 254, 0.7);
}
groupenterdate--ml-date-picker .glass-dp-day.is-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupenterdate--ml-date-picker .glass-dp-day.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker .glass-dp-clear {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: color 0.12s ease;
}
groupenterdate--ml-date-picker .glass-dp-clear:hover {
  color: #fff;
}
groupenterdate--ml-date-picker .glass-dp-clear:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.minDate = '';
        this.maxDate = '';
        this.placeholder = '';
        this.firstDayOfWeek = 0;
        this.showWeekNumbers = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.viewMonth = new Date().getUTCMonth();
        this.viewYear = new Date().getUTCFullYear();
        this.fieldId = `date-${Math.random().toString(36).slice(2)}`;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.syncViewToValue(this.value);
        this.handleOutsideClick = this.handleOutsideClick.bind(this);
        document.addEventListener('mousedown', this.handleOutsideClick);
    }
    disconnectedCallback() {
        document.removeEventListener('mousedown', this.handleOutsideClick);
        super.disconnectedCallback();
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const minAttr = this.getAttribute('min-date');
        const maxAttr = this.getAttribute('max-date');
        const editingAttr = this.getAttribute('is-editing');
        if (valueAttr === `{{${key}}}`) {
            this.syncViewToValue(value);
        }
        if (minAttr === `{{${key}}}` || maxAttr === `{{${key}}}`) {
            this.ensureViewWithinRange();
        }
        if (editingAttr === `{{${key}}}` && value === false) {
            this.isOpen = false;
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggleOpen() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.syncViewToValue(this.value);
        }
    }
    handleFocus() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleOutsideClick(e) {
        if (!this.isOpen)
            return;
        const path = e.composedPath();
        if (!path.includes(this)) {
            this.isOpen = false;
        }
    }
    handlePrevMonth() {
        if (!this.canNavigatePrev())
            return;
        const prev = this.addMonths(this.viewYear, this.viewMonth, -1);
        this.viewYear = prev.year;
        this.viewMonth = prev.month;
        this.dispatchEvent(new CustomEvent('monthChange', {
            bubbles: true,
            composed: true,
            detail: { year: this.viewYear, month: this.viewMonth + 1 },
        }));
    }
    handleNextMonth() {
        if (!this.canNavigateNext())
            return;
        const next = this.addMonths(this.viewYear, this.viewMonth, 1);
        this.viewYear = next.year;
        this.viewMonth = next.month;
        this.dispatchEvent(new CustomEvent('monthChange', {
            bubbles: true,
            composed: true,
            detail: { year: this.viewYear, month: this.viewMonth + 1 },
        }));
    }
    handleSelectDay(day) {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const iso = this.toIsoDate(this.viewYear, this.viewMonth, day);
        if (this.isDateDisabled(iso))
            return;
        this.value = iso;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleClear() {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        this.value = null;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.isOpen = false;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    syncViewToValue(value) {
        const parsed = this.parseIsoDate(value);
        if (parsed) {
            this.viewYear = parsed.year;
            this.viewMonth = parsed.month;
        }
        else {
            const now = new Date();
            this.viewYear = now.getUTCFullYear();
            this.viewMonth = now.getUTCMonth();
        }
        this.ensureViewWithinRange();
    }
    ensureViewWithinRange() {
        const min = this.parseIsoDate(this.minDate);
        const max = this.parseIsoDate(this.maxDate);
        if (min) {
            const minKey = this.toDateKey(min.year, min.month, min.day);
            const viewKey = this.toDateKey(this.viewYear, this.viewMonth, 1);
            if (viewKey < minKey) {
                this.viewYear = min.year;
                this.viewMonth = min.month;
            }
        }
        if (max) {
            const maxKey = this.toDateKey(max.year, max.month, max.day);
            const viewKey = this.toDateKey(this.viewYear, this.viewMonth, 1);
            if (viewKey > maxKey) {
                this.viewYear = max.year;
                this.viewMonth = max.month;
            }
        }
    }
    parseIsoDate(value) {
        if (!value)
            return null;
        const match = /^\d{4}-\d{2}-\d{2}$/.exec(value);
        if (!match)
            return null;
        const [year, month, day] = value.split('-').map((v) => Number(v));
        return { year, month: month - 1, day };
    }
    toIsoDate(year, month, day) {
        const m = `${month + 1}`.padStart(2, '0');
        const d = `${day}`.padStart(2, '0');
        return `${year}-${m}-${d}`;
    }
    toDateKey(year, month, day) {
        return year * 10000 + (month + 1) * 100 + day;
    }
    formatDisplay(value) {
        if (!value)
            return this.msg.emptyView;
        const parsed = this.parseIsoDate(value);
        if (!parsed)
            return this.msg.emptyView;
        const locale = this.locale || 'en-US';
        const date = new Date(Date.UTC(parsed.year, parsed.month, parsed.day));
        const fmt = new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            timeZone: 'UTC',
        });
        return fmt.format(date);
    }
    formatTriggerValue() {
        if (!this.value)
            return this.placeholder || this.msg.placeholder;
        const parsed = this.parseIsoDate(this.value);
        if (!parsed)
            return this.placeholder || this.msg.placeholder;
        const locale = this.locale || 'en-US';
        const date = new Date(Date.UTC(parsed.year, parsed.month, parsed.day));
        const fmt = new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            timeZone: 'UTC',
        });
        return fmt.format(date);
    }
    getWeekdayLabels() {
        const locale = this.locale || 'en-US';
        const formatter = new Intl.DateTimeFormat(locale, { weekday: 'short', timeZone: 'UTC' });
        const base = new Date(Date.UTC(2024, 0, 7));
        const labels = [];
        for (let i = 0; i < 7; i++) {
            const date = new Date(base.getTime() + i * 86400000);
            labels.push(formatter.format(date));
        }
        const shift = this.firstDayOfWeek % 7;
        return labels.slice(shift).concat(labels.slice(0, shift));
    }
    getDaysInMonth(year, month) {
        return new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
    }
    addMonths(year, month, delta) {
        const date = new Date(Date.UTC(year, month + delta, 1));
        return { year: date.getUTCFullYear(), month: date.getUTCMonth() };
    }
    isDateDisabled(iso) {
        const parsed = this.parseIsoDate(iso);
        if (!parsed)
            return true;
        const key = this.toDateKey(parsed.year, parsed.month, parsed.day);
        const min = this.parseIsoDate(this.minDate);
        const max = this.parseIsoDate(this.maxDate);
        if (min && key < this.toDateKey(min.year, min.month, min.day))
            return true;
        if (max && key > this.toDateKey(max.year, max.month, max.day))
            return true;
        return false;
    }
    canNavigatePrev() {
        const min = this.parseIsoDate(this.minDate);
        if (!min)
            return true;
        const prev = this.addMonths(this.viewYear, this.viewMonth, -1);
        const lastDayPrev = this.getDaysInMonth(prev.year, prev.month);
        const prevKey = this.toDateKey(prev.year, prev.month, lastDayPrev);
        const minKey = this.toDateKey(min.year, min.month, min.day);
        return prevKey >= minKey;
    }
    canNavigateNext() {
        const max = this.parseIsoDate(this.maxDate);
        if (!max)
            return true;
        const next = this.addMonths(this.viewYear, this.viewMonth, 1);
        const nextKey = this.toDateKey(next.year, next.month, 1);
        const maxKey = this.toDateKey(max.year, max.month, max.day);
        return nextKey <= maxKey;
    }
    getISOWeekNumber(date) {
        const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
        const dayNum = d.getUTCDay() || 7;
        d.setUTCDate(d.getUTCDate() + 4 - dayNum);
        const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
        return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    }
    // ===========================================================================
    // CLASSES (glass)
    // ===========================================================================
    getContainerClasses() {
        return 'relative w-full';
    }
    getTriggerClasses(hasError) {
        return [
            'glass-dp-trigger w-full px-3 py-2 text-sm flex items-center justify-between gap-2',
            hasError ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    getDayClasses(isToday, isSelected, disabled) {
        return [
            'glass-dp-day w-9 h-9 text-sm flex items-center justify-center',
            isSelected ? 'is-selected' : '',
            isToday && !isSelected ? 'is-today' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelId = `${this.fieldId}-label`;
        return html `
      <label id=${labelId} class="glass-dp-label mb-1 block text-sm">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="glass-dp-req"> *</span>` : html ``}
      </label>
    `;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id=${`${this.fieldId}-error`} class="glass-error-text mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${`${this.fieldId}-helper`} class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderCalendar() {
        if (!this.isOpen || this.loading || !this.isEditing)
            return html ``;
        const daysInMonth = this.getDaysInMonth(this.viewYear, this.viewMonth);
        const firstDay = new Date(Date.UTC(this.viewYear, this.viewMonth, 1)).getUTCDay();
        const offset = (firstDay - (this.firstDayOfWeek % 7) + 7) % 7;
        const totalCells = Math.ceil((offset + daysInMonth) / 7) * 7;
        const weekdayLabels = this.getWeekdayLabels();
        const today = new Date();
        const todayKey = this.toDateKey(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
        const selectedParsed = this.parseIsoDate(this.value);
        const selectedKey = selectedParsed ? this.toDateKey(selectedParsed.year, selectedParsed.month, selectedParsed.day) : null;
        const weeks = [];
        let currentDay = 1;
        for (let i = 0; i < totalCells; i++) {
            const rowIndex = Math.floor(i / 7);
            if (!weeks[rowIndex])
                weeks[rowIndex] = [];
            if (i < offset || currentDay > daysInMonth) {
                weeks[rowIndex].push(null);
            }
            else {
                weeks[rowIndex].push(currentDay);
                currentDay++;
            }
        }
        return html `
      <div class="glass-dp-panel absolute z-20 mt-2 w-full p-3">
        <div class="flex items-center justify-between mb-2">
          <button
            class="glass-dp-nav p-2 ${this.canNavigatePrev() ? '' : 'is-disabled'}"
            ?disabled=${!this.canNavigatePrev()}
            @click=${this.handlePrevMonth}
            aria-label="Previous month"
          >
            ${svg `<svg viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4"><path d="M12.7 15.3a1 1 0 0 1-1.4 0l-5-5a1 1 0 0 1 0-1.4l5-5a1 1 0 0 1 1.4 1.4L8.4 9l4.3 4.3a1 1 0 0 1 0 1.4z"></path></svg>`}
          </button>
          <div class="glass-dp-month text-sm" aria-live="polite">
            ${new Intl.DateTimeFormat(this.locale || 'en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(this.viewYear, this.viewMonth, 1)))}
          </div>
          <button
            class="glass-dp-nav p-2 ${this.canNavigateNext() ? '' : 'is-disabled'}"
            ?disabled=${!this.canNavigateNext()}
            @click=${this.handleNextMonth}
            aria-label="Next month"
          >
            ${svg `<svg viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4"><path d="M7.3 4.7a1 1 0 0 1 1.4 0l5 5a1 1 0 0 1 0 1.4l-5 5a1 1 0 1 1-1.4-1.4L11.6 10 7.3 5.7a1 1 0 0 1 0-1.4z"></path></svg>`}
          </button>
        </div>
        <div class="grid grid-cols-7 gap-1 mb-1 text-xs glass-dp-weekday">
          ${weekdayLabels.map((label) => html `<div class="text-center">${label}</div>`)}
        </div>
        <div class="grid grid-cols-${this.showWeekNumbers ? '8' : '7'} gap-1" role="grid">
          ${weeks.map((week, rowIndex) => {
            const weekDayIndex = Math.max(1, rowIndex * 7 - offset + 1);
            const weekDate = new Date(Date.UTC(this.viewYear, this.viewMonth, weekDayIndex));
            const weekNumber = this.getISOWeekNumber(weekDate);
            return html `
              ${this.showWeekNumbers ? html `<div class="glass-dp-weeknum w-9 h-9 text-xs flex items-center justify-center">${weekNumber}</div>` : html ``}
              ${week.map((day) => {
                if (!day) {
                    return html `<div class="w-9 h-9"></div>`;
                }
                const iso = this.toIsoDate(this.viewYear, this.viewMonth, day);
                const parsed = this.parseIsoDate(iso);
                const key = parsed ? this.toDateKey(parsed.year, parsed.month, parsed.day) : 0;
                const isToday = key === todayKey;
                const isSelected = selectedKey !== null && key === selectedKey;
                const disabled = this.isDateDisabled(iso);
                return html `
                  <button
                    class=${this.getDayClasses(isToday, isSelected, disabled)}
                    ?disabled=${disabled}
                    role="gridcell"
                    aria-selected=${isSelected}
                    aria-disabled=${disabled}
                    @click=${() => this.handleSelectDay(day)}
                  >
                    ${day}
                  </button>
                `;
            })}
            `;
        })}
        </div>
        <div class="mt-2 flex justify-end">
          <button
            class="glass-dp-clear text-xs"
            @click=${this.handleClear}
            ?disabled=${this.disabled || this.readonly || this.loading}
          >
            ${this.msg.clear}
          </button>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `
        <div class="w-full">
          ${this.renderLabel()}
          <p class="glass-dp-view text-sm">${this.formatDisplay(this.value)}</p>
        </div>
      `;
        }
        const hasError = !!this.error;
        const labelId = this.hasSlot('Label') ? `${this.fieldId}-label` : '';
        const describedBy = this.error ? `${this.fieldId}-error` : (this.hasSlot('Helper') ? `${this.fieldId}-helper` : '');
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}
        <input type="hidden" name=${this.name} .value=${this.value || ''} />
        <button
          id=${this.fieldId}
          class=${this.getTriggerClasses(hasError)}
          @click=${this.handleToggleOpen}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          aria-haspopup="dialog"
          aria-expanded=${this.isOpen}
          aria-labelledby=${labelId || nothing}
          aria-describedby=${describedBy || nothing}
          aria-invalid=${hasError ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          ?disabled=${this.disabled}
        >
          <span class="glass-dp-value ${this.value ? 'has-value' : ''}">
            ${this.formatTriggerValue()}
          </span>
          <span class="glass-dp-icon">
            ${svg `<svg viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4"><path d="M6 2a1 1 0 0 1 1 1v1h6V3a1 1 0 1 1 2 0v1h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1V3a1 1 0 0 1 1-1zm9 7H5v7a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9z"></path></svg>`}
          </span>
        </button>
        ${this.loading ? html `<div class="glass-dp-loading mt-2 text-xs">${this.msg.loading}</div>` : html ``}
        ${this.renderCalendar()}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlDatePickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatePickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatePickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatePickerMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-date' })
], MlDatePickerMolecule.prototype, "minDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-date' })
], MlDatePickerMolecule.prototype, "maxDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatePickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'first-day-of-week' })
], MlDatePickerMolecule.prototype, "firstDayOfWeek", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-week-numbers' })
], MlDatePickerMolecule.prototype, "showWeekNumbers", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDatePickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatePickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatePickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatePickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatePickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlDatePickerMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlDatePickerMolecule.prototype, "viewMonth", void 0);
__decorate([
    state()
], MlDatePickerMolecule.prototype, "viewYear", void 0);
__decorate([
    state()
], MlDatePickerMolecule.prototype, "fieldId", void 0);
MlDatePickerMolecule = __decorate([
    customElement('groupenterdate--ml-date-picker')
], MlDatePickerMolecule);
export { MlDatePickerMolecule };
