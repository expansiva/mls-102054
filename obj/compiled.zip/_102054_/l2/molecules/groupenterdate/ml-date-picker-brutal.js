var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterdate/ml-date-picker-brutal.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// DATE PICKER — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: enter + date
// Herda toda a lógica de MlDatePickerMolecule (mls-102040): date math, navegação
// de mês, range min/max, seleção de dia, outside-click e estado reativo
// (isOpen/viewYear/viewMonth). Sobrescreve apenas render()/calendário com classes
// brutal. A formatação de exibição é refeita localmente (i18n próprio) para não
// depender do `msg` privado do pai (que só é populado no render() original).
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { MlDatePickerMolecule } from '/_102040_/l2/molecules/groupenterdate/ml-date-picker.js';
/// **collab_i18n_start**
const message_en = { placeholder: 'Select a date', clear: 'Clear', loading: 'Loading...', emptyView: '—' };
const messages = {
    en: message_en,
    pt: { placeholder: 'Selecione uma data', clear: 'Limpar', loading: 'Carregando...', emptyView: '—' },
};
let MlDatePickerBrutal = class MlDatePickerBrutal extends MlDatePickerMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-date-picker-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-req {
  color: #ef4444;
}
groupenterdate--ml-date-picker-brutal .brutal-helper {
  color: #666;
}
groupenterdate--ml-date-picker-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-view {
  color: #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-icon {
  color: #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-loading {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-trigger {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-trigger:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-trigger.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-trigger.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-trigger.is-readonly {
  cursor: default;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-value {
  color: #999;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-value.has-value {
  color: #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-panel,
.brutal-dp-portal .brutal-dp-panel {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 6px 6px 0 #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-month,
.brutal-dp-portal .brutal-dp-month {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-weekday,
.brutal-dp-portal .brutal-dp-weekday {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-weeknum,
.brutal-dp-portal .brutal-dp-weeknum {
  color: #999;
  font-weight: 700;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-nav,
.brutal-dp-portal .brutal-dp-nav {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 2px 2px 0 #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-nav:hover:not(.is-disabled),
.brutal-dp-portal .brutal-dp-nav:hover:not(.is-disabled) {
  background: #000;
  color: #fff;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-nav:active:not(.is-disabled),
.brutal-dp-portal .brutal-dp-nav:active:not(.is-disabled) {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupenterdate--ml-date-picker-brutal .brutal-dp-nav.is-disabled,
.brutal-dp-portal .brutal-dp-nav.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-day,
.brutal-dp-portal .brutal-dp-day {
  border-radius: 0;
  border: 2px solid transparent;
  color: #000;
  cursor: pointer;
  font-weight: 700;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-day:hover:not(.is-disabled):not(.is-selected),
.brutal-dp-portal .brutal-dp-day:hover:not(.is-disabled):not(.is-selected) {
  background: #f0f0f0;
  border-color: #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-day.is-today,
.brutal-dp-portal .brutal-dp-day.is-today {
  border-color: #3b82f6;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-day.is-selected,
.brutal-dp-portal .brutal-dp-day.is-selected {
  background: #000;
  border-color: #000;
  color: #fff;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-day.is-disabled,
.brutal-dp-portal .brutal-dp-day.is-disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-clear,
.brutal-dp-portal .brutal-dp-clear {
  background: #fff;
  border: 2px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-clear:hover,
.brutal-dp-portal .brutal-dp-clear:hover {
  background: #000;
  color: #fff;
}
groupenterdate--ml-date-picker-brutal .brutal-dp-clear:active,
.brutal-dp-portal .brutal-dp-clear:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupenterdate--ml-date-picker-brutal .brutal-dp-clear:disabled,
.brutal-dp-portal .brutal-dp-clear:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
`);
        this.portalClassName = 'brutal-dp-portal';
        this.bMsg = messages.en;
        this.bFieldId = `dp-brutal-${Math.random().toString(36).slice(2)}`;
    }
    get x() {
        return this;
    }
    // --- formatação de exibição (própria, i18n local) ---
    fmtDate(value) {
        if (!value)
            return '';
        const p = this.x.parseIsoDate(value);
        if (!p)
            return '';
        try {
            return new Intl.DateTimeFormat(this.locale || 'en-US', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                timeZone: 'UTC',
            }).format(new Date(Date.UTC(p.year, p.month, p.day)));
        }
        catch {
            return value;
        }
    }
    getTriggerText() {
        return this.value ? this.fmtDate(this.value) : this.placeholder || this.bMsg.placeholder;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalTriggerClasses(hasError) {
        return [
            'brutal-dp-trigger w-full px-3 py-2 text-sm flex items-center justify-between gap-2',
            hasError ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    brutalDayClasses(isToday, isSelected, disabled) {
        return [
            'brutal-dp-day w-9 h-9 text-sm flex items-center justify-center',
            isSelected ? 'is-selected' : '',
            isToday && !isSelected ? 'is-today' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${`${this.bFieldId}-label`} class="brutal-dp-label mb-1 block text-sm">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="brutal-dp-req"> *</span>` : html ``}
      </label>
    `;
    }
    brutalHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id=${`${this.bFieldId}-error`} class="brutal-error-text mt-1 text-xs">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${`${this.bFieldId}-helper`} class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    getPortalTemplate() {
        const x = this.x;
        const viewYear = x.viewYear;
        const viewMonth = x.viewMonth;
        const daysInMonth = x.getDaysInMonth(viewYear, viewMonth);
        const firstDay = new Date(Date.UTC(viewYear, viewMonth, 1)).getUTCDay();
        const offset = (firstDay - (this.firstDayOfWeek % 7) + 7) % 7;
        const totalCells = Math.ceil((offset + daysInMonth) / 7) * 7;
        const weekdayLabels = x.getWeekdayLabels();
        const today = new Date();
        const todayKey = x.toDateKey(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
        const selectedParsed = x.parseIsoDate(this.value);
        const selectedKey = selectedParsed ? x.toDateKey(selectedParsed.year, selectedParsed.month, selectedParsed.day) : null;
        const weeks = [];
        let currentDay = 1;
        for (let i = 0; i < totalCells; i++) {
            const rowIndex = Math.floor(i / 7);
            if (!weeks[rowIndex])
                weeks[rowIndex] = [];
            if (i < offset || currentDay > daysInMonth) {
                weeks[rowIndex].push(null);
            }
            else {
                weeks[rowIndex].push(currentDay);
                currentDay++;
            }
        }
        return html `
      <div class="brutal-dp-panel mt-2 p-3">
        <div class="flex items-center justify-between mb-2">
          <button
            class="brutal-dp-nav p-2 ${x.canNavigatePrev() ? '' : 'is-disabled'}"
            ?disabled=${!x.canNavigatePrev()}
            @click=${() => x.handlePrevMonth()}
            aria-label="Previous month"
          >
            ${svg `<svg viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4"><path d="M12.7 15.3a1 1 0 0 1-1.4 0l-5-5a1 1 0 0 1 0-1.4l5-5a1 1 0 0 1 1.4 1.4L8.4 9l4.3 4.3a1 1 0 0 1 0 1.4z"></path></svg>`}
          </button>
          <div class="brutal-dp-month text-sm" aria-live="polite">
            ${new Intl.DateTimeFormat(this.locale || 'en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(viewYear, viewMonth, 1)))}
          </div>
          <button
            class="brutal-dp-nav p-2 ${x.canNavigateNext() ? '' : 'is-disabled'}"
            ?disabled=${!x.canNavigateNext()}
            @click=${() => x.handleNextMonth()}
            aria-label="Next month"
          >
            ${svg `<svg viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4"><path d="M7.3 4.7a1 1 0 0 1 1.4 0l5 5a1 1 0 0 1 0 1.4l-5 5a1 1 0 1 1-1.4-1.4L11.6 10 7.3 5.7a1 1 0 0 1 0-1.4z"></path></svg>`}
          </button>
        </div>
        <div class="grid grid-cols-7 gap-1 mb-1 text-xs brutal-dp-weekday">
          ${weekdayLabels.map((label) => html `<div class="text-center">${label}</div>`)}
        </div>
        <div class="grid grid-cols-${this.showWeekNumbers ? '8' : '7'} gap-1" role="grid">
          ${weeks.map((week, rowIndex) => {
            const weekDayIndex = Math.max(1, rowIndex * 7 - offset + 1);
            const weekDate = new Date(Date.UTC(viewYear, viewMonth, weekDayIndex));
            const weekNumber = x.getISOWeekNumber(weekDate);
            return html `
              ${this.showWeekNumbers ? html `<div class="brutal-dp-weeknum w-9 h-9 text-xs flex items-center justify-center">${weekNumber}</div>` : html ``}
              ${week.map((day) => {
                if (!day)
                    return html `<div class="w-9 h-9"></div>`;
                const iso = x.toIsoDate(viewYear, viewMonth, day);
                const parsed = x.parseIsoDate(iso);
                const key = parsed ? x.toDateKey(parsed.year, parsed.month, parsed.day) : 0;
                const isToday = key === todayKey;
                const isSelected = selectedKey !== null && key === selectedKey;
                const disabled = x.isDateDisabled(iso);
                return html `
                  <button
                    class=${this.brutalDayClasses(isToday, isSelected, disabled)}
                    ?disabled=${disabled}
                    role="gridcell"
                    aria-selected=${isSelected}
                    aria-disabled=${disabled}
                    @click=${() => x.handleSelectDay(day)}
                  >
                    ${day}
                  </button>
                `;
            })}
            `;
        })}
        </div>
        <div class="mt-2 flex justify-end">
          <button
            class="brutal-dp-clear text-xs"
            @click=${() => x.handleClear()}
            ?disabled=${this.disabled || this.readonly || this.loading}
          >
            ${this.bMsg.clear}
          </button>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — lógica herdada via this.x
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        const x = this.x;
        if (!this.isEditing) {
            const display = this.value ? this.fmtDate(this.value) : this.bMsg.emptyView;
            return html `
        <div class="w-full">
          ${this.brutalLabel()}
          <p class="brutal-dp-view text-sm">${display}</p>
        </div>
      `;
        }
        const hasError = !!this.error;
        const labelId = this.hasSlot('Label') ? `${this.bFieldId}-label` : '';
        const describedBy = this.error ? `${this.bFieldId}-error` : this.hasSlot('Helper') ? `${this.bFieldId}-helper` : '';
        return html `
      <div class="relative w-full">
        ${this.brutalLabel()}
        <input type="hidden" name=${this.name} .value=${this.value || ''} />
        <button
          id=${this.bFieldId}
          class=${this.brutalTriggerClasses(hasError)}
          @click=${() => x.handleToggleOpen()}
          @focus=${() => x.handleFocus()}
          @blur=${() => x.handleBlur()}
          aria-haspopup="dialog"
          aria-expanded=${x.isOpen}
          aria-labelledby=${labelId || nothing}
          aria-describedby=${describedBy || nothing}
          aria-invalid=${hasError ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          ?disabled=${this.disabled}
        >
          <span class="brutal-dp-value ${this.value ? 'has-value' : ''}">${this.getTriggerText()}</span>
          <span class="brutal-dp-icon">
            ${svg `<svg viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4"><path d="M6 2a1 1 0 0 1 1 1v1h6V3a1 1 0 1 1 2 0v1h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1V3a1 1 0 0 1 1-1zm9 7H5v7a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9z"></path></svg>`}
          </span>
        </button>
        ${this.loading ? html `<div class="brutal-dp-loading mt-2 text-xs">${this.bMsg.loading}</div>` : html ``}
        ${this.brutalHelperOrError()}
      </div>
    `;
    }
};
MlDatePickerBrutal = __decorate([
    customElement('groupenterdate--ml-date-picker-brutal')
], MlDatePickerBrutal);
export { MlDatePickerBrutal };
