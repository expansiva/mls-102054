var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML LINEAR PROGRESS — BRUTALISM por HERANCA (mls-102054)
// =============================================================================
// Skill Group: groupShowProgress
// Herda LinearProgressMolecule (mls-102040): contrato/props (value, size, label,
// showValue, variant) e clamp. Sobrescreve so render() + helpers de aparencia.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { LinearProgressMolecule } from '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress.js';
let LinearProgressBrutal = class LinearProgressBrutal extends LinearProgressMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-linear-progress-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-value {
  color: #000;
  font-weight: 700;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-track {
  background: #e5e5e5;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp--xs {
  height: 0.375rem;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp--sm {
  height: 0.5rem;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp--md {
  height: 0.75rem;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp--lg {
  height: 1rem;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-fill {
  border-radius: 0;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-fill.is-default {
  background: #3b82f6;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-fill.is-success {
  background: #10b981;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-fill.is-warning {
  background: #f59e0b;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-fill.is-danger {
  background: #ef4444;
}
groupshowprogress--ml-linear-progress-brutal .brutal-lp-fill.is-indeterminate {
  width: 40% !important;
  animation: brutal-lp-indeterminate 1.2s steps(20) infinite;
}
@keyframes brutal-lp-indeterminate {
  0% {
    transform: translateX(-60%);
  }
  100% {
    transform: translateX(160%);
  }
}
`);
    }
    get x() {
        return this;
    }
    // ---- helpers presentacionais (brutal) — nomes proprios p/ nao colidir com os private do pai ----
    brutalSizeClasses() {
        const sizeMap = {
            xs: 'brutal-lp--xs',
            sm: 'brutal-lp--sm',
            md: 'brutal-lp--md',
            lg: 'brutal-lp--lg',
        };
        return sizeMap[this.size] || sizeMap.md;
    }
    brutalTrackClasses() {
        return 'brutal-lp-track w-full overflow-hidden';
    }
    brutalFillClasses(isIndeterminate) {
        return ['brutal-lp-fill h-full', `is-${this.variant}`, isIndeterminate ? 'is-indeterminate' : '']
            .filter(Boolean)
            .join(' ');
    }
    brutalValueText(value) {
        if (value === null || !this.showValue)
            return null;
        const textClasses = ['brutal-lp-value min-w-[3rem] text-right', this.x.getTextSizeClasses()].join(' ');
        return html `<span class="${textClasses}">${Math.round(value)}%</span>`;
    }
    // ===========================================================================
    // RENDER (override) — logica/clamp herdados via this.x
    // ===========================================================================
    render() {
        const normalized = this.x.getNormalizedValue();
        const isIndeterminate = normalized === null;
        const trackClasses = [this.brutalTrackClasses(), this.brutalSizeClasses()].join(' ');
        const fillClasses = this.brutalFillClasses(isIndeterminate);
        const widthStyle = isIndeterminate ? '' : `width: ${normalized}%;`;
        const ariaAttrs = {
            role: 'progressbar',
            'aria-label': this.label || undefined,
            'aria-valuemin': isIndeterminate ? undefined : '0',
            'aria-valuemax': isIndeterminate ? undefined : '100',
            'aria-valuenow': isIndeterminate ? undefined : String(normalized),
        };
        return html `
      <div class="w-full flex items-center gap-2" ...=${ariaAttrs}>
        <div class="${trackClasses}">
          <div class="${fillClasses}" style="${widthStyle}" aria-hidden="true"></div>
        </div>
        ${this.brutalValueText(isIndeterminate ? null : normalized)}
      </div>
    `;
    }
};
LinearProgressBrutal = __decorate([
    customElement('groupshowprogress--ml-linear-progress-brutal')
], LinearProgressBrutal);
export { LinearProgressBrutal };
