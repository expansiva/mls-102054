var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupshowprogress/ml-linear-progress.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LINEAR PROGRESS MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupShowProgress
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let LinearProgressMolecule = class LinearProgressMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-linear-progress {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupshowprogress--ml-linear-progress .glass-lp-value {
  color: rgba(255, 255, 255, 0.7);
}
groupshowprogress--ml-linear-progress .glass-lp-track {
  background: rgba(255, 255, 255, 0.14);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 9999px;
}
groupshowprogress--ml-linear-progress .glass-lp--xs {
  height: 0.375rem;
}
groupshowprogress--ml-linear-progress .glass-lp--sm {
  height: 0.5rem;
}
groupshowprogress--ml-linear-progress .glass-lp--md {
  height: 0.75rem;
}
groupshowprogress--ml-linear-progress .glass-lp--lg {
  height: 1rem;
}
groupshowprogress--ml-linear-progress .glass-lp-fill {
  border-radius: 9999px;
  transition: width 0.3s ease-out;
}
groupshowprogress--ml-linear-progress .glass-lp-fill.is-default {
  background: linear-gradient(90deg, #818cf8, #c7d2fe);
}
groupshowprogress--ml-linear-progress .glass-lp-fill.is-success {
  background: linear-gradient(90deg, #10b981, #6ee7b7);
}
groupshowprogress--ml-linear-progress .glass-lp-fill.is-warning {
  background: linear-gradient(90deg, #f59e0b, #fcd34d);
}
groupshowprogress--ml-linear-progress .glass-lp-fill.is-danger {
  background: linear-gradient(90deg, #ef4444, #fca5a5);
}
groupshowprogress--ml-linear-progress .glass-lp-fill.is-indeterminate {
  width: 40% !important;
  animation: glass-lp-indeterminate 1.2s ease-in-out infinite;
}
@keyframes glass-lp-indeterminate {
  0% {
    transform: translateX(-60%);
  }
  100% {
    transform: translateX(160%);
  }
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
        this.variant = 'default';
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getNormalizedValue() {
        if (this.value === null || this.value === undefined)
            return null;
        const clamped = Math.max(0, Math.min(100, this.value));
        return clamped;
    }
    getSizeClasses() {
        const sizeMap = {
            xs: 'glass-lp--xs',
            sm: 'glass-lp--sm',
            md: 'glass-lp--md',
            lg: 'glass-lp--lg',
        };
        return sizeMap[this.size] || sizeMap.md;
    }
    getTextSizeClasses() {
        const sizeMap = {
            xs: 'text-xs',
            sm: 'text-xs',
            md: 'text-sm',
            lg: 'text-sm',
        };
        return sizeMap[this.size] || sizeMap.md;
    }
    getTrackClasses() {
        return 'glass-lp-track w-full overflow-hidden';
    }
    getFillClasses(isIndeterminate) {
        return [
            'glass-lp-fill h-full',
            `is-${this.variant}`,
            isIndeterminate ? 'is-indeterminate' : '',
        ].filter(Boolean).join(' ');
    }
    renderValueText(value) {
        if (value === null || !this.showValue)
            return null;
        const textClasses = ['glass-lp-value min-w-[3rem] text-right', this.getTextSizeClasses()].join(' ');
        return html `<span class="${textClasses}">${Math.round(value)}%</span>`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const normalized = this.getNormalizedValue();
        const isIndeterminate = normalized === null;
        const trackClasses = [this.getTrackClasses(), this.getSizeClasses()].join(' ');
        const fillClasses = this.getFillClasses(isIndeterminate);
        const widthStyle = isIndeterminate ? '' : `width: ${normalized}%;`;
        const ariaAttrs = {
            role: 'progressbar',
            'aria-label': this.label || undefined,
            'aria-valuemin': isIndeterminate ? undefined : '0',
            'aria-valuemax': isIndeterminate ? undefined : '100',
            'aria-valuenow': isIndeterminate ? undefined : String(normalized),
        };
        return html `
      <div class="w-full flex items-center gap-2" ...=${ariaAttrs}>
        <div class="${trackClasses}">
          <div class="${fillClasses}" style="${widthStyle}" aria-hidden="true"></div>
        </div>
        ${this.renderValueText(isIndeterminate ? null : normalized)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], LinearProgressMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], LinearProgressMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], LinearProgressMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], LinearProgressMolecule.prototype, "showValue", void 0);
__decorate([
    propertyDataSource({ type: String })
], LinearProgressMolecule.prototype, "variant", void 0);
LinearProgressMolecule = __decorate([
    customElement('groupshowprogress--ml-linear-progress')
], LinearProgressMolecule);
export { LinearProgressMolecule };
