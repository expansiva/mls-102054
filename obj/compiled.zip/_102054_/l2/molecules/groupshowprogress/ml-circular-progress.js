var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupshowprogress/ml-circular-progress.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CIRCULAR PROGRESS MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupShowProgress
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let CircularProgressMolecule = class CircularProgressMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-circular-progress {
  display: inline-block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupshowprogress--ml-circular-progress .glass-cp-track {
  stroke: rgba(255, 255, 255, 0.15);
}
groupshowprogress--ml-circular-progress .glass-cp-fill {
  stroke: #c7d2fe;
  transition: stroke-dashoffset 0.4s ease-out;
  filter: drop-shadow(0 0 4px rgba(199, 210, 254, 0.5));
}
groupshowprogress--ml-circular-progress .glass-cp-value {
  color: rgba(255, 255, 255, 0.9);
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = [];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const determinate = this.isDeterminate();
        const clampedValue = determinate ? this.getClampedValue() : null;
        const showText = determinate && this.showValue;
        const ariaAttrs = this.getAriaAttributes(clampedValue);
        return html `
      <div class="${this.getWrapperClasses()}" role="progressbar" aria-label="${this.label || 'Progress'}" ${ariaAttrs}>
        ${this.renderSvg(clampedValue, determinate)}
        ${showText ? html `<div class="${this.getValueTextClasses()}">${Math.round(clampedValue || 0)}%</div>` : html ``}
      </div>
    `;
    }
    // ==========================================================================
    // SVG RENDERING
    // ==========================================================================
    renderSvg(value, determinate) {
        const radius = 45;
        const circumference = 2 * Math.PI * radius;
        const dashOffset = determinate && value !== null
            ? circumference * (1 - value / 100)
            : circumference * 0.25;
        return html `
      <svg viewBox="0 0 100 100" class="${this.getSvgClasses()}" aria-hidden="true">
        ${svg `
          <circle cx="50" cy="50" r="45" fill="none" stroke-width="10" class="glass-cp-track"></circle>
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke-width="10"
            stroke-linecap="round"
            stroke-dasharray="${circumference}"
            stroke-dashoffset="${dashOffset}"
            class="glass-cp-fill"
            transform="${determinate ? 'rotate(-90 50 50)' : ''}"
          >
            ${!determinate
            ? svg `<animateTransform
                  attributeName="transform"
                  attributeType="XML"
                  type="rotate"
                  from="0 50 50"
                  to="360 50 50"
                  dur="1s"
                  repeatCount="indefinite"
                ></animateTransform>`
            : svg ``}
          </circle>
        `}
      </svg>
    `;
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isDeterminate() {
        return this.value !== null && !Number.isNaN(this.value);
    }
    getClampedValue() {
        const raw = this.value ?? 0;
        return Math.min(100, Math.max(0, raw));
    }
    getAriaAttributes(value) {
        if (!this.isDeterminate() || value === null) {
            return html ``;
        }
        return html `aria-valuenow="${value}" aria-valuemin="0" aria-valuemax="100"`;
    }
    getWrapperClasses() {
        return ['glass-cp relative inline-flex items-center justify-center', this.getSizeClasses()].join(' ');
    }
    getSvgClasses() {
        return 'w-full h-full';
    }
    getValueTextClasses() {
        return 'glass-cp-value absolute text-xs font-medium pointer-events-none';
    }
    getSizeClasses() {
        const size = this.getResolvedSize();
        const map = {
            xs: 'w-4 h-4',
            sm: 'w-6 h-6',
            md: 'w-10 h-10',
            lg: 'w-16 h-16',
        };
        return map[size] || map.md;
    }
    getResolvedSize() {
        const sizes = ['xs', 'sm', 'md', 'lg'];
        return sizes.includes(this.size) ? this.size : 'md';
    }
};
__decorate([
    propertyDataSource({ type: Number })
], CircularProgressMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], CircularProgressMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], CircularProgressMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], CircularProgressMolecule.prototype, "showValue", void 0);
CircularProgressMolecule = __decorate([
    customElement('groupshowprogress--ml-circular-progress')
], CircularProgressMolecule);
export { CircularProgressMolecule };
