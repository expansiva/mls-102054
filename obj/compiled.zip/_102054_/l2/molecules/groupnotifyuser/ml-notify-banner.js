/// <mls fileReference="_102054_/l2/molecules/groupnotifyuser/ml-notify-banner.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// NOTIFY BANNER MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNotifyUser (notify + user)
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    dismissLabel: 'Dismiss notification',
    missingMessage: 'Notification message is required.',
};
const messages = {
    en: message_en,
    pt: {
        dismissLabel: 'Dispensar notificação',
        missingMessage: 'Mensagem da notificação é obrigatória.',
    },
};
/// **collab_i18n_end**
let NotifyBannerMolecule = class NotifyBannerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-notify-banner {
  display: contents;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnotifyuser--ml-notify-banner .glass-banner {
  position: relative;
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: rgba(56, 60, 120, 0.55);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  box-shadow: 0 12px 36px rgba(0, 0, 0, 0.32), inset 0 1px 0 rgba(255, 255, 255, 0.3);
  color: rgba(255, 255, 255, 0.92);
}
groupnotifyuser--ml-notify-banner .glass-banner.is-info {
  background: rgba(56, 70, 140, 0.55);
}
groupnotifyuser--ml-notify-banner .glass-banner.is-success {
  background: rgba(16, 100, 70, 0.5);
}
groupnotifyuser--ml-notify-banner .glass-banner.is-warning {
  background: rgba(120, 90, 20, 0.5);
}
groupnotifyuser--ml-notify-banner .glass-banner.is-error {
  background: rgba(130, 40, 50, 0.55);
}
groupnotifyuser--ml-notify-banner .glass-banner-icon {
  color: #fff;
}
groupnotifyuser--ml-notify-banner .is-success .glass-banner-icon {
  color: #6ee7b7;
}
groupnotifyuser--ml-notify-banner .is-warning .glass-banner-icon {
  color: #fcd34d;
}
groupnotifyuser--ml-notify-banner .is-error .glass-banner-icon {
  color: #fca5a5;
}
groupnotifyuser--ml-notify-banner .is-info .glass-banner-icon {
  color: #c7d2fe;
}
groupnotifyuser--ml-notify-banner .glass-banner-title {
  color: #fff;
}
groupnotifyuser--ml-notify-banner .glass-banner-message {
  color: rgba(255, 255, 255, 0.82);
}
groupnotifyuser--ml-notify-banner .glass-banner-action {
  color: #c7d2fe;
}
groupnotifyuser--ml-notify-banner .glass-banner-action:hover {
  text-decoration: underline;
}
groupnotifyuser--ml-notify-banner .glass-banner-dismiss {
  border: none;
  border-radius: 8px;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease;
}
groupnotifyuser--ml-notify-banner .glass-banner-dismiss:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
groupnotifyuser--ml-notify-banner .glass-banner-dismiss:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.7);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Title', 'Message', 'Action', 'Icon'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.type = 'info';
        this.visible = false;
        this.dismissible = true;
        this.duration = 0;
        this.position = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.dismissTimer = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        this.clearAutoDismiss();
        super.disconnectedCallback();
    }
    updated(changedProps) {
        if (changedProps.has('visible') || changedProps.has('duration')) {
            if (this.visible && this.duration > 0) {
                this.startAutoDismiss();
            }
            else {
                this.clearAutoDismiss();
            }
        }
    }
    // ===========================================================================
    // AUTO-DISMISS
    // ===========================================================================
    startAutoDismiss() {
        this.clearAutoDismiss();
        this.dismissTimer = window.setTimeout(() => {
            if (!this.visible)
                return;
            this.handleDismiss();
        }, this.duration);
    }
    clearAutoDismiss() {
        if (this.dismissTimer) {
            window.clearTimeout(this.dismissTimer);
            this.dismissTimer = null;
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDismiss() {
        if (!this.visible)
            return;
        this.clearAutoDismiss();
        this.visible = false;
        this.dispatchEvent(new CustomEvent('dismiss', { bubbles: true, composed: true, detail: {} }));
    }
    handleActionClick() {
        this.dispatchEvent(new CustomEvent('action', { bubbles: true, composed: true, detail: {} }));
    }
    // ===========================================================================
    // RENDER HELPERS  (aparência = classes glass; layout/posição = Tailwind)
    // ===========================================================================
    getRole() {
        return this.type === 'error' || this.type === 'warning' ? 'alert' : 'status';
    }
    getAriaLive() {
        return this.type === 'error' ? 'assertive' : 'polite';
    }
    getPositionClasses() {
        if (!this.position)
            return '';
        const pos = this.position.toLowerCase();
        const base = ['fixed', 'z-50'].join(' ');
        if (pos.includes('top-right'))
            return `${base} top-4 right-4`;
        if (pos.includes('top-left'))
            return `${base} top-4 left-4`;
        if (pos.includes('bottom-right'))
            return `${base} bottom-4 right-4`;
        if (pos.includes('bottom-left'))
            return `${base} bottom-4 left-4`;
        if (pos.includes('top'))
            return `${base} top-4 left-1/2 -translate-x-1/2`;
        if (pos.includes('bottom'))
            return `${base} bottom-4 left-1/2 -translate-x-1/2`;
        return `${base} top-4 right-4`;
    }
    getContainerClasses() {
        return [
            'glass-banner',
            `is-${this.type}`,
            'w-full max-w-xl flex items-start gap-3 px-4 py-3 text-sm',
            this.position ? '' : 'relative',
            this.getPositionClasses(),
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderDefaultIcon() {
        const iconClasses = 'glass-banner-icon h-5 w-5';
        switch (this.type) {
            case 'success':
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M16.704 5.29a1 1 0 010 1.415l-7.2 7.2a1 1 0 01-1.415 0l-3.6-3.6a1 1 0 011.415-1.415l2.893 2.893 6.493-6.493a1 1 0 011.415 0z" clip-rule="evenodd" /></svg>`;
            case 'warning':
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.721-1.36 3.486 0l6.518 11.594C18.994 16.025 18.049 18 16.517 18H3.483c-1.532 0-2.477-1.975-1.744-3.307L8.257 3.1zM9 7a1 1 0 012 0v4a1 1 0 01-2 0V7zm1 8a1.25 1.25 0 100-2.5A1.25 1.25 0 0010 15z" clip-rule="evenodd" /></svg>`;
            case 'error':
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-10a1 1 0 112 0v4a1 1 0 01-2 0V8zm1 8a1.25 1.25 0 100-2.5A1.25 1.25 0 0010 16z" clip-rule="evenodd" /></svg>`;
            case 'info':
            default:
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M18 10A8 8 0 112 10a8 8 0 0116 0zM9 8a1 1 0 112 0v6a1 1 0 11-2 0V8zm1-3a1.25 1.25 0 100 2.5A1.25 1.25 0 0010 5z" clip-rule="evenodd" /></svg>`;
        }
    }
    renderIcon() {
        if (this.hasSlot('Icon')) {
            return html `<div class="mt-0.5">${unsafeHTML(this.getSlotContent('Icon'))}</div>`;
        }
        return html `<div class="mt-0.5">${this.renderDefaultIcon()}</div>`;
    }
    renderTitle() {
        if (!this.hasSlot('Title'))
            return html ``;
        return html `<div class="glass-banner-title text-sm font-semibold">${unsafeHTML(this.getSlotContent('Title'))}</div>`;
    }
    renderMessage() {
        const content = this.hasSlot('Message') ? this.getSlotContent('Message') : this.msg.missingMessage;
        return html `<div class="glass-banner-message text-sm">${unsafeHTML(content)}</div>`;
    }
    renderAction() {
        if (!this.hasSlot('Action'))
            return html ``;
        return html `
      <div class="glass-banner-action mt-3 inline-flex items-center text-sm font-medium cursor-pointer" @click=${this.handleActionClick}>
        ${unsafeHTML(this.getSlotContent('Action'))}
      </div>
    `;
    }
    renderDismissButton() {
        if (!this.dismissible)
            return html ``;
        return html `
      <button
        class="glass-banner-dismiss ml-2 inline-flex h-7 w-7 items-center justify-center"
        aria-label="${this.msg.dismissLabel}"
        @click=${this.handleDismiss}
      >
        <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path
            fill-rule="evenodd"
            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
            clip-rule="evenodd"
          />
        </svg>
      </button>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.visible) {
            return html ``;
        }
        return html `
      <div class="${this.getContainerClasses()}" role="${this.getRole()}" aria-live="${this.getAriaLive()}">
        ${this.renderIcon()}
        <div class="flex-1">${this.renderTitle()} ${this.renderMessage()} ${this.renderAction()}</div>
        ${this.renderDismissButton()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], NotifyBannerMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NotifyBannerMolecule.prototype, "visible", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NotifyBannerMolecule.prototype, "dismissible", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NotifyBannerMolecule.prototype, "duration", void 0);
__decorate([
    propertyDataSource({ type: String })
], NotifyBannerMolecule.prototype, "position", void 0);
__decorate([
    state()
], NotifyBannerMolecule.prototype, "dismissTimer", void 0);
NotifyBannerMolecule = __decorate([
    customElement('groupnotifyuser--ml-notify-banner')
], NotifyBannerMolecule);
export { NotifyBannerMolecule };
