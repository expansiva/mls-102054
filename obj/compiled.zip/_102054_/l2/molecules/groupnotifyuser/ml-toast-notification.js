/// <mls fileReference="_102054_/l2/molecules/groupnotifyuser/ml-toast-notification.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TOAST NOTIFICATION MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNotifyUser
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    dismissLabel: 'Dismiss notification',
};
const messages = {
    en: message_en,
    pt: {
        dismissLabel: 'Dispensar notificação',
    },
};
let ToastNotificationMolecule = class ToastNotificationMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-toast-notification {
  display: contents;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnotifyuser--ml-toast-notification .glass-toast {
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: rgba(30, 27, 75, 0.78);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  box-shadow: 0 14px 40px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3);
  color: rgba(255, 255, 255, 0.92);
}
groupnotifyuser--ml-toast-notification .glass-toast.is-success {
  background: rgba(16, 80, 60, 0.8);
}
groupnotifyuser--ml-toast-notification .glass-toast.is-warning {
  background: rgba(100, 75, 18, 0.8);
}
groupnotifyuser--ml-toast-notification .glass-toast.is-error {
  background: rgba(110, 35, 45, 0.82);
}
groupnotifyuser--ml-toast-notification .glass-toast.is-info {
  background: rgba(40, 50, 110, 0.8);
}
groupnotifyuser--ml-toast-notification .glass-toast-icon {
  color: #fff;
}
groupnotifyuser--ml-toast-notification .is-success .glass-toast-icon {
  color: #6ee7b7;
}
groupnotifyuser--ml-toast-notification .is-warning .glass-toast-icon {
  color: #fcd34d;
}
groupnotifyuser--ml-toast-notification .is-error .glass-toast-icon {
  color: #fca5a5;
}
groupnotifyuser--ml-toast-notification .is-info .glass-toast-icon {
  color: #c7d2fe;
}
groupnotifyuser--ml-toast-notification .glass-toast-title {
  color: #fff;
}
groupnotifyuser--ml-toast-notification .glass-toast-message {
  color: rgba(255, 255, 255, 0.82);
}
groupnotifyuser--ml-toast-notification .glass-toast-action {
  color: #c7d2fe;
}
groupnotifyuser--ml-toast-notification .glass-toast-action:hover {
  text-decoration: underline;
}
groupnotifyuser--ml-toast-notification .glass-toast-close {
  border: none;
  border-radius: 8px;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease;
}
groupnotifyuser--ml-toast-notification .glass-toast-close:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
groupnotifyuser--ml-toast-notification .glass-toast-close:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.7);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Title', 'Message', 'Action', 'Icon'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.type = 'info';
        this.visible = false;
        this.dismissible = true;
        this.duration = 0;
        this.position = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isAnimatingOut = false;
        this.autoCloseTimer = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.clearAutoCloseTimer();
    }
    updated(changedProperties) {
        if (changedProperties.has('visible')) {
            if (this.visible) {
                this.isAnimatingOut = false;
                this.startAutoCloseTimer();
            }
            else {
                this.clearAutoCloseTimer();
            }
        }
        if (changedProperties.has('duration') && this.visible) {
            this.clearAutoCloseTimer();
            this.startAutoCloseTimer();
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const visibleAttr = this.getAttribute('visible');
        if (visibleAttr === `{{${key}}}`) {
            if (value === true) {
                this.isAnimatingOut = false;
                this.startAutoCloseTimer();
            }
            else {
                this.clearAutoCloseTimer();
            }
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // TIMER MANAGEMENT
    // ===========================================================================
    startAutoCloseTimer() {
        this.clearAutoCloseTimer();
        if (this.duration > 0) {
            this.autoCloseTimer = window.setTimeout(() => {
                this.handleDismiss();
            }, this.duration);
        }
    }
    clearAutoCloseTimer() {
        if (this.autoCloseTimer !== null) {
            window.clearTimeout(this.autoCloseTimer);
            this.autoCloseTimer = null;
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDismiss() {
        this.clearAutoCloseTimer();
        this.isAnimatingOut = true;
        setTimeout(() => {
            this.visible = false;
            this.isAnimatingOut = false;
            this.dispatchEvent(new CustomEvent('dismiss', { bubbles: true, composed: true, detail: {} }));
        }, 300);
    }
    handleActionClick(e) {
        e.stopPropagation();
        this.dispatchEvent(new CustomEvent('action', { bubbles: true, composed: true, detail: {} }));
    }
    // ===========================================================================
    // STYLING HELPERS  (aparência = classes glass; layout/posição/animação = Tailwind)
    // ===========================================================================
    getContainerClasses() {
        return [
            'glass-toast',
            `is-${this.type}`,
            'flex items-start gap-3 p-4 max-w-sm w-full transition-all duration-300 ease-in-out',
            this.getPositionClasses(),
            this.getAnimationClasses(),
        ]
            .filter(Boolean)
            .join(' ');
    }
    getPositionClasses() {
        if (!this.position)
            return '';
        const positionMap = {
            top: 'fixed top-4 left-1/2 -translate-x-1/2 z-50',
            bottom: 'fixed bottom-4 left-1/2 -translate-x-1/2 z-50',
            'top-right': 'fixed top-4 right-4 z-50',
            'bottom-right': 'fixed bottom-4 right-4 z-50',
            'top-left': 'fixed top-4 left-4 z-50',
            'bottom-left': 'fixed bottom-4 left-4 z-50',
        };
        return positionMap[this.position] || '';
    }
    getAnimationClasses() {
        if (this.isAnimatingOut) {
            return this.getExitAnimationClass();
        }
        return this.getEntryAnimationClass();
    }
    getEntryAnimationClass() {
        if (!this.position)
            return 'opacity-100 translate-y-0';
        switch (this.position) {
            case 'top':
            case 'top-left':
            case 'top-right':
                return 'animate-slide-in-top';
            case 'bottom':
            case 'bottom-left':
            case 'bottom-right':
                return 'animate-slide-in-bottom';
            default:
                return 'opacity-100';
        }
    }
    getExitAnimationClass() {
        if (!this.position)
            return 'opacity-0 translate-y-2';
        switch (this.position) {
            case 'top':
            case 'top-left':
            case 'top-right':
                return 'opacity-0 -translate-y-4';
            case 'bottom':
            case 'bottom-left':
            case 'bottom-right':
                return 'opacity-0 translate-y-4';
            default:
                return 'opacity-0';
        }
    }
    // ===========================================================================
    // ACCESSIBILITY HELPERS
    // ===========================================================================
    getAriaRole() {
        return this.type === 'error' || this.type === 'warning' ? 'alert' : 'status';
    }
    getAriaLive() {
        return this.type === 'error' ? 'assertive' : 'polite';
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderIcon() {
        if (this.hasSlot('Icon')) {
            return html `<div class="glass-toast-icon flex-shrink-0">${unsafeHTML(this.getSlotContent('Icon'))}</div>`;
        }
        return html `<div class="glass-toast-icon flex-shrink-0">${this.renderDefaultIcon()}</div>`;
    }
    renderDefaultIcon() {
        const iconClasses = 'w-5 h-5';
        switch (this.type) {
            case 'success':
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">${svg `<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clip-rule="evenodd" />`}</svg>`;
            case 'warning':
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">${svg `<path fill-rule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd" />`}</svg>`;
            case 'error':
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">${svg `<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.28 7.22a.75.75 0 00-1.06 1.06L8.94 10l-1.72 1.72a.75.75 0 101.06 1.06L10 11.06l1.72 1.72a.75.75 0 101.06-1.06L11.06 10l1.72-1.72a.75.75 0 00-1.06-1.06L10 8.94 8.28 7.22z" clip-rule="evenodd" />`}</svg>`;
            case 'info':
            default:
                return html `<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">${svg `<path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z" clip-rule="evenodd" />`}</svg>`;
        }
    }
    renderTitle() {
        if (!this.hasSlot('Title')) {
            return html ``;
        }
        return html `<div class="glass-toast-title text-sm font-semibold">${unsafeHTML(this.getSlotContent('Title'))}</div>`;
    }
    renderMessage() {
        return html `<div class="glass-toast-message text-sm">${unsafeHTML(this.getSlotContent('Message'))}</div>`;
    }
    renderAction() {
        if (!this.hasSlot('Action')) {
            return html ``;
        }
        return html `<div class="glass-toast-action mt-2 text-sm font-medium cursor-pointer" @click=${this.handleActionClick}>${unsafeHTML(this.getSlotContent('Action'))}</div>`;
    }
    renderCloseButton() {
        if (!this.dismissible) {
            return html ``;
        }
        return html `
      <button type="button" class="glass-toast-close flex-shrink-0 p-1" aria-label="${this.msg.dismissLabel}" @click=${this.handleDismiss}>
        <svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">${svg `<path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />`}</svg>
      </button>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.visible && !this.isAnimatingOut) {
            return html ``;
        }
        return html `
      <div class="${this.getContainerClasses()}" role="${this.getAriaRole()}" aria-live="${this.getAriaLive()}">
        ${this.renderIcon()}
        <div class="flex-1 min-w-0">${this.renderTitle()} ${this.renderMessage()} ${this.renderAction()}</div>
        ${this.renderCloseButton()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], ToastNotificationMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ToastNotificationMolecule.prototype, "visible", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ToastNotificationMolecule.prototype, "dismissible", void 0);
__decorate([
    propertyDataSource({ type: Number })
], ToastNotificationMolecule.prototype, "duration", void 0);
__decorate([
    propertyDataSource({ type: String })
], ToastNotificationMolecule.prototype, "position", void 0);
__decorate([
    state()
], ToastNotificationMolecule.prototype, "isAnimatingOut", void 0);
ToastNotificationMolecule = __decorate([
    customElement('groupnotifyuser--ml-toast-notification')
], ToastNotificationMolecule);
export { ToastNotificationMolecule };
