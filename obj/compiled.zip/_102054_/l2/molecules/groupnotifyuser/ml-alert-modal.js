var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnotifyuser/ml-alert-modal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML-ALERT-MODAL MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: groupNotifyUser
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// O scrim usa backdrop-filter (desfoca a página atrás); o painel é vidro.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    dismiss: 'Dismiss notification',
    defaultMessage: 'Notification',
};
const messages = {
    en: message_en,
    pt: {
        dismiss: 'Dispensar notificação',
        defaultMessage: 'Notificação',
    },
};
/// **collab_i18n_end**
let MlAlertModalMolecule = class MlAlertModalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal {
  display: contents;
  font-family: 'Inter', system-ui, sans-serif;
}
groupnotifyuser--ml-alert-modal .glass-modal-scrim {
  background: rgba(8, 10, 25, 0.45);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
groupnotifyuser--ml-alert-modal .glass-modal {
  position: relative;
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: rgba(30, 27, 75, 0.8);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.3);
  color: rgba(255, 255, 255, 0.92);
}
groupnotifyuser--ml-alert-modal .glass-modal.is-success {
  border-top: 3px solid rgba(110, 231, 183, 0.8);
}
groupnotifyuser--ml-alert-modal .glass-modal.is-warning {
  border-top: 3px solid rgba(252, 211, 77, 0.8);
}
groupnotifyuser--ml-alert-modal .glass-modal.is-error {
  border-top: 3px solid rgba(252, 165, 165, 0.85);
}
groupnotifyuser--ml-alert-modal .glass-modal.is-info {
  border-top: 3px solid rgba(199, 210, 254, 0.8);
}
groupnotifyuser--ml-alert-modal .glass-modal-icon-wrap {
  color: #fff;
  background: rgba(255, 255, 255, 0.12);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupnotifyuser--ml-alert-modal .is-success .glass-modal-icon-wrap {
  color: #6ee7b7;
  background: rgba(16, 100, 70, 0.45);
}
groupnotifyuser--ml-alert-modal .is-warning .glass-modal-icon-wrap {
  color: #fcd34d;
  background: rgba(120, 90, 20, 0.45);
}
groupnotifyuser--ml-alert-modal .is-error .glass-modal-icon-wrap {
  color: #fca5a5;
  background: rgba(130, 40, 50, 0.5);
}
groupnotifyuser--ml-alert-modal .is-info .glass-modal-icon-wrap {
  color: #c7d2fe;
  background: rgba(56, 70, 140, 0.5);
}
groupnotifyuser--ml-alert-modal .glass-modal-title {
  color: #fff;
}
groupnotifyuser--ml-alert-modal .glass-modal-message {
  color: rgba(255, 255, 255, 0.82);
}
groupnotifyuser--ml-alert-modal .glass-modal-dismiss {
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  border-radius: 8px;
  padding: 0.25rem;
  transition: background 150ms ease, color 150ms ease;
}
groupnotifyuser--ml-alert-modal .glass-modal-dismiss:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Title', 'Message', 'Action', 'Icon'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.type = 'info';
        this.visible = false;
        this.dismissible = true;
        this.duration = 0;
        this.position = '';
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.autoDismissId = null;
    }
    // =========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key) {
        const visibleAttr = this.getAttribute('visible');
        const durationAttr = this.getAttribute('duration');
        if (visibleAttr === `{{${key}}}` || durationAttr === `{{${key}}}`) {
            this.manageAutoDismiss();
        }
        this.requestUpdate();
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    updated(changedProps) {
        if (changedProps.has('visible') || changedProps.has('duration')) {
            this.manageAutoDismiss();
        }
    }
    // =========================================================================
    // AUTO DISMISS
    // =========================================================================
    manageAutoDismiss() {
        this.clearAutoDismiss();
        if (!this.visible || this.duration <= 0)
            return;
        this.autoDismissId = window.setTimeout(() => {
            this.handleDismiss();
        }, this.duration);
    }
    clearAutoDismiss() {
        if (this.autoDismissId !== null) {
            window.clearTimeout(this.autoDismissId);
            this.autoDismissId = null;
        }
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleDismiss() {
        if (!this.visible)
            return;
        this.visible = false;
        this.clearAutoDismiss();
        this.dispatchEvent(new CustomEvent('dismiss', { bubbles: true, composed: true, detail: {} }));
    }
    handleActionClick() {
        if (!this.visible)
            return;
        this.dispatchEvent(new CustomEvent('action', { bubbles: true, composed: true, detail: {} }));
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    getNormalizedType() {
        const raw = (this.type || 'info').toLowerCase();
        if (raw === 'danger')
            return 'error';
        if (raw === 'success' || raw === 'warning' || raw === 'error')
            return raw;
        return 'info';
    }
    getRole() {
        const t = this.getNormalizedType();
        return t === 'error' || t === 'warning' ? 'alert' : 'status';
    }
    getAriaLive() {
        const t = this.getNormalizedType();
        return t === 'error' ? 'assertive' : 'polite';
    }
    getPositionClasses() {
        const pos = (this.position || '').toLowerCase();
        const base = 'items-center justify-center';
        if (!pos || pos === 'center')
            return base;
        if (pos === 'top')
            return 'items-start justify-center';
        if (pos === 'bottom')
            return 'items-end justify-center';
        if (pos === 'top-right')
            return 'items-start justify-end';
        if (pos === 'bottom-right')
            return 'items-end justify-end';
        if (pos === 'top-left')
            return 'items-start justify-start';
        if (pos === 'bottom-left')
            return 'items-end justify-start';
        return base;
    }
    getContainerClasses() {
        return ['glass-modal', `is-${this.getNormalizedType()}`, 'w-full max-w-xl p-6'].join(' ');
    }
    getIconWrapperClasses() {
        return 'glass-modal-icon-wrap h-12 w-12 rounded-full flex items-center justify-center';
    }
    renderDefaultIcon() {
        const type = this.getNormalizedType();
        if (type === 'success') {
            return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>`}</svg>`;
        }
        if (type === 'warning') {
            return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01"></path>`}${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path>`}</svg>`;
        }
        if (type === 'error') {
            return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01"></path>`}${svg `<circle cx="12" cy="12" r="9"></circle>`}</svg>`;
        }
        return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<circle cx="12" cy="12" r="9"></circle>`}${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 8h.01M11 12h2v4h-2z"></path>`}</svg>`;
    }
    renderIcon() {
        if (this.hasSlot('Icon')) {
            return html `<div class="${this.getIconWrapperClasses()}">${unsafeHTML(this.getSlotContent('Icon'))}</div>`;
        }
        return html `<div class="${this.getIconWrapperClasses()}">${this.renderDefaultIcon()}</div>`;
    }
    renderTitle() {
        if (!this.hasSlot('Title'))
            return html ``;
        return html `<h3 class="glass-modal-title text-lg font-semibold">${unsafeHTML(this.getSlotContent('Title'))}</h3>`;
    }
    renderMessage() {
        const message = this.getSlotContent('Message') || this.msg.defaultMessage;
        return html `<div class="glass-modal-message text-sm">${unsafeHTML(message)}</div>`;
    }
    renderActions() {
        if (!this.hasSlot('Action'))
            return html ``;
        return html `<div class="mt-6 flex items-center justify-end gap-3" @click=${this.handleActionClick}>${unsafeHTML(this.getSlotContent('Action'))}</div>`;
    }
    renderDismiss() {
        if (!this.dismissible)
            return html ``;
        return html `
      <button type="button" class="glass-modal-dismiss" aria-label="${this.msg.dismiss}" @click=${this.handleDismiss}>
        <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>`}</svg>
      </button>
    `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.visible)
            return html ``;
        return html `
      <div class="fixed inset-0 z-50 flex ${this.getPositionClasses()} p-6">
        <div class="glass-modal-scrim absolute inset-0" aria-hidden="true" @click=${this.dismissible ? this.handleDismiss : null}></div>
        <div
          class="relative z-10 w-full ${this.getContainerClasses()}"
          role="${this.getRole()}"
          aria-live="${this.getAriaLive()}"
          aria-modal="true"
        >
          <div class="flex items-start justify-between gap-4">
            <div class="flex items-start gap-4">
              ${this.renderIcon()}
              <div class="space-y-2">${this.renderTitle()} ${this.renderMessage()}</div>
            </div>
            ${this.renderDismiss()}
          </div>
          ${this.renderActions()}
        </div>
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlAlertModalMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAlertModalMolecule.prototype, "visible", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAlertModalMolecule.prototype, "dismissible", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlAlertModalMolecule.prototype, "duration", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAlertModalMolecule.prototype, "position", void 0);
__decorate([
    state()
], MlAlertModalMolecule.prototype, "autoDismissId", void 0);
MlAlertModalMolecule = __decorate([
    customElement('groupnotifyuser--ml-alert-modal')
], MlAlertModalMolecule);
export { MlAlertModalMolecule };
