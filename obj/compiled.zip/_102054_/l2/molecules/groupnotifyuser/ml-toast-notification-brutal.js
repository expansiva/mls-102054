var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnotifyuser/ml-toast-notification-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TOAST NOTIFICATION — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de ToastNotificationMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ToastNotificationMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.js';
let ToastNotificationBrutal = class ToastNotificationBrutal extends ToastNotificationMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-toast-notification-brutal {
  display: contents;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-primary: #3b82f6;
  --ml-success: #16a34a;
  --ml-warning: #ca8a04;
  --ml-error: #ef4444;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  font-family: var(--ml-font-family);
}
groupnotifyuser--ml-toast-notification-brutal .ml-primary-dim-bg,
groupnotifyuser--ml-toast-notification-brutal .ml-success-dim-bg,
groupnotifyuser--ml-toast-notification-brutal .ml-warning-dim-bg,
groupnotifyuser--ml-toast-notification-brutal .ml-error-dim-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  box-shadow: 3px 3px 0 #000000;
  color: var(--ml-on-surface, #000000);
}
groupnotifyuser--ml-toast-notification-brutal .ml-border-info {
  border-left: 6px solid var(--ml-primary, #3b82f6);
}
groupnotifyuser--ml-toast-notification-brutal .ml-border-success {
  border-left: 6px solid var(--ml-success, #16a34a);
}
groupnotifyuser--ml-toast-notification-brutal .ml-border-warning {
  border-left: 6px solid var(--ml-warning, #ca8a04);
}
groupnotifyuser--ml-toast-notification-brutal .ml-border-error {
  border-left: 6px solid var(--ml-error, #ef4444);
}
groupnotifyuser--ml-toast-notification-brutal .ml-text {
  color: #333333;
}
groupnotifyuser--ml-toast-notification-brutal .font-semibold.ml-text {
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnotifyuser--ml-toast-notification-brutal .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
}
groupnotifyuser--ml-toast-notification-brutal .ml-success-text {
  color: var(--ml-success, #16a34a);
}
groupnotifyuser--ml-toast-notification-brutal .ml-warning-text {
  color: var(--ml-warning, #ca8a04);
}
groupnotifyuser--ml-toast-notification-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupnotifyuser--ml-toast-notification-brutal .ml-primary-text.cursor-pointer,
groupnotifyuser--ml-toast-notification-brutal .ml-success-text.cursor-pointer,
groupnotifyuser--ml-toast-notification-brutal .ml-warning-text.cursor-pointer,
groupnotifyuser--ml-toast-notification-brutal .ml-error-text.cursor-pointer {
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  transition: none;
}
groupnotifyuser--ml-toast-notification-brutal .ml-primary-text.cursor-pointer:hover,
groupnotifyuser--ml-toast-notification-brutal .ml-success-text.cursor-pointer:hover,
groupnotifyuser--ml-toast-notification-brutal .ml-warning-text.cursor-pointer:hover,
groupnotifyuser--ml-toast-notification-brutal .ml-error-text.cursor-pointer:hover {
  text-decoration: underline;
}
groupnotifyuser--ml-toast-notification-brutal button.ml-text-faint {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid #000000;
  background: var(--ml-surface, #ffffff);
  color: #000000;
  cursor: pointer;
  transition: none;
}
groupnotifyuser--ml-toast-notification-brutal button.ml-text-faint:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupnotifyuser--ml-toast-notification-brutal .hover\:ml-text-muted:hover {
  color: #ffffff;
}
groupnotifyuser--ml-toast-notification-brutal .hover\:ml-surface-dim-bg:hover {
  background: #000000;
}
`);
    }
};
ToastNotificationBrutal = __decorate([
    customElement('groupnotifyuser--ml-toast-notification-brutal')
], ToastNotificationBrutal);
export { ToastNotificationBrutal };
