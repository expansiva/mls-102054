var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML-ALERT-MODAL — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: groupNotifyUser
// Herda toda a lógica de MlAlertModalMolecule (mls-102040): visibilidade,
// auto-dismiss timer, eventos (dismiss/action) e estado reativo. Sobrescreve
// apenas render() e helpers brutal-prefixados.
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { MlAlertModalMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.js';
/// **collab_i18n_start**
const message_en = {
    dismiss: 'Dismiss notification',
    defaultMessage: 'Notification',
};
const messages = {
    en: message_en,
    pt: {
        dismiss: 'Dispensar notificação',
        defaultMessage: 'Notificação',
    },
};
let MlAlertModalBrutal = class MlAlertModalBrutal extends MlAlertModalMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal-brutal {
  display: contents;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-scrim {
  background: rgba(0, 0, 0, 0.7);
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal {
  position: relative;
  border-radius: 0;
  border: 3px solid #000;
  background: #fff;
  box-shadow: 6px 6px 0 #000;
  color: #000;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal.is-success {
  border-top: 6px solid #16a34a;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal.is-warning {
  border-top: 6px solid #ca8a04;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal.is-error {
  border-top: 6px solid #ef4444;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal.is-info {
  border-top: 6px solid #3b82f6;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-icon-wrap {
  color: #000;
  background: #eee;
  border: 3px solid #000;
}
groupnotifyuser--ml-alert-modal-brutal .is-success .brutal-modal-icon-wrap {
  color: #16a34a;
  background: #f0fdf4;
  border-color: #16a34a;
}
groupnotifyuser--ml-alert-modal-brutal .is-warning .brutal-modal-icon-wrap {
  color: #ca8a04;
  background: #fefce8;
  border-color: #ca8a04;
}
groupnotifyuser--ml-alert-modal-brutal .is-error .brutal-modal-icon-wrap {
  color: #ef4444;
  background: #fef2f2;
  border-color: #ef4444;
}
groupnotifyuser--ml-alert-modal-brutal .is-info .brutal-modal-icon-wrap {
  color: #3b82f6;
  background: #eff6ff;
  border-color: #3b82f6;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-title {
  color: #000;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-message {
  color: #333;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-dismiss {
  border: 3px solid #000;
  background: #fff;
  color: #000;
  cursor: pointer;
  border-radius: 0;
  padding: 0.25rem;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-dismiss:hover {
  background: #000;
  color: #fff;
}
groupnotifyuser--ml-alert-modal-brutal .brutal-modal-dismiss:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
}
`);
        this.gMsg = messages.en;
        this.brutalHandleDismiss = () => this.x.handleDismiss();
        this.brutalHandleActionClick = () => this.x.handleActionClick();
    }
    get x() {
        return this;
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalContainerClasses() {
        return ['brutal-modal', `is-${this.x.getNormalizedType()}`, 'w-full max-w-xl p-6'].join(' ');
    }
    brutalIconWrapperClasses() {
        return 'brutal-modal-icon-wrap h-12 w-12 flex items-center justify-center';
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalDefaultIcon() {
        const type = this.x.getNormalizedType();
        if (type === 'success') {
            return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>`}</svg>`;
        }
        if (type === 'warning') {
            return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01"></path>`}${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path>`}</svg>`;
        }
        if (type === 'error') {
            return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01"></path>`}${svg `<circle cx="12" cy="12" r="9"></circle>`}</svg>`;
        }
        return html `<svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">${svg `<circle cx="12" cy="12" r="9"></circle>`}${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 8h.01M11 12h2v4h-2z"></path>`}</svg>`;
    }
    brutalIcon() {
        if (this.hasSlot('Icon')) {
            return html `<div class="${this.brutalIconWrapperClasses()}">${unsafeHTML(this.getSlotContent('Icon'))}</div>`;
        }
        return html `<div class="${this.brutalIconWrapperClasses()}">${this.brutalDefaultIcon()}</div>`;
    }
    brutalTitle() {
        if (!this.hasSlot('Title'))
            return html ``;
        return html `<h3 class="brutal-modal-title text-lg font-bold">${unsafeHTML(this.getSlotContent('Title'))}</h3>`;
    }
    brutalMessage() {
        const message = this.getSlotContent('Message') || this.gMsg.defaultMessage;
        return html `<div class="brutal-modal-message text-sm">${unsafeHTML(message)}</div>`;
    }
    brutalActions() {
        if (!this.hasSlot('Action'))
            return html ``;
        return html `<div class="mt-6 flex items-center justify-end gap-3" @click=${this.brutalHandleActionClick}>${unsafeHTML(this.getSlotContent('Action'))}</div>`;
    }
    brutalDismiss() {
        if (!this.dismissible)
            return html ``;
        return html `
      <button type="button" class="brutal-modal-dismiss" aria-label="${this.gMsg.dismiss}" @click=${this.brutalHandleDismiss}>
        <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2">${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>`}</svg>
      </button>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        const x = this.x;
        if (!this.visible)
            return html ``;
        return html `
      <div class="fixed inset-0 z-50 flex ${x.getPositionClasses()} p-6">
        <div class="brutal-modal-scrim absolute inset-0" aria-hidden="true" @click=${this.dismissible ? this.brutalHandleDismiss : null}></div>
        <div
          class="relative z-10 w-full ${this.brutalContainerClasses()}"
          role="${x.getRole()}"
          aria-live="${x.getAriaLive()}"
          aria-modal="true"
        >
          <div class="flex items-start justify-between gap-4">
            <div class="flex items-start gap-4">
              ${this.brutalIcon()}
              <div class="space-y-2">${this.brutalTitle()} ${this.brutalMessage()}</div>
            </div>
            ${this.brutalDismiss()}
          </div>
          ${this.brutalActions()}
        </div>
      </div>
    `;
    }
};
MlAlertModalBrutal = __decorate([
    customElement('groupnotifyuser--ml-alert-modal-brutal')
], MlAlertModalBrutal);
export { MlAlertModalBrutal };
