var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ALERT MODAL — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlAlertModalMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlAlertModalMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.js';
let MlAlertModalBrutal = class MlAlertModalBrutal extends MlAlertModalMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal-brutal {
  display: contents;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-primary: #3b82f6;
  --ml-success: #16a34a;
  --ml-warning: #ca8a04;
  --ml-error: #ef4444;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  font-family: var(--ml-font-family);
}
groupnotifyuser--ml-alert-modal-brutal div[aria-hidden='true'] {
  background: rgba(0, 0, 0, 0.7);
}
groupnotifyuser--ml-alert-modal-brutal .ml-surface-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  box-shadow: 6px 6px 0 #000000;
  color: var(--ml-on-surface, #000000);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-info {
  border-top: 6px solid var(--ml-primary, #3b82f6);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-success {
  border-top: 6px solid var(--ml-success, #16a34a);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-warning {
  border-top: 6px solid var(--ml-warning, #ca8a04);
}
groupnotifyuser--ml-alert-modal-brutal .ml-border-error {
  border-top: 6px solid var(--ml-error, #ef4444);
}
groupnotifyuser--ml-alert-modal-brutal .ml-primary-text.ml-primary-dim-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-primary, #3b82f6);
  background: #eff6ff;
}
groupnotifyuser--ml-alert-modal-brutal .ml-success-text.ml-success-dim-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-success, #16a34a);
  background: #f0fdf4;
}
groupnotifyuser--ml-alert-modal-brutal .ml-warning-text.ml-warning-dim-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-warning, #ca8a04);
  background: #fefce8;
}
groupnotifyuser--ml-alert-modal-brutal .ml-error-text.ml-error-dim-bg {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-error, #ef4444);
  background: #fef2f2;
}
groupnotifyuser--ml-alert-modal-brutal h3.ml-text {
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnotifyuser--ml-alert-modal-brutal div.ml-text {
  color: #333333;
}
groupnotifyuser--ml-alert-modal-brutal button.ml-text-muted {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid #000000;
  background: var(--ml-surface, #ffffff);
  color: #000000;
  padding: 0.25rem;
  cursor: pointer;
  transition: none;
}
groupnotifyuser--ml-alert-modal-brutal button.ml-text-muted:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupnotifyuser--ml-alert-modal-brutal .hover\:ml-text:hover {
  background: #000000;
  color: #ffffff;
}
`);
    }
};
MlAlertModalBrutal = __decorate([
    customElement('groupnotifyuser--ml-alert-modal-brutal')
], MlAlertModalBrutal);
export { MlAlertModalBrutal };
