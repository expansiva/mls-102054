var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATETIME PICKER MOLECULE — GLASSMORPHISM (mls-102054)
// =============================================================================
// Skill Group: enter + datetime
// Mesma molécula/contrato do mls-102040. Lógica intacta. Aparência (vidro) no .less.
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select date and time',
    loading: 'Loading...',
    confirm: 'Confirm',
    clear: 'Clear',
    empty: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione data e hora',
        loading: 'Carregando...',
        confirm: 'Confirmar',
        clear: 'Limpar',
        empty: '—',
    },
    de: {
        placeholder: 'Datum und Uhrzeit wählen',
        loading: 'Laden...',
        confirm: 'Bestätigen',
        clear: 'Löschen',
        empty: '—',
    },
};
/// **collab_i18n_end**
let MlDatetimePickerMolecule = class MlDatetimePickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdatetime--ml-datetime-picker {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-label {
  color: rgba(255, 255, 255, 0.7);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-label.is-disabled {
  opacity: 0.5;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-req {
  color: #ffb4ab;
}
groupenterdatetime--ml-datetime-picker .glass-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupenterdatetime--ml-datetime-picker .glass-error-text {
  color: #ffb4ab;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-view {
  color: #fff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-icon {
  color: rgba(255, 255, 255, 0.6);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-spinner {
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: rgba(255, 255, 255, 0.9);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-month {
  color: #fff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-weekday {
  color: rgba(255, 255, 255, 0.5);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-trigger {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  color: #fff;
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-trigger.is-focused {
  border-color: rgba(199, 210, 254, 0.9);
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.25);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-trigger.is-error {
  border-color: rgba(255, 120, 120, 0.7);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-trigger.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-value {
  color: rgba(255, 255, 255, 0.45);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-value.has-value {
  color: #fff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-panel {
  background: rgba(30, 27, 75, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 14px;
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-nav {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  border-radius: 6px;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-nav:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-day {
  border-radius: 8px;
  border: 1px solid transparent;
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-day:hover:not(.is-disabled):not(.is-selected) {
  background: rgba(255, 255, 255, 0.1);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-day.is-today {
  border-color: rgba(199, 210, 254, 0.6);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-day.is-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-day.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-time {
  border-radius: 8px;
  border: 1px solid transparent;
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-time:hover:not(.is-disabled):not(.is-selected) {
  background: rgba(255, 255, 255, 0.1);
}
groupenterdatetime--ml-datetime-picker .glass-dtp-time.is-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-time.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-clear {
  background: transparent;
  border: none;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-clear:hover {
  color: #fff;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-confirm {
  background: rgba(129, 140, 248, 0.85);
  border: 1px solid rgba(199, 210, 254, 0.6);
  border-radius: 8px;
  color: #fff;
  cursor: pointer;
  transition: background 0.12s ease;
}
groupenterdatetime--ml-datetime-picker .glass-dtp-confirm:hover {
  background: #818cf8;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.timezone = '';
        this.minDatetime = '';
        this.maxDatetime = '';
        this.minuteStep = 1;
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.isFocused = false;
        this.displayValue = '';
        this.selectedDate = null; // YYYY-MM-DD
        this.selectedHour = null;
        this.selectedMinute = null;
        this.currentMonth = new Date();
        this.labelId = `ml-dt-label-${Math.random().toString(36).slice(2)}`;
        this.helperId = `ml-dt-helper-${Math.random().toString(36).slice(2)}`;
        this.errorId = `ml-dt-error-${Math.random().toString(36).slice(2)}`;
        this.documentClickBound = false;
        this.handleDocumentClick = (event) => {
            const target = event.target;
            if (!this.contains(target)) {
                this.closePicker();
            }
        };
    }
    createRenderRoot() {
        return this;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const localeAttr = this.getAttribute('locale');
        const timezoneAttr = this.getAttribute('timezone');
        if (valueAttr === `{{${key}}}`) {
            this.updateFromValue(value);
            this.updateDisplay(value);
        }
        if (localeAttr === `{{${key}}}` || timezoneAttr === `{{${key}}}`) {
            this.updateDisplay(this.value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        this.removeDocumentListener();
        super.disconnectedCallback();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (this.isOpen) {
            this.closePicker();
        }
        else {
            this.openPicker();
        }
    }
    handleFocus() {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleDaySelect(dateStr, disabled) {
        if (disabled)
            return;
        this.selectedDate = dateStr;
        const validTime = this.getFirstValidTime();
        if (this.selectedHour === null || this.selectedMinute === null || this.isTimeDisabled(this.selectedHour, this.selectedMinute)) {
            this.selectedHour = validTime ? validTime.hour : null;
            this.selectedMinute = validTime ? validTime.minute : null;
        }
    }
    handleHourSelect(hour, disabled) {
        if (disabled)
            return;
        this.selectedHour = hour;
        if (this.selectedMinute === null || this.isTimeDisabled(hour, this.selectedMinute)) {
            const firstMinute = this.getFirstValidMinute(hour);
            this.selectedMinute = firstMinute;
        }
    }
    handleMinuteSelect(minute, disabled) {
        if (disabled)
            return;
        this.selectedMinute = minute;
    }
    handleConfirm() {
        if (!this.selectedDate)
            return;
        if (this.selectedHour === null || this.selectedMinute === null) {
            const valid = this.getFirstValidTime();
            if (!valid)
                return;
            this.selectedHour = valid.hour;
            this.selectedMinute = valid.minute;
        }
        if (this.isTimeDisabled(this.selectedHour, this.selectedMinute))
            return;
        const value = `${this.selectedDate}T${this.pad(this.selectedHour)}:${this.pad(this.selectedMinute)}:00`;
        this.value = value;
        this.updateDisplay(value);
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.closePicker();
    }
    handleClear() {
        this.value = null;
        this.selectedDate = null;
        this.selectedHour = null;
        this.selectedMinute = null;
        this.updateDisplay(null);
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.closePicker();
    }
    handlePrevMonth() {
        this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() - 1, 1);
    }
    handleNextMonth() {
        this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + 1, 1);
    }
    // ===========================================================================
    // PICKER OPEN/CLOSE
    // ===========================================================================
    openPicker() {
        this.isOpen = true;
        this.prepareOpenState();
        this.addDocumentListener();
    }
    closePicker() {
        this.isOpen = false;
        this.removeDocumentListener();
    }
    addDocumentListener() {
        if (this.documentClickBound)
            return;
        this.documentClickBound = true;
        document.addEventListener('click', this.handleDocumentClick);
    }
    removeDocumentListener() {
        if (!this.documentClickBound)
            return;
        this.documentClickBound = false;
        document.removeEventListener('click', this.handleDocumentClick);
    }
    prepareOpenState() {
        this.updateFromValue(this.value);
        if (this.selectedDate) {
            const parsed = this.parseIso(this.value || '');
            if (parsed) {
                this.currentMonth = new Date(parsed.year, parsed.month - 1, 1);
            }
        }
        else {
            const today = new Date();
            this.currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        }
    }
    // ===========================================================================
    // VALUE AND FORMAT HELPERS
    // ===========================================================================
    updateFromValue(value) {
        if (!value) {
            this.selectedDate = null;
            this.selectedHour = null;
            this.selectedMinute = null;
            return;
        }
        const parsed = this.parseIso(value);
        if (!parsed)
            return;
        this.selectedDate = `${parsed.year}-${this.pad(parsed.month)}-${this.pad(parsed.day)}`;
        this.selectedHour = parsed.hour;
        this.selectedMinute = parsed.minute;
    }
    updateDisplay(value) {
        this.displayValue = this.formatDisplay(value);
    }
    formatDisplay(value) {
        if (!value)
            return '';
        const parsed = this.parseIso(value);
        if (!parsed)
            return '';
        const date = this.timezone
            ? new Date(Date.UTC(parsed.year, parsed.month - 1, parsed.day, parsed.hour, parsed.minute, parsed.second))
            : new Date(parsed.year, parsed.month - 1, parsed.day, parsed.hour, parsed.minute, parsed.second);
        const formatter = new Intl.DateTimeFormat(this.locale || undefined, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            timeZone: this.timezone || undefined,
        });
        return formatter.format(date);
    }
    parseIso(value) {
        const match = value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?/);
        if (!match)
            return null;
        return {
            year: Number(match[1]),
            month: Number(match[2]),
            day: Number(match[3]),
            hour: Number(match[4]),
            minute: Number(match[5]),
            second: Number(match[6] || '0'),
        };
    }
    pad(value) {
        return String(value).padStart(2, '0');
    }
    getMinuteOptions() {
        const step = Math.max(1, Math.min(60, this.minuteStep || 1));
        const result = [];
        for (let m = 0; m < 60; m += step)
            result.push(m);
        return result;
    }
    parseMinMax(value) {
        const parsed = this.parseIso(value);
        if (!parsed)
            return null;
        return new Date(parsed.year, parsed.month - 1, parsed.day, parsed.hour, parsed.minute, parsed.second);
    }
    getMinDate() {
        return this.minDatetime ? this.parseMinMax(this.minDatetime) : null;
    }
    getMaxDate() {
        return this.maxDatetime ? this.parseMinMax(this.maxDatetime) : null;
    }
    isDateDisabled(year, month, day) {
        const min = this.getMinDate();
        const max = this.getMaxDate();
        const date = new Date(year, month, day, 0, 0, 0);
        if (min) {
            const minDate = new Date(min.getFullYear(), min.getMonth(), min.getDate(), 0, 0, 0);
            if (date < minDate)
                return true;
        }
        if (max) {
            const maxDate = new Date(max.getFullYear(), max.getMonth(), max.getDate(), 0, 0, 0);
            if (date > maxDate)
                return true;
        }
        return false;
    }
    isTimeDisabled(hour, minute) {
        if (!this.selectedDate)
            return true;
        const min = this.getMinDate();
        const max = this.getMaxDate();
        const [y, m, d] = this.selectedDate.split('-').map(Number);
        const date = new Date(y, m - 1, d, hour, minute, 0);
        if (min && date < min)
            return true;
        if (max && date > max)
            return true;
        return false;
    }
    getFirstValidTime() {
        if (!this.selectedDate)
            return null;
        const minutes = this.getMinuteOptions();
        for (let h = 0; h < 24; h += 1) {
            for (const m of minutes) {
                if (!this.isTimeDisabled(h, m))
                    return { hour: h, minute: m };
            }
        }
        return null;
    }
    getFirstValidMinute(hour) {
        const minutes = this.getMinuteOptions();
        for (const m of minutes) {
            if (!this.isTimeDisabled(hour, m))
                return m;
        }
        return null;
    }
    // ===========================================================================
    // RENDER HELPERS (glass)
    // ===========================================================================
    getTriggerClasses() {
        return [
            'glass-dtp-trigger w-full flex items-center justify-between gap-3 px-3 py-2 text-sm',
            this.isFocused ? 'is-focused' : '',
            this.error ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getLabelClasses() {
        return ['glass-dtp-label text-sm font-medium', this.disabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return 'glass-dtp-panel absolute z-20 mt-2 w-full p-4';
    }
    getDayButtonClasses(selected, disabled, today) {
        return [
            'glass-dtp-day h-8 w-8 text-xs',
            selected ? 'is-selected' : '',
            today && !selected ? 'is-today' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getTimeButtonClasses(selected, disabled) {
        return [
            'glass-dtp-time w-full px-2 py-1 text-xs text-left',
            selected ? 'is-selected' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getAriaDescribedBy() {
        if (this.error)
            return this.errorId;
        if (this.hasSlot('Helper'))
            return this.helperId;
        return undefined;
    }
    getWeekdays() {
        const formatter = new Intl.DateTimeFormat(this.locale || undefined, { weekday: 'short' });
        const base = new Date(2021, 7, 1); // Sunday
        return Array.from({ length: 7 }).map((_, i) => formatter.format(new Date(base.getTime() + i * 86400000)));
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${this.labelId} class=${this.getLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="glass-dtp-req ml-1">*</span>` : nothing}
      </label>
    `;
    }
    renderHiddenInput() {
        if (!this.name)
            return html ``;
        return html `<input type="hidden" name=${this.name} .value=${this.value || ''} />`;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id=${this.errorId} class="glass-error-text mt-1 text-xs">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${this.helperId} class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderTrigger() {
        const placeholder = this.placeholder || this.msg.placeholder;
        const display = this.displayValue || this.formatDisplay(this.value);
        const text = display || placeholder;
        return html `
      <button
        class=${this.getTriggerClasses()}
        type="button"
        aria-labelledby=${ifDefined(this.hasSlot('Label') ? this.labelId : undefined)}
        aria-describedby=${ifDefined(this.getAriaDescribedBy())}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        aria-label=${text}
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
        @click=${this.handleTriggerClick}
        ?disabled=${this.disabled || this.loading}
      >
        <span class="glass-dtp-value flex-1 text-left truncate ${this.value ? 'has-value' : ''}">${text}</span>
        <span class="glass-dtp-icon flex items-center gap-2">
          ${this.loading
            ? html `<span class="glass-dtp-spinner h-4 w-4 animate-spin rounded-full"></span>`
            : html `
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  ${svg `<rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>`}
                  ${svg `<line x1="16" y1="2" x2="16" y2="6"></line>`}
                  ${svg `<line x1="8" y1="2" x2="8" y2="6"></line>`}
                  ${svg `<line x1="3" y1="10" x2="21" y2="10"></line>`}
                </svg>
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  ${svg `<circle cx="12" cy="12" r="9"></circle>`}
                  ${svg `<polyline points="12 7 12 12 15 15"></polyline>`}
                </svg>
              `}
        </span>
      </button>
    `;
    }
    renderCalendar() {
        const year = this.currentMonth.getFullYear();
        const month = this.currentMonth.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const cells = [];
        for (let i = 0; i < firstDay; i += 1) {
            cells.push(html `<div></div>`);
        }
        for (let day = 1; day <= daysInMonth; day += 1) {
            const dateStr = `${year}-${this.pad(month + 1)}-${this.pad(day)}`;
            const disabled = this.isDateDisabled(year, month, day);
            const selected = this.selectedDate === dateStr;
            const today = (() => {
                const t = new Date();
                return t.getFullYear() === year && t.getMonth() === month && t.getDate() === day;
            })();
            cells.push(html `
        <button
          class=${this.getDayButtonClasses(selected, disabled, today)}
          role="gridcell"
          aria-selected=${selected ? 'true' : 'false'}
          aria-disabled=${disabled ? 'true' : 'false'}
          @click=${() => this.handleDaySelect(dateStr, disabled)}
          ?disabled=${disabled}
        >
          ${day}
        </button>
      `);
        }
        const weekdayNames = this.getWeekdays();
        return html `
      <div class="flex items-center justify-between mb-2">
        <button type="button" class="glass-dtp-nav px-2 py-1 text-xs" @click=${this.handlePrevMonth}>‹</button>
        <div class="glass-dtp-month text-sm font-medium">
          ${new Intl.DateTimeFormat(this.locale || undefined, { month: 'long', year: 'numeric' }).format(this.currentMonth)}
        </div>
        <button type="button" class="glass-dtp-nav px-2 py-1 text-xs" @click=${this.handleNextMonth}>›</button>
      </div>
      <div class="grid grid-cols-7 gap-1 mb-2 text-[10px] glass-dtp-weekday">
        ${weekdayNames.map((d) => html `<div class="text-center">${d}</div>`)}
      </div>
      <div class="grid grid-cols-7 gap-1">
        ${cells}
      </div>
    `;
    }
    renderTime() {
        const minutes = this.getMinuteOptions();
        return html `
      <div class="grid grid-cols-2 gap-3">
        <div class="flex flex-col gap-1 max-h-40 overflow-auto">
          ${Array.from({ length: 24 }).map((_, hour) => {
            const disabled = this.isTimeDisabled(hour, this.selectedMinute ?? 0) || !this.selectedDate;
            const selected = this.selectedHour === hour;
            return html `
              <button class=${this.getTimeButtonClasses(selected, disabled)} @click=${() => this.handleHourSelect(hour, disabled)} ?disabled=${disabled}>
                ${this.pad(hour)}
              </button>
            `;
        })}
        </div>
        <div class="flex flex-col gap-1 max-h-40 overflow-auto">
          ${minutes.map((minute) => {
            const disabled = this.selectedHour === null || this.isTimeDisabled(this.selectedHour, minute) || !this.selectedDate;
            const selected = this.selectedMinute === minute;
            return html `
              <button class=${this.getTimeButtonClasses(selected, disabled)} @click=${() => this.handleMinuteSelect(minute, disabled)} ?disabled=${disabled}>
                ${this.pad(minute)}
              </button>
            `;
        })}
        </div>
      </div>
    `;
    }
    renderPanel() {
        if (!this.isOpen)
            return html ``;
        return html `
      <div class=${this.getPanelClasses()} role="dialog" aria-modal="true">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>${this.renderCalendar()}</div>
          <div>${this.renderTime()}</div>
        </div>
        <div class="mt-4 flex items-center justify-end gap-2">
          <button type="button" class="glass-dtp-clear px-3 py-1 text-xs" @click=${this.handleClear}>${this.msg.clear}</button>
          <button type="button" class="glass-dtp-confirm px-3 py-1 text-xs" @click=${this.handleConfirm}>${this.msg.confirm}</button>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            const display = this.displayValue || this.formatDisplay(this.value) || this.msg.empty;
            return html `
        <div class="flex flex-col gap-1">
          ${this.renderHiddenInput()}
          ${this.renderLabel()}
          <div class="glass-dtp-view text-sm">${display}</div>
        </div>
      `;
        }
        return html `
      <div class="relative flex flex-col gap-1">
        ${this.renderHiddenInput()}
        ${this.renderLabel()}
        ${this.renderTrigger()}
        ${this.renderPanel()}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlDatetimePickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatetimePickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatetimePickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatetimePickerMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatetimePickerMolecule.prototype, "timezone", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-datetime' })
], MlDatetimePickerMolecule.prototype, "minDatetime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-datetime' })
], MlDatetimePickerMolecule.prototype, "maxDatetime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], MlDatetimePickerMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDatetimePickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDatetimePickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatetimePickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatetimePickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatetimePickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDatetimePickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "displayValue", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "selectedDate", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "selectedHour", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "selectedMinute", void 0);
__decorate([
    state()
], MlDatetimePickerMolecule.prototype, "currentMonth", void 0);
MlDatetimePickerMolecule = __decorate([
    customElement('groupenterdatetime--ml-datetime-picker')
], MlDatetimePickerMolecule);
export { MlDatetimePickerMolecule };
