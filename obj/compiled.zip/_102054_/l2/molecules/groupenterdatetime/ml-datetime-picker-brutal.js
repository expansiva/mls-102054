var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATETIME PICKER — BRUTALISM por HERANÇA (mls-102054)
// =============================================================================
// Skill Group: enter + datetime
// Herda toda a lógica de MlDatetimePickerMolecule (mls-102040): parsing ISO,
// navegação de mês, seleção de dia/hora/minuto, range min/max, confirm/clear,
// outside-click e estado reativo (isOpen/selectedDate/selectedHour/...).
// Sobrescreve apenas render()/painel com classes brutal. A formatação de exibição
// é refeita localmente (i18n próprio) para não depender do `msg` privado do pai.
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement } from 'lit/decorators.js';
import { MlDatetimePickerMolecule } from '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select date and time',
    loading: 'Loading...',
    confirm: 'Confirm',
    clear: 'Clear',
    empty: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione data e hora',
        loading: 'Carregando...',
        confirm: 'Confirmar',
        clear: 'Limpar',
        empty: '—',
    },
    de: {
        placeholder: 'Datum und Uhrzeit wählen',
        loading: 'Laden...',
        confirm: 'Bestätigen',
        clear: 'Löschen',
        empty: '—',
    },
};
let DatetimePickerBrutal = class DatetimePickerBrutal extends MlDatetimePickerMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdatetime--ml-datetime-picker-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-label {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-label.is-disabled {
  opacity: 0.4;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-req {
  color: #ef4444;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-helper {
  color: #666;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-error-text {
  color: #ef4444;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-view {
  color: #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-icon {
  color: #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-spinner {
  border: 3px solid #ccc;
  border-top-color: #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-month {
  color: #000;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-weekday {
  color: #666;
  font-weight: 700;
  text-transform: uppercase;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-trigger {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  box-shadow: 3px 3px 0 #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-trigger.is-focused {
  outline: 3px solid #000;
  outline-offset: 2px;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-trigger.is-error {
  border-color: #ef4444;
  box-shadow: 3px 3px 0 #ef4444;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-trigger.is-disabled {
  opacity: 0.4;
  border-color: #999;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-value {
  color: #999;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-value.has-value {
  color: #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-panel,
.brutal-dtp-portal .brutal-dtp-panel {
  background: #fff;
  border: 3px solid #000;
  border-radius: 0;
  box-shadow: 6px 6px 0 #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-nav,
.brutal-dtp-portal .brutal-dtp-nav {
  background: #fff;
  border: 2px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  font-weight: 700;
  box-shadow: 2px 2px 0 #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-nav:hover,
.brutal-dtp-portal .brutal-dtp-nav:hover {
  background: #000;
  color: #fff;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-nav:active,
.brutal-dtp-portal .brutal-dtp-nav:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-day,
.brutal-dtp-portal .brutal-dtp-day {
  border-radius: 0;
  border: 2px solid transparent;
  color: #000;
  cursor: pointer;
  font-weight: 700;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-day:hover:not(.is-disabled):not(.is-selected),
.brutal-dtp-portal .brutal-dtp-day:hover:not(.is-disabled):not(.is-selected) {
  background: #f0f0f0;
  border-color: #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-day.is-today,
.brutal-dtp-portal .brutal-dtp-day.is-today {
  border-color: #3b82f6;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-day.is-selected,
.brutal-dtp-portal .brutal-dtp-day.is-selected {
  background: #000;
  border-color: #000;
  color: #fff;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-day.is-disabled,
.brutal-dtp-portal .brutal-dtp-day.is-disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-time,
.brutal-dtp-portal .brutal-dtp-time {
  border-radius: 0;
  border: 2px solid transparent;
  color: #000;
  cursor: pointer;
  font-weight: 700;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-time:hover:not(.is-disabled):not(.is-selected),
.brutal-dtp-portal .brutal-dtp-time:hover:not(.is-disabled):not(.is-selected) {
  background: #f0f0f0;
  border-color: #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-time.is-selected,
.brutal-dtp-portal .brutal-dtp-time.is-selected {
  background: #000;
  border-color: #000;
  color: #fff;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-time.is-disabled,
.brutal-dtp-portal .brutal-dtp-time.is-disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-clear,
.brutal-dtp-portal .brutal-dtp-clear {
  background: #fff;
  border: 2px solid #000;
  border-radius: 0;
  color: #000;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-clear:hover,
.brutal-dtp-portal .brutal-dtp-clear:hover {
  background: #000;
  color: #fff;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-clear:active,
.brutal-dtp-portal .brutal-dtp-clear:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-confirm,
.brutal-dtp-portal .brutal-dtp-confirm {
  background: #3b82f6;
  border: 2px solid #000;
  border-radius: 0;
  color: #fff;
  cursor: pointer;
  font-weight: 700;
  text-transform: uppercase;
  box-shadow: 2px 2px 0 #000;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-confirm:hover,
.brutal-dtp-portal .brutal-dtp-confirm:hover {
  background: #2563eb;
}
groupenterdatetime--ml-datetime-picker-brutal .brutal-dtp-confirm:active,
.brutal-dtp-portal .brutal-dtp-confirm:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
`);
        this.portalClassName = 'brutal-dtp-portal';
        this.bMsg = messages.en;
    }
    get x() {
        return this;
    }
    // --- formatação de exibição (própria, i18n local) ---
    brutalFormatDisplay(value) {
        if (!value)
            return '';
        const parsed = this.x.parseIso(value);
        if (!parsed)
            return '';
        const date = this.timezone
            ? new Date(Date.UTC(parsed.year, parsed.month - 1, parsed.day, parsed.hour, parsed.minute, parsed.second))
            : new Date(parsed.year, parsed.month - 1, parsed.day, parsed.hour, parsed.minute, parsed.second);
        const formatter = new Intl.DateTimeFormat(this.locale || undefined, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            timeZone: this.timezone || undefined,
        });
        return formatter.format(date);
    }
    // ===========================================================================
    // CLASSES (brutal)
    // ===========================================================================
    brutalTriggerClasses() {
        return [
            'brutal-dtp-trigger w-full flex items-center justify-between gap-3 px-3 py-2 text-sm',
            this.x.isFocused ? 'is-focused' : '',
            this.error ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalLabelClasses() {
        return ['brutal-dtp-label text-sm font-medium', this.disabled ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    brutalDayClasses(selected, disabled, today) {
        return [
            'brutal-dtp-day h-8 w-8 text-xs',
            selected ? 'is-selected' : '',
            today && !selected ? 'is-today' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    brutalTimeClasses(selected, disabled) {
        return [
            'brutal-dtp-time w-full px-2 py-1 text-xs text-left',
            selected ? 'is-selected' : '',
            disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS (brutal)
    // ===========================================================================
    brutalLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${this.x.labelId} class=${this.brutalLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="brutal-dtp-req ml-1">*</span>` : nothing}
      </label>
    `;
    }
    brutalHiddenInput() {
        if (!this.name)
            return html ``;
        return html `<input type="hidden" name=${this.name} .value=${this.value || ''} />`;
    }
    brutalHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id=${this.x.errorId} class="brutal-error-text mt-1 text-xs">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${this.x.helperId} class="brutal-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    brutalTrigger() {
        const x = this.x;
        const placeholder = this.placeholder || this.bMsg.placeholder;
        const display = this.brutalFormatDisplay(this.value);
        const text = display || placeholder;
        return html `
      <button
        class=${this.brutalTriggerClasses()}
        type="button"
        aria-labelledby=${ifDefined(this.hasSlot('Label') ? x.labelId : undefined)}
        aria-describedby=${ifDefined(x.getAriaDescribedBy())}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        aria-label=${text}
        @focus=${() => x.handleFocus()}
        @blur=${() => x.handleBlur()}
        @click=${() => x.handleTriggerClick()}
        ?disabled=${this.disabled || this.loading}
      >
        <span class="brutal-dtp-value flex-1 text-left truncate ${this.value ? 'has-value' : ''}">${text}</span>
        <span class="brutal-dtp-icon flex items-center gap-2">
          ${this.loading
            ? html `<span class="brutal-dtp-spinner h-4 w-4 animate-spin"></span>`
            : html `
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  ${svg `<rect x="3" y="4" width="18" height="18" rx="0" ry="0"></rect>`}
                  ${svg `<line x1="16" y1="2" x2="16" y2="6"></line>`}
                  ${svg `<line x1="8" y1="2" x2="8" y2="6"></line>`}
                  ${svg `<line x1="3" y1="10" x2="21" y2="10"></line>`}
                </svg>
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  ${svg `<circle cx="12" cy="12" r="9"></circle>`}
                  ${svg `<polyline points="12 7 12 12 15 15"></polyline>`}
                </svg>
              `}
        </span>
      </button>
    `;
    }
    brutalCalendar() {
        const x = this.x;
        const year = x.currentMonth.getFullYear();
        const month = x.currentMonth.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const cells = [];
        for (let i = 0; i < firstDay; i += 1) {
            cells.push(html `<div></div>`);
        }
        for (let day = 1; day <= daysInMonth; day += 1) {
            const dateStr = `${year}-${x.pad(month + 1)}-${x.pad(day)}`;
            const disabled = x.isDateDisabled(year, month, day);
            const selected = x.selectedDate === dateStr;
            const today = (() => {
                const t = new Date();
                return t.getFullYear() === year && t.getMonth() === month && t.getDate() === day;
            })();
            cells.push(html `
        <button
          class=${this.brutalDayClasses(selected, disabled, today)}
          role="gridcell"
          aria-selected=${selected ? 'true' : 'false'}
          aria-disabled=${disabled ? 'true' : 'false'}
          @click=${() => x.handleDaySelect(dateStr, disabled)}
          ?disabled=${disabled}
        >
          ${day}
        </button>
      `);
        }
        const weekdayNames = x.getWeekdays();
        return html `
      <div class="flex items-center justify-between mb-2">
        <button type="button" class="brutal-dtp-nav px-2 py-1 text-xs" @click=${() => x.handlePrevMonth()}>&#9664;</button>
        <div class="brutal-dtp-month text-sm font-medium">
          ${new Intl.DateTimeFormat(this.locale || undefined, { month: 'long', year: 'numeric' }).format(x.currentMonth)}
        </div>
        <button type="button" class="brutal-dtp-nav px-2 py-1 text-xs" @click=${() => x.handleNextMonth()}>&#9654;</button>
      </div>
      <div class="grid grid-cols-7 gap-1 mb-2 text-[10px] brutal-dtp-weekday">
        ${weekdayNames.map((d) => html `<div class="text-center">${d}</div>`)}
      </div>
      <div class="grid grid-cols-7 gap-1">
        ${cells}
      </div>
    `;
    }
    brutalTime() {
        const x = this.x;
        const minutes = x.getMinuteOptions();
        return html `
      <div class="grid grid-cols-2 gap-3">
        <div class="flex flex-col gap-1 max-h-40 overflow-auto">
          ${Array.from({ length: 24 }).map((_, hour) => {
            const disabled = x.isTimeDisabled(hour, x.selectedMinute ?? 0) || !x.selectedDate;
            const selected = x.selectedHour === hour;
            return html `
              <button class=${this.brutalTimeClasses(selected, disabled)} @click=${() => x.handleHourSelect(hour, disabled)} ?disabled=${disabled}>
                ${x.pad(hour)}
              </button>
            `;
        })}
        </div>
        <div class="flex flex-col gap-1 max-h-40 overflow-auto">
          ${minutes.map((minute) => {
            const disabled = x.selectedHour === null || x.isTimeDisabled(x.selectedHour, minute) || !x.selectedDate;
            const selected = x.selectedMinute === minute;
            return html `
              <button class=${this.brutalTimeClasses(selected, disabled)} @click=${() => x.handleMinuteSelect(minute, disabled)} ?disabled=${disabled}>
                ${x.pad(minute)}
              </button>
            `;
        })}
        </div>
      </div>
    `;
    }
    getPortalTemplate() {
        const x = this.x;
        return html `
      <div class="brutal-dtp-panel mt-2 p-4" role="dialog" aria-modal="true">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>${this.brutalCalendar()}</div>
          <div>${this.brutalTime()}</div>
        </div>
        <div class="mt-4 flex items-center justify-end gap-2">
          <button type="button" class="brutal-dtp-clear px-3 py-1 text-xs" @click=${() => x.handleClear()}>${this.bMsg.clear}</button>
          <button type="button" class="brutal-dtp-confirm px-3 py-1 text-xs" @click=${() => x.handleConfirm()}>${this.bMsg.confirm}</button>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — lógica/estado herdados via this.x
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.bMsg = messages[lang];
        if (!this.isEditing) {
            const display = this.brutalFormatDisplay(this.value) || this.bMsg.empty;
            return html `
        <div class="flex flex-col gap-1">
          ${this.brutalHiddenInput()}
          ${this.brutalLabel()}
          <div class="brutal-dtp-view text-sm">${display}</div>
        </div>
      `;
        }
        return html `
      <div class="relative flex flex-col gap-1">
        ${this.brutalHiddenInput()}
        ${this.brutalLabel()}
        ${this.brutalTrigger()}
        ${this.brutalHelperOrError()}
      </div>
    `;
    }
};
DatetimePickerBrutal = __decorate([
    customElement('groupenterdatetime--ml-datetime-picker-brutal')
], DatetimePickerBrutal);
export { DatetimePickerBrutal };
