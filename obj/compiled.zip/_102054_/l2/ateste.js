/// <mls fileReference="_102054_/l2/ateste.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let Ateste102054 = class Ateste102054 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-102054 {
  color: red;
}
`);
        this.name = 'Somebody';
    }
    render() {
        return html `<p> Hello, ${this.name} !</p>`;
    }
};
__decorate([
    property()
], Ateste102054.prototype, "name", void 0);
Ateste102054 = __decorate([
    customElement('ateste-102054')
], Ateste102054);
export { Ateste102054 };
