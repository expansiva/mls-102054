declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102054_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102054_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102054_/l2/molecules/groupenterboolean/ml-toggle-switch" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102054_/l2/molecules/groupenterboolean/ml-toggle-switch";
    export class GroupEnterBooleanIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/ml-toggle-switch.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch\n\n# Objective\nA boolean input molecule that enables users to switch between two mutually exclusive states. It provides an interactive toggle during editing mode and displays the current selection as static text during read-only mode. It reports value changes, focus, and blur to the surrounding system, and presents labels, contextual guidance, and validation errors according to its current state.\n\n# Responsibilities\n- Present an interactive binary toggle when in editing mode\n- Display static text representing the current value when not in editing mode, showing \"Yes\" for true and \"No\" for false\n- Accept and display label content through the contract-defined label region\n- Accept and display helper content through the contract-defined helper region when no validation error is present and in editing mode\n- Display validation error messages when provided and in editing mode\n- Change the boolean value upon user activation when in editing mode\n- Report value changes to the system, including the new boolean state\n- Report when the control receives focus\n- Report when the control loses focus\n- Prevent user activation and suppress value change reports when disabled\n- Prevent all interaction and suppress reports when not in editing mode\n- Initialize with a default value of false when no prior value exists\n- Support keyboard activation to change the value when enabled and in editing mode\n- Communicate the current boolean state to accessibility tools\n- Communicate the disabled condition to accessibility tools when applicable\n- Communicate the invalid condition to accessibility tools when a validation error is present\n- Maintain programmatic associations between the control and its label, helper text, and error messages\n\n# Constraints\n- Must exclusively use the Label and Helper content regions defined in the contract\n- Must treat the value strictly as a boolean type without intermediate states\n- Must not permit value changes while disabled\n- Must not report value changes while disabled\n- Must not permit interaction or report focus, blur, or value changes when not in editing mode\n- Must suppress helper text display when a validation error message is present\n- Must not display helper text or error messages when not in editing mode\n- Must ensure value change reports are detectable outside the component\n- Must display \"Yes\" only when the value is true in read-only mode\n- Must display \"No\" only when the value is false in read-only mode\n\n# Notes\n- The control maintains a strict binary state; null or indeterminate values are not supported\n- Keyboard activation should follow conventional toggle interaction patterns\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-button-standard" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ButtonStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private isDisabled;
        private getVariant;
        private getSizeKey;
        private getSizeClasses;
        private getButtonClasses;
        private getIconClasses;
        private renderSpinner;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102054_/l2/molecules/grouptriggeraction/ml-button-standard";
    export class GroupTriggerActionIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-button-standard.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard\n\n# Objective\nA standard button molecule for the groupTriggerAction group that triggers actions when activated. It supports text labels, icons, multiple sizes, visual styles, loading states with a spinner indicator, and disabled states. Designed for corporate interfaces such as ERP, CRM, HR, Financial, and Logistics systems.\n\n# Responsibilities\n- Display a text label and/or an icon provided through the designated Label and Icon content areas.\n- Arrange the icon either before or after the text label based on configuration.\n- Adjust overall dimensions and icon scale according to the selected size.\n- Behave as a standard button, a submit button, or a reset button based on configuration.\n- Ignore activation attempts and present a disabled state when configured as disabled.\n- Ignore activation attempts and present a busy state when configured as loading.\n- Show a loading spinner in place of the icon or text during loading, keeping the button size unchanged.\n- Trigger an action event when activated by pointer or keyboard (Enter or Space), unless disabled or loading.\n- Expose an accessible name for icon-only buttons using the Label content when available.\n- Support rich content within the Label and Icon areas.\n- Provide distinct visual feedback for Normal, Hover, Active, and Focused states, with a visible focus indicator for keyboard users.\n- Reduce opacity and remove interactive feedback when disabled.\n- Support visual variations for primary, secondary, danger, ghost, and link styles through theming.\n\n# Constraints\n- Must compose content using only the Label and Icon areas.\n- Icon position must be either 'start' or 'end'.\n- Size must be one of 'xs', 'sm', 'md', or 'lg'.\n- Type must be one of 'button', 'submit', or 'reset'.\n- When disabled, the action event must not trigger.\n- When loading, the action event must not trigger, and the button must expose busy and disabled states for accessibility.\n- During loading, the spinner replaces the icon if present; otherwise, it replaces the text label.\n- The action event must contain no detail and must propagate normally.\n- For icon-only buttons, the accessible name must come from the Label content if provided; otherwise, it must be empty.\n- Visual style variations must not require additional configuration properties.\n\n# Notes\n- Designed for corporate contexts such as ERP forms, CRM proposals, HR approvals, financial payments, and logistics operations.\n- The button must preserve its dimensions during loading to prevent layout shifts.\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; assumes a rich/dark background behind the component (container contract).";
}
