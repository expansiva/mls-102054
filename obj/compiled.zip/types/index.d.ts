declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102054_/l2/ateste" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class Ateste102054 extends CollabLitElement {
        name: string;
        render(): any;
    }
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102054_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102054_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch';
    export class GroupEnterBooleanIndex extends StateLitElement {
        private cardOff;
        private cardOn;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/ml-toggle-switch.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch\n\n# Objective\nA boolean input molecule that enables users to switch between two mutually exclusive states. It provides an interactive toggle during editing mode and displays the current selection as static text during read-only mode. It reports value changes, focus, and blur to the surrounding system, and presents labels, contextual guidance, and validation errors according to its current state.\n\n# Responsibilities\n- Present an interactive binary toggle when in editing mode\n- Display static text representing the current value when not in editing mode, showing \"Yes\" for true and \"No\" for false\n- Accept and display label content through the contract-defined label region\n- Accept and display helper content through the contract-defined helper region when no validation error is present and in editing mode\n- Display validation error messages when provided and in editing mode\n- Change the boolean value upon user activation when in editing mode\n- Report value changes to the system, including the new boolean state\n- Report when the control receives focus\n- Report when the control loses focus\n- Prevent user activation and suppress value change reports when disabled\n- Prevent all interaction and suppress reports when not in editing mode\n- Initialize with a default value of false when no prior value exists\n- Support keyboard activation to change the value when enabled and in editing mode\n- Communicate the current boolean state to accessibility tools\n- Communicate the disabled condition to accessibility tools when applicable\n- Communicate the invalid condition to accessibility tools when a validation error is present\n- Maintain programmatic associations between the control and its label, helper text, and error messages\n\n# Constraints\n- Must exclusively use the Label and Helper content regions defined in the contract\n- Must treat the value strictly as a boolean type without intermediate states\n- Must not permit value changes while disabled\n- Must not report value changes while disabled\n- Must not permit interaction or report focus, blur, or value changes when not in editing mode\n- Must suppress helper text display when a validation error message is present\n- Must not display helper text or error messages when not in editing mode\n- Must ensure value change reports are detectable outside the component\n- Must display \"Yes\" only when the value is true in read-only mode\n- Must display \"No\" only when the value is false in read-only mode\n\n# Notes\n- The control maintains a strict binary state; null or indeterminate values are not supported\n- Keyboard activation should follow conventional toggle interaction patterns\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; assumes a rich/dark background behind the component (container contract).";
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class MoleculeAuraElement extends StateLitElement {
        protected slotTags: string[];
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/ml-toggle-switch" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenterdate/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker';
    export class GroupEnterDateIndex extends StateLitElement {
        private date;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterdate/ml-date-picker.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-date-picker\n\n# Objective\nA date picker with a trigger field and a popover calendar. The value is an ISO date string (YYYY-MM-DD). Supports locale formatting, min/max date bounds, first day of week, optional week numbers, validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Open a popover calendar; navigate months (respecting min/max) and select a day.\n- Format the trigger and view value via Intl.DateTimeFormat; mark today and the selected day.\n- Clear the value; close on outside click; dispatch change ({ value }), monthChange ({ year, month }), focus and blur.\n\n# Constraints\n- Dates outside min/max are disabled; no changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent trigger; calendar popover uses rgba(30,27,75,0.85) + blur(18px); selected day in indigo. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupenterdate/ml-date-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlDatePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        private fieldId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleToggleOpen;
        private handleFocus;
        private handleBlur;
        private handleOutsideClick;
        private handlePrevMonth;
        private handleNextMonth;
        private handleSelectDay;
        private handleClear;
        private syncViewToValue;
        private ensureViewWithinRange;
        private parseIsoDate;
        private toIsoDate;
        private toDateKey;
        private formatDisplay;
        private formatTriggerValue;
        private getWeekdayLabels;
        private getDaysInMonth;
        private addMonths;
        private isDateDisabled;
        private canNavigatePrev;
        private canNavigateNext;
        private getISOWeekNumber;
        private getContainerClasses;
        private getTriggerClasses;
        private getDayClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderCalendar;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenterdatetime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    export class GroupEnterDatetimeIndex extends StateLitElement {
        private dt;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker.defs" {
    export const group = "groupEnterDatetime";
    export const skill = "# Metadata\n- TagName: groupenterdatetime--ml-datetime-picker\n\n# Objective\nA combined date and time picker. The value is an ISO datetime string (YYYY-MM-DDTHH:mm:ss). The popover shows a month calendar plus hour and minute columns, confirmed via a button. Supports locale/timezone formatting, min/max datetime bounds, minute step, validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Open a popover; select a day, then an hour and minute; confirm to commit the value.\n- Disable out-of-range dates/times based on min/max and the chosen day; auto-pick the first valid time.\n- Format the trigger/view via Intl.DateTimeFormat; clear the value; close on outside click.\n- Dispatch change ({ value }), focus and blur; keep a hidden input in sync for forms.\n\n# Constraints\n- Values outside min/max are disabled; no changes while disabled, readonly or loading; selection is only committed on Confirm.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent trigger; popover uses rgba(30,27,75,0.85) + blur(18px); selected day/time in indigo; confirm button is a solid indigo accent. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlDatetimePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private displayValue;
        private selectedDate;
        private selectedHour;
        private selectedMinute;
        private currentMonth;
        private labelId;
        private helperId;
        private errorId;
        private documentClickBound;
        createRenderRoot(): this;
        handleIcaStateChange(key: string, value: any): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleFocus;
        private handleBlur;
        private handleDaySelect;
        private handleHourSelect;
        private handleMinuteSelect;
        private handleConfirm;
        private handleClear;
        private handlePrevMonth;
        private handleNextMonth;
        private openPicker;
        private closePicker;
        private addDocumentListener;
        private removeDocumentListener;
        private handleDocumentClick;
        private prepareOpenState;
        private updateFromValue;
        private updateDisplay;
        private formatDisplay;
        private parseIso;
        private pad;
        private getMinuteOptions;
        private parseMinMax;
        private getMinDate;
        private getMaxDate;
        private isDateDisabled;
        private isTimeDisabled;
        private getFirstValidTime;
        private getFirstValidMinute;
        private getTriggerClasses;
        private getLabelClasses;
        private getPanelClasses;
        private getDayButtonClasses;
        private getTimeButtonClasses;
        private getAriaDescribedBy;
        private getWeekdays;
        private renderLabel;
        private renderHiddenInput;
        private renderHelperOrError;
        private renderTrigger;
        private renderCalendar;
        private renderTime;
        private renderPanel;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentermoney/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input';
    export class GroupEnterMoneyIndex extends StateLitElement {
        private price;
        private budget;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentermoney/ml-currency-input.defs" {
    export const group = "groupEnterMoney";
    export const skill = "# Metadata\n- TagName: groupentermoney--ml-currency-input\n\n# Objective\nA currency amount input. The user types digits which are interpreted as minor units (cents) and formatted with locale/currency. Supports min/max clamping, decimals, optional symbol, validation, disabled/readonly/loading and a read-only view mode.\n\n# Responsibilities\n- Maintain a raw input string and parse it to a number (BigInt-safe) on input.\n- Format the committed value with Intl.NumberFormat (currency or decimal) on blur and in view mode.\n- Clamp the value to min/max on blur and dispatch input/change/focus/blur with { value }.\n- Render label, helper or error, and a loading overlay.\n\n# Constraints\n- Value is rounded to the configured number of decimals and clamped to min/max on blur.\n- No value changes while disabled or readonly.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent field with light text. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupentermoney/ml-currency-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class GroupEnterMoneyMlCurrencyInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        currency: string;
        locale: string;
        decimals: number;
        min: number | null;
        max: number | null;
        showSymbol: boolean;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        private getEffectiveLocale;
        private formatNumber;
        private formatToRaw;
        /**
         * Parses the raw string entered by the user, interpreting it as an integer of cents
         * (or the appropriate fraction based on `decimals`). Returns a number or null.
         * Supports up to 20 digits by using BigInt for the intermediate integer value.
         */
        private parseRawToNumber;
        private clampValue;
        private onFocus;
        private onInput;
        private onBlur;
        private getInputClasses;
        private getContainerClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderInput;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenternumber/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider';
    export class GroupEnterNumberIndex extends StateLitElement {
        private qty;
        private priceLow;
        private priceHigh;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenternumber/ml-number-stepper.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-number-stepper\n\n# Objective\nA numeric input with increment/decrement buttons. Supports min/max bounds, step, decimal precision, locale-aware formatting, prefix/suffix, validation, disabled/readonly/loading and a read-only view mode.\n\n# Responsibilities\n- Display a formatted numeric value with optional prefix/suffix; allow typing and parsing back to a number using locale separators.\n- Increment/decrement by step, clamped to min/max; round to the configured decimals.\n- Dispatch input on typing and change on blur/step; dispatch focus/blur events.\n- Show validation error (including required when empty); show helper otherwise.\n- Render a plain read-only view when not editing; show loading state.\n\n# Constraints\n- Value must respect min/max and decimals.\n- No interaction while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Field and buttons are translucent glass. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupenternumber/ml-number-stepper" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class NumberStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        connectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private increment;
        private decrement;
        private emitInput;
        private emitChange;
        private formatToDisplay;
        private parseRawToNumber;
        private normalizeValue;
        private roundToDecimals;
        private getNumberSeparators;
        private getInputClasses;
        private getButtonClasses;
        private getContainerClasses;
        private getRowClasses;
        render(): any;
        private renderViewMode;
        private renderLabel;
        private renderHelperOrError;
        private renderPrefix;
        private renderSuffix;
    }
}
declare module "_102054_/l2/molecules/groupenternumber/ml-range-slider.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-range-slider\n\n# Objective\nA dual-handle range slider for selecting a numeric interval (low/high). Supports min/max, step, decimals, locale formatting, prefix/suffix, validation, disabled/readonly/loading and a read-only view mode.\n\n# Responsibilities\n- Render two range inputs (low and high) bound to value and value-high; clamp the pair so low <= high.\n- Display the formatted current low/high values with optional prefix/suffix and a separator.\n- Dispatch input while dragging and change on commit/blur with { value: { min, max } }; dispatch focus/blur.\n- Show validation error or helper; show loading state; render a read-only summary when not editing.\n\n# Constraints\n- low must not exceed high; values are clamped to min/max and rounded to decimals.\n- No value changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Track and thumbs are translucent glass. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupenternumber/ml-range-slider" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class RangeSliderMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: number | null;
        valueHigh: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValueLow;
        private rawValueHigh;
        handleIcaStateChange(key: string, value: any): void;
        private getLabelId;
        private getErrorId;
        private getHelperId;
        private getDisplayPlaceholder;
        private isIntervalUnset;
        private getBounds;
        private normalizeValue;
        private roundToDecimals;
        private formatToDisplay;
        private clampPair;
        private emitInput;
        private emitChange;
        private emitFocus;
        private emitBlur;
        private handleLowInput;
        private handleHighInput;
        private handleLowChange;
        private handleHighChange;
        private handleFocus;
        private handleBlur;
        private renderLabel;
        private renderPrefixSuffix;
        private renderHelperOrError;
        private getInputClasses;
        private getValueDisplay;
        private renderLoading;
        private renderEditMode;
        private renderViewMode;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input';
    export class GroupEnterTextIndex extends StateLitElement {
        private fullName;
        private username;
        private password;
        private tags;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentertext/ml-floating-text-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input\n\n# Objective\nAllow the user to enter a single line of text through an input field that features a floating label \u2014 the label starts in the placeholder position and animates upward when the field is focused or has a value. The component supports optional input masking, prefix and suffix slots, character length limits, multiple input types, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a floating label that animates to a smaller position above the input when the field is focused or has a value.\n- Accept and expose typed text as the component's value, dispatching an \"input\" event on each keystroke and a \"change\" event on blur.\n- Apply an optional input mask: insert literal separator characters automatically, strip non-matching characters, and store only the raw (unmasked) digits or letters as the value.\n- Enforce optional maximum and minimum character length limits on the raw value.\n- Support multiple input types (text, password, email, etc.) via the input-type property; never apply masking when the type is \"password\".\n- Render a read-only view mode (isEditing = false) that shows the label and value as plain text, displaying \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\" for password type and \"\u2014\" when the value is empty.\n- Show an inline error message styled in red when the error property is set.\n- Show a helper text below the field when a Helper slot is provided and there is no error.\n- Render optional prefix and suffix content inside the input container via named slots.\n- Show a spinning indicator inside the suffix area when the loading state is active.\n- Dispatch \"focus\" and \"blur\" custom events when the underlying input gains or loses focus.\n- Synchronize the displayed masked value when the bound value, mask, or input-type changes externally.\n\n# Constraints\n- Input, typing, focus, and all interaction must be blocked when disabled, readonly, loading, or isEditing is false.\n- Masking must never be applied to password-type inputs.\n- The raw (unmasked) value must be stored in the value property; masked characters are display-only.\n- The clear action and option list are not part of this component; it is a plain text input, not a select.\n- Error styling must persist until the error property is cleared externally.\n- The loading state must prevent interaction and display a spinner in place of or alongside the suffix slot.\n- Multiple simultaneous selections or multi-line input are not supported by this component.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupentertext/ml-floating-text-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlFloatingTextInputMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private isFocused;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private shouldUseMask;
        private getMaskedDisplayValue;
        private applyMaskToRaw;
        private extractRawFromInput;
        private isMaskToken;
        private isCharValidForToken;
        private getLabelText;
        private getInputPlaceholder;
        private getViewValue;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderInlineLabel;
        private renderFloatingLabel;
        private getContainerClasses;
        private getInputClasses;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentertext/ml-password-strength-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-password-strength-input\n\n# Objective\nA password input with a live strength meter and criteria checklist (min length, uppercase, number, symbol). Supports show/hide toggle, optional mask, prefix/suffix, validation, disabled/readonly/loading and a masked read-only view.\n\n# Responsibilities\n- Maintain the password value, apply optional mask, and toggle visibility (text/password).\n- Compute the criteria status and strength level (weak/medium/strong/veryStrong) and render the bar + checklist.\n- Dispatch input/change/focus/blur with { value }.\n- Render label, helper or error, and a loading state.\n\n# Constraints\n- maxLength limits the stored value; no value changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent field; strength bar uses semantic colors on a dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupentertext/ml-password-strength-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class PasswordStrengthInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isPasswordVisible;
        private isFocused;
        private rawDisplay;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private applyMask;
        private extractRawValue;
        private getCriteriaStatus;
        private getStrengthLevel;
        private getStrengthLabel;
        private getStrengthBarClasses;
        private getStrengthTextClasses;
        private handleInput;
        private handleChange;
        private handleFocus;
        private handleBlur;
        private togglePasswordVisibility;
        private getContainerClasses;
        private getInputWrapperClasses;
        private getInputClasses;
        private getToggleButtonClasses;
        private getCriteriaItemClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderToggleButton;
        private renderInput;
        private renderStrengthIndicator;
        private renderCriteriaItem;
        private renderHelper;
        private renderError;
        private renderLoading;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentertext/ml-tag-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-tag-input\n\n# Objective\nA tag/chip input. The user types tokens and commits them with Enter or comma; tags are stored as a comma-separated string. Backspace on an empty field removes the last tag. Supports a multi-line textarea mode (rows > 1), min/max length, prefix/suffix, validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Parse value into tags (split by comma) and render removable chips.\n- Add tags on Enter/comma/blur (dedup case-insensitively, enforce min/max length) and remove by index.\n- In multi-line mode, behave as a plain textarea with optional character counter.\n- Dispatch input/change/focus/blur with { value } and focus the field on container click.\n\n# Constraints\n- Duplicate tags (case-insensitive) and tags outside min/max length are rejected.\n- No edits while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent box with frosted chips. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupentertext/ml-tag-input" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlTagInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private currentInput;
        private isFocused;
        private get tags();
        private get isInteractive();
        private get isMultiLine();
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleKeyDown;
        private addTag;
        private removeTagByIndex;
        private handleFocus;
        private handleBlur;
        private handleContainerClick;
        private getContainerClasses;
        private getInputClasses;
        private getTagClasses;
        private getRemoveButtonClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderTag;
        private renderTags;
        private renderInput;
        private renderTextarea;
        private renderEditMode;
        private renderViewMode;
        private renderHelper;
        private renderLoadingIndicator;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentertime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class GroupEnterTimeIndex extends StateLitElement {
        private time;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentertime/ml-clock-time-picker.defs" {
    export const group = "groupEnterTime";
    export const skill = "# Metadata\n- TagName: groupentertime--ml-clock-time-picker\n\n# Objective\nA time picker with a read-only field and a popover that steps through hour, then minute, then (optionally) second selection. The value is a time string (HH:mm or HH:mm:ss). Supports 12/24-hour mode with AM/PM, minute step, min/max time bounds, validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Open a popover; pick hour \u2192 minute \u2192 (second); toggle AM/PM in 12-hour mode; confirm to commit.\n- Disable out-of-range hours/minutes/seconds based on min/max time; format the field via Intl.DateTimeFormat.\n- Clear the value; close on outside click; dispatch change ({ value }), focus and blur.\n\n# Constraints\n- Values outside min/max are disabled; selection is only committed on Confirm; no changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent field; popover uses rgba(30,27,75,0.85) + blur(18px); circular time options, selected in indigo; confirm is a solid indigo accent. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupentertime/ml-clock-time-picker" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ClockTimePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private stage;
        private selectedHour;
        private selectedMinute;
        private selectedSecond;
        private amPm;
        handleIcaStateChange(key: string, value: any): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private onToggleOpen;
        private onOutsideClick;
        private onInputFocus;
        private onInputBlur;
        private onSelectHour;
        private onSelectMinute;
        private onSelectSecond;
        private onConfirm;
        private onClear;
        private onToggleAmPm;
        private canInteract;
        private syncSelectionFromValue;
        private parseTime;
        private formatTime;
        private buildValueString;
        private isSelectionComplete;
        private convertTo24Hour;
        private convertTo12Hour;
        private attachOutsideClick;
        private detachOutsideClick;
        private isHourDisabled;
        private isMinuteDisabled;
        private isSecondDisabled;
        private getHourOptions;
        private getMinuteOptions;
        private getSecondOptions;
        private getInputClasses;
        private getOptionClasses;
        private getPanelClasses;
        private getLabelClasses;
        private getStepLabel;
        private renderLabel;
        private renderHelperOrError;
        private renderClockOptions;
        private renderAmPm;
        private getLabelId;
        private getHelperId;
        private getErrorId;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    export class GroupExpandContentIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-accordion.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-accordion\n\n# Objective\nAllow the user to expand and collapse individually labeled content sections arranged vertically. The component can operate in single-expand mode (only one section open at a time) or multi-expand mode (any number of sections open simultaneously), and supports disabled, loading, and per-section disabled states with full keyboard navigation.\n\n# Responsibilities\n- Render each Section slot as a collapsible panel with a clickable header showing its title attribute.\n- Track which sections are open and toggle them when their header is clicked or activated via keyboard.\n- In single-expand mode, close any currently open section before opening a new one.\n- In multi-expand mode, allow any number of sections to be open simultaneously.\n- Initialize open sections from the expanded attribute present on Section elements at first render.\n- Dispatch a toggle custom event (bubbling, composed) with index, title, and expanded when a section is toggled.\n- Allow moving keyboard focus between section headers using ArrowDown and ArrowUp keys, skipping disabled headers.\n- Activate a focused header with Enter or Space.\n- Render an optional Label slot above the accordion panels.\n- Display a loading skeleton with an animated pulse when the loading property is true.\n- Show an empty-state message when no Section slots are provided.\n- Apply disabled styling and block interaction on individual sections that carry the disabled attribute.\n- Block all interaction when the component-level disabled or loading property is true.\n\n# Constraints\n- A section must not open or close while the component-level disabled or loading state is active.\n- A per-section disabled header must receive tabindex=\"-1\" and must not be reachable or togglable.\n- In single-expand mode, at most one section may be open at any time.\n- Keyboard navigation must skip disabled headers and wrap around the list.\n- The component must not contain business logic; it only manages visual expand/collapse state.\n- Section content is rendered via unsafeHTML from the Section slot's inner template or innerHTML and must not be sanitized by this component.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-accordion" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlAccordionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private findNextEnabledHeader;
        private getSectionContent;
        private getHeaderClasses;
        private getContentClasses;
        private getChevronClasses;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private renderSection;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-collapsible-panel\n\n# Objective\nA stacked collapsible panel: each Section has a title, optional subtitle and icon, and expandable HTML content. Supports single or multiple open sections, per-section expanded/disabled flags, keyboard control and a loading skeleton.\n\n# Responsibilities\n- Parse Section slots; open initially-expanded sections; toggle on header click/Enter/Space.\n- Enforce single vs multiple open mode; support ArrowUp/Down to move focus between headers.\n- Dispatch toggle with { index, title, expanded }; animate content height/opacity.\n\n# Constraints\n- No toggling while disabled or loading; disabled sections cannot open.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Frosted stacked sections; open header highlighted in indigo. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlCollapsiblePanelMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleHeaderClick;
        private handleHeaderKeydown;
        private focusAdjacentHeader;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private getSectionContent;
        private getHeaderClasses;
        private getChevronClasses;
        private getContentClasses;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-reveal-overlay\n\n# Objective\nHide section content behind a frosted overlay with a reveal action, expanding to show the content when activated. Supports multiple or single reveal, per-section disabled state, an optional warning label, and loading state.\n\n# Responsibilities\n- Render each Section slot with its content covered by an overlay until revealed.\n- Toggle a section open/closed when its header or the reveal button is activated; dispatch a toggle event (index, title, expanded).\n- In single mode, revealing a section hides any previously revealed section.\n- Initialize revealed sections from the expanded attribute at first render.\n- Support keyboard activation (Enter/Space) and ArrowUp/ArrowDown navigation between headers.\n- Render an optional Label slot as a warning note above each section.\n- Apply disabled appearance and block interaction for the whole component or individual sections.\n- Render a loading placeholder when loading is true.\n\n# Constraints\n- A disabled component or section must not toggle.\n- Section content is rendered via unsafeHTML and must not be sanitized here.\n- The component must not contain business logic; it only manages reveal state and appearance.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). The overlay uses backdrop-filter to frost the content until revealed. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class RevealOverlayMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private renderLoading;
        private getHeaderClasses;
        private getContainerClasses;
        private getOverlayClasses;
        private getActionButtonClasses;
        private renderSectionContent;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatemain/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class GroupNavigateMainIndex extends StateLitElement {
        private active;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav.defs" {
    export const group = "groupNavigateMain";
    export const skill = "# Metadata\n- TagName: groupnavigatemain--ml-sidebar-nav\n\n# Objective\nA primary application sidebar navigation listing items (with icons and badges), optionally organized in collapsible groups and a footer. Supports a collapsed (icon-only) mode, active item highlight, disabled items, and loading state.\n\n# Responsibilities\n- Render top-level Item slots, grouped Items inside Group slots (with collapsible group headers), and Footer Items.\n- Each item shows an icon (or initials fallback), label, and optional badge.\n- Track the active item via value; dispatch a change event (value, label, badge) when an enabled item is clicked.\n- Toggle a collapsed (icon-only) mode and dispatch a collapse event; show tooltips and a badge dot when collapsed.\n- Collapse/expand individual groups.\n- Show a loading skeleton; apply disabled appearance and block interaction for disabled items or the whole component.\n\n# Constraints\n- Disabled items do not trigger change events.\n- The component must not contain business logic; slot content/icons are rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). The sidebar surface and items are translucent glass; active item uses an indigo tint. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlSidebarNavMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        collapsed: boolean;
        disabled: boolean;
        loading: boolean;
        private collapsedGroups;
        private parseItem;
        private parseTopItems;
        private parseGroups;
        private parseFooterItems;
        private handleItemClick;
        private handleToggleCollapse;
        private handleToggleGroup;
        private getItemClasses;
        private getIconClasses;
        private renderItemIcon;
        private renderNavItem;
        private renderGroup;
        private renderCollapseToggle;
        private renderLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    export class GroupNavigateSectionIndex extends StateLitElement {
        private tab;
        private pill;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-breadcrumb-trail\n\n# Objective\nA breadcrumb trail that shows the navigation path as a sequence of levels separated by delimiters. The last level is the current page (non-interactive); earlier levels are clickable. Collapses middle levels into an overflow menu on small screens, and shows the active level's content.\n\n# Responsibilities\n- Render each Tab slot as a breadcrumb level with optional icon and title, separated by a delimiter.\n- Treat the last level as the current page (non-clickable); make earlier, enabled levels clickable.\n- Dispatch a change event (value, title) when an earlier level is activated.\n- On small screens, collapse middle levels into an overflow (\"...\") menu.\n- Support keyboard navigation (ArrowLeft/ArrowRight, Enter/Space) across interactive levels.\n- Show the active level's content, plus loading and error states.\n\n# Constraints\n- The last level and disabled levels are not clickable.\n- No interaction while loading or disabled.\n- The component must not contain business logic; content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Levels are subtle translucent links; the overflow menu is a translucent popover. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class BreadcrumbTrailMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private isOverflowOpen;
        firstUpdated(): void;
        private getTabs;
        private getActiveValue;
        private getTabClasses;
        private getDelimiterClasses;
        private getOverflowButtonClasses;
        private getPanelClasses;
        private getLabelClasses;
        private getErrorClasses;
        private renderTab;
        private renderOverflowMenu;
        private renderTrail;
        private handleTabClick;
        private handleOverflowToggle;
        private handleKeyDown;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-navigate-pills\n\n# Objective\nA pill-style section navigation that lets the user switch between named tabs, showing the active tab's content below. Supports icons per tab, disabled tabs, loading and error states, and keyboard navigation.\n\n# Responsibilities\n- Render each Tab slot as a pill with optional icon and title; show the active tab's content in a panel.\n- Track the active tab via the value property; default to the first enabled tab.\n- Dispatch a change event (value, title) when a tab is activated.\n- Support keyboard navigation (ArrowLeft/ArrowRight to move focus, Enter/Space to activate), skipping disabled tabs.\n- Show disabled tabs as non-interactive; show a loading state and an error message when provided.\n\n# Constraints\n- Disabled tabs cannot be activated.\n- No interaction while loading or disabled.\n- The component must not contain business logic; tab content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Pills and panel are translucent glass. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class NavigatePillsMolecule extends MoleculeAuraElement {
        private msg;
        private instanceId;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private lastActiveIndex;
        private handleTabClick;
        private handleKeyDown;
        private focusTabButton;
        private dispatchChange;
        private getTabs;
        private getActiveIndex;
        private getTabClasses;
        private renderLabel;
        private renderLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-tabs.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-tabs\n\n# Objective\nA classic underlined tab navigation that switches between sections and shows the active tab's content. Supports per-tab icons, disabled tabs, loading, empty and error states, and keyboard navigation.\n\n# Responsibilities\n- Render each Tab slot as an underlined tab with optional icon and title; show the active tab's content in a panel.\n- Track the active tab via value; default to the first enabled tab.\n- Dispatch a change event (value, title) when a tab is activated (not when re-selecting the active one).\n- Support ArrowLeft/ArrowRight focus movement and Enter/Space activation, skipping disabled tabs (roving tabindex).\n- Show loading, empty and error states.\n\n# Constraints\n- Disabled tabs cannot be activated; no interaction while loading or disabled.\n- The component must not contain business logic; tab content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Active tab uses an accent underline; panel is translucent glass. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-tabs" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlTabsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private uid;
        private handleTabClick;
        private handleKeyDown;
        private parseTabs;
        private getActiveValue;
        private toSafeId;
        private getTabClasses;
        private getTabListClasses;
        private getPanelClasses;
        private renderLabel;
        private renderLoading;
        private renderError;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesteps/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    export class GroupNavigateStepsIndex extends StateLitElement {
        private step;
        private wiz;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-horizontal-stepper\n\n# Objective\nA horizontal step indicator showing progress through an ordered sequence. Each Step has a title, optional description, optional icon, and completed/disabled flags. The current step is value (index). Supports linear navigation, keyboard control and a loading state.\n\n# Responsibilities\n- Parse Step slots; mark steps before value (or flagged completed) as completed and value as active.\n- Allow click/keyboard navigation respecting linear mode (only up to value+1) and disabled steps.\n- Dispatch change with { value, title } on navigation; render connectors between steps.\n\n# Constraints\n- In linear mode the user cannot skip ahead beyond the next step; disabled steps are not navigable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Glass circular indicators; active is indigo, completed is emerald. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlHorizontalStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private focusedIndex;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private getSteps;
        private getLabelText;
        private isStepCompleted;
        private canNavigateTo;
        private getNextFocusableIndex;
        private handleStepClick;
        private handleKeyDown;
        private handleFocus;
        private getIndicatorClasses;
        private getTitleClasses;
        private getDescriptionClasses;
        private getContainerClasses;
        private renderLoading;
        private renderStep;
        private renderConnector;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-wizard-steps\n\n# Objective\nA wizard step navigator rendering each step as a card with an index/check indicator, title and optional description. The current step is value (index). Supports linear navigation rules, keyboard control and a loading state.\n\n# Responsibilities\n- Parse Step slots (title/description/completed/disabled); highlight the active and completed steps.\n- Enforce linear navigation (can only reach the next step when the current is completed) and skip disabled steps.\n- Dispatch change with { value, title } on navigation; support arrow/Enter/Space keyboard control.\n\n# Constraints\n- In linear mode forward navigation requires the current step to be completed; disabled steps are not navigable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Frosted step cards; active is indigo, completed is emerald. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlWizardStepsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private focusedIndex;
        private handleStepClick;
        private handleContainerKeyDown;
        private parseSteps;
        private canNavigateTo;
        private getInitialFocusIndex;
        private findNextFocusableIndex;
        private getStepClasses;
        private getLabelText;
        private renderLoading;
        private renderLabel;
        private renderStep;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GroupNotifyUserIndex extends StateLitElement {
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-alert-modal.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-alert-modal\n\n# Objective\nDisplay a centered modal alert dialog over a dimmed overlay to communicate an important status to the user and optionally request an action. Supports four semantic types (info, success, warning, error), optional title, custom icon, action area, dismiss button, timed auto-dismiss, and configurable position.\n\n# Responsibilities\n- Render nothing when visible is false; render the overlay and dialog when visible is true.\n- Apply type-specific accent and icon (info, success, warning, error); normalize \"danger\" to \"error\".\n- Render a custom icon from the Icon slot when provided; otherwise render the default type icon.\n- Render an optional Title slot and the Message slot (with fallback text when absent).\n- Render an optional Action slot and dispatch an action custom event (bubbling, composed) when clicked.\n- Render a dismiss button when dismissible is true; clicking it sets visible to false and dispatches a dismiss event.\n- Start an auto-dismiss timer when visible and duration > 0; cancel it when visible becomes false or duration is 0.\n- Position the dialog according to the position property (center, top, bottom, and corners).\n- Set role/aria-live according to type and mark the dialog as aria-modal.\n\n# Constraints\n- The dialog must render no DOM output while visible is false.\n- The dismiss button must not appear unless dismissible is true.\n- Only one auto-dismiss timer may be active at a time.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). The scrim uses backdrop-filter to blur the page behind it and the dialog is a translucent glass panel. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-alert-modal" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlAlertModalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: string;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: string;
        private autoDismissId;
        handleIcaStateChange(key: string): void;
        updated(changedProps: Map<string, unknown>): void;
        private manageAutoDismiss;
        private clearAutoDismiss;
        private handleDismiss;
        private handleActionClick;
        private getNormalizedType;
        private getRole;
        private getAriaLive;
        private getPositionClasses;
        private getContainerClasses;
        private getIconWrapperClasses;
        private renderDefaultIcon;
        private renderIcon;
        private renderTitle;
        private renderMessage;
        private renderActions;
        private renderDismiss;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-notify-banner.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-notify-banner\n\n# Objective\nDisplay a contextual inline or floating notification banner that communicates a status message to the user. The banner supports four semantic types (info, success, warning, error), an optional title, an optional action link, an optional custom icon, a dismiss button, automatic timed dismissal, and configurable screen positioning.\n\n# Responsibilities\n- Render the banner only when the visible property is true; render nothing when visible is false.\n- Apply type-specific colors and a default icon matching the type (info, success, warning, error).\n- Render a custom icon from the Icon slot when provided, replacing the default icon.\n- Render an optional Title slot as a bold heading above the message.\n- Render the Message slot content as the notification body; show a fallback warning text when the Message slot is absent.\n- Render an optional Action slot as a clickable inline element and dispatch an action custom event (bubbling, composed) when it is clicked.\n- Render a dismiss button when the dismissible property is true; clicking it sets visible to false and dispatches a dismiss custom event (bubbling, composed).\n- Start an auto-dismiss timer when both visible is true and duration is greater than zero; cancel the timer when visible becomes false or duration changes to zero.\n- Cancel the auto-dismiss timer when the component is disconnected from the DOM.\n- Apply fixed-position placement classes derived from the position property (top-right, top-left, bottom-right, bottom-left, top, bottom); use relative positioning when position is empty.\n- Set role=\"alert\" and aria-live=\"assertive\" for error type; set role=\"status\" and aria-live=\"polite\" for all other types.\n\n# Constraints\n- The banner must render no DOM output while visible is false.\n- The dismiss button must not appear unless dismissible is true.\n- Auto-dismiss must not fire if visible has already been set to false before the timer expires.\n- The component must not contain business logic; it only manages notification visibility and appearance.\n- Slot content (Title, Message, Action, Icon) is rendered via unsafeHTML and must not be sanitized by this component.\n- Only one auto-dismiss timer may be active at a time; a new timer must cancel the previous one.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the banner is a translucent panel tinted by type. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-notify-banner" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class NotifyBannerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: 'info' | 'success' | 'warning' | 'error' | string;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: string;
        private dismissTimer;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private startAutoDismiss;
        private clearAutoDismiss;
        private handleDismiss;
        private handleActionClick;
        private getRole;
        private getAriaLive;
        private getPositionClasses;
        private getContainerClasses;
        private renderDefaultIcon;
        private renderIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderDismissButton;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-toast-notification.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-toast-notification\n\n# Objective\nDisplay a transient toast notification that appears at a configurable screen position to communicate a short status message, with four semantic types (info, success, warning, error), optional title, action, and custom icon, a dismiss button, and automatic timed dismissal with enter/exit animation.\n\n# Responsibilities\n- Render the toast only when visible is true (or while animating out); render nothing otherwise.\n- Apply type-specific colors and a default icon matching the type.\n- Render optional Title, Message, Action and Icon slots; dispatch an action event when the Action area is clicked.\n- Render a dismiss button when dismissible is true; dismissing animates out, sets visible to false and dispatches a dismiss event.\n- Start an auto-close timer when visible and duration > 0; cancel it when visible becomes false or duration changes; clear on disconnect.\n- Apply fixed-position placement classes from the position property (top, bottom and corners) and enter/exit animation classes.\n- Set role/aria-live according to type.\n\n# Constraints\n- The toast must render no DOM output while not visible and not animating out.\n- The dismiss button must not appear unless dismissible is true.\n- Only one auto-close timer may be active at a time.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the toast is a translucent panel tinted by type. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-toast-notification" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    type NotificationType = 'info' | 'success' | 'warning' | 'error';
    type PositionType = 'top' | 'bottom' | 'top-right' | 'bottom-right' | 'top-left' | 'bottom-left';
    export class ToastNotificationMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: NotificationType;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: PositionType | '';
        private isAnimatingOut;
        private autoCloseTimer;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private startAutoCloseTimer;
        private clearAutoCloseTimer;
        private handleDismiss;
        private handleActionClick;
        private getContainerClasses;
        private getPositionClasses;
        private getAnimationClasses;
        private getEntryAnimationClass;
        private getExitAnimationClass;
        private getAriaRole;
        private getAriaLive;
        private renderIcon;
        private renderDefaultIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderCloseButton;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouprateitem/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    export class GroupRateItemIndex extends StateLitElement {
        private stars;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-emoji-mood-scale\n\n# Objective\nA mood/sentiment scale where each option is an emoji (or custom Item). The user picks a single value from min..max by step, or from explicit Item slots. Supports hover preview, keyboard navigation, validation, disabled/readonly and a read-only view.\n\n# Responsibilities\n- Build options from Item slots or min/max/step and render them as a radiogroup.\n- Handle click/hover/keyboard selection; dispatch change/focus/blur with { value }.\n- Render label, helper or error, and a read-only summary of the chosen option.\n\n# Constraints\n- No selection while disabled or readonly; required with no value shows a validation message.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Frosted emoji buttons; selected/hover highlighted in indigo. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class EmojiMoodScaleMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private focusedIndex;
        private handleOptionClick;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleMouseEnter;
        private handleMouseLeave;
        private handleKeydown;
        private focusItem;
        private getSelectedIndex;
        private getItems;
        private getActiveValue;
        private getHasError;
        private getErrorMessage;
        private renderLabel;
        private renderHelperOrError;
        private getContainerClasses;
        private getOptionClasses;
        private renderOption;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouprateitem/ml-star-rating.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-star-rating\n\n# Objective\nA star (or custom Item) rating control. The user picks a value from min..max by step, or from explicit Item slots. Supports hover preview, keyboard navigation, validation, disabled/readonly and a read-only view.\n\n# Responsibilities\n- Build rating options from Item slots or from min/max/step; highlight items up to the active value.\n- Handle click/hover/keyboard selection as a radiogroup and dispatch change/focus/blur with { value }.\n- Render label, helper or error, a hidden input for forms, and a read-only summary.\n\n# Constraints\n- No selection while disabled or readonly; required with no value marks the group invalid.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent container; active stars glow gold. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/grouprateitem/ml-star-rating" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlStarRatingMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private uid;
        private handleOptionClick;
        private handleOptionMouseEnter;
        private handleOptionMouseLeave;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleOptionKeydown;
        private focusOption;
        private getRatingItems;
        private getActiveValue;
        private isItemActive;
        private getLabelId;
        private getHelpId;
        private getIsInvalid;
        private renderLabel;
        private renderHelperOrError;
        private renderHiddenInput;
        private renderStarIcon;
        private renderOption;
        private renderEditMode;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupsearchcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar';
    export class GroupSearchContentIndex extends StateLitElement {
        private query;
        private lastSearch;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupsearchcontent/ml-search-bar.defs" {
    export const group = "groupSearchContent";
    export const skill = "# Metadata\n- TagName: groupsearchcontent--ml-search-bar\n\n# Objective\nA search input with a leading icon, clearable text, debounced search events, and an optional suggestion dropdown with keyboard navigation. Supports validation, disabled and loading states.\n\n# Responsibilities\n- Track the query, debounce 'search' events, and dispatch 'change' on commit (Enter or suggestion click) and 'clear' when emptied.\n- Render suggestions from Suggestion slots; support ArrowUp/Down/Enter/Escape and mouse selection.\n- Show loading and empty states inside the suggestion panel; show label, helper or error.\n\n# Constraints\n- No interaction while disabled.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent input with icon; suggestion panel uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupsearchcontent/ml-search-bar" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlSearchBarMolecule extends MoleculeAuraElement {
        private msg;
        private debounceTimer;
        private componentId;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        debounce: number;
        disabled: boolean;
        loading: boolean;
        private query;
        private isOpen;
        private highlightIndex;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private handleClearClick;
        private handleSuggestionClick;
        private scheduleSearch;
        private confirmQuery;
        private confirmSuggestion;
        private getSuggestions;
        private getInputClasses;
        private getPanelClasses;
        private getSuggestionClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderSuggestions;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectfileforupload/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class GroupSelectFileForUploadIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-file-upload-dropzone\n\n# Objective\nA drag-and-drop (and click-to-browse) file selection zone. Holds the selected File[] in value, validates by type/size/count, lists selected files with remove buttons, and supports single or multiple selection.\n\n# Responsibilities\n- Open the native file picker on click/Enter/Space; accept files via drag-and-drop with a dragging highlight.\n- Validate files against accept, max-size-kb and max-files; dispatch 'reject' with the rejected files and reason.\n- Update value with valid files (replace in single mode, append in multiple mode) and allow removing files.\n- Render label, helper or error, loading state and the selected-file list.\n\n# Constraints\n- No interaction while disabled or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent dashed dropzone and frosted file cards. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlFileUploadDropzoneMolecule extends MoleculeAuraElement {
        private msg;
        private inputId;
        private labelId;
        private errorId;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private handleZoneClick;
        private handleZoneKeydown;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleInputChange;
        private handleRemoveFile;
        private processFiles;
        private validateFiles;
        private getAvailableSlots;
        private isFileTypeAccepted;
        private formatFileSize;
        private getInputElement;
        render(): any;
        private renderTriggerContent;
        private renderFileList;
    }
}
declare module "_102054_/l2/molecules/groupselectmany/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select';
    export class GroupSelectManyIndex extends StateLitElement {
        private skills;
        private langs;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-multi-select-dropdown\n\n# Objective\nProvide a multi-select field that allows users to choose one or more options from a dropdown list. The field supports grouped options, search filtering, selection limits, and validation states, adapting its behavior between editing and viewing modes.\n\n# Responsibilities\n- Display a label to identify the field\n- Present a trigger area that shows selected items, a selection count, or placeholder text when no items are chosen\n- Toggle the dropdown panel open and closed when the user activates the trigger\n- Keep the panel open while the user selects or deselects options\n- List all available options in the dropdown panel, organized under group headers when grouping is configured\n- Allow the user to select and deselect multiple options independently\n- Provide a search input to filter the visible option list by label when search is enabled\n- Show a loading indicator and prevent panel opening while loading\n- Prevent all interaction and selection changes when disabled or readonly\n- Render selected option labels as static non-interactive content when not in editing mode\n- Notify the system when the selection value changes\n- Notify the system when the field gains or loses focus during editing\n- Enforce a minimum number of selected items by showing an error when the count is too low\n- Enforce a maximum number of selected items by preventing additional selections and treating unselected options as non-selectable when the limit is reached\n- Display individual options that are marked as non-selectable in a disabled state\n- Show helper text below the field when no error exists and the field is in editing mode\n- Show error messages below the field when validation fails or an error is explicitly set\n- Display empty state content when no options are available to show\n\n# Constraints\n- The current selection must be represented as a comma-separated list of option values; an empty string indicates no selection\n- The dropdown panel must close when the user presses Escape or clicks outside the component boundaries\n- The trigger must not activate and the panel must not open when the component is disabled, readonly, or loading\n- Options marked as disabled must be visible but cannot be selected or toggled\n- When a maximum selection limit is active and reached, unselected options must behave as disabled\n- An error state must appear when the field is required and no options are selected\n- An error state must appear when the number of selected items is below the configured minimum\n- Error messaging takes priority over helper text display\n- No trigger, dropdown panel, events, or validation messaging may be presented when the component is not in editing mode\n\n# Notes\n- The component uses named content regions: Label, Helper, Trigger, Item, Group, and Empty\n- Each option carries a value identifier and can be marked as non-selectable\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the panel is a translucent popover (base 0.85 for readability). Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MultiSelectDropdownMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private uid;
        private labelId;
        private helperId;
        private errorId;
        private panelId;
        private hasFocus;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handlePanelKeydown;
        private handleSearchInput;
        private handleOptionClick;
        private handleFocusIn;
        private handleFocusOut;
        private handleDocumentClick;
        private toggleSelection;
        private toggleOpen;
        private closePanel;
        private registerOutsideClick;
        private unregisterOutsideClick;
        private focusSearchInput;
        private focusTrigger;
        private moveOptionFocus;
        private getSelectedValues;
        private parseItem;
        private getGroupedItems;
        private getUngroupedItems;
        private getAllItems;
        private renderLabel;
        private renderHelperOrError;
        private renderSelectedTags;
        private getTriggerClasses;
        private getPanelClasses;
        private getItemClasses;
        private renderOptionList;
        private renderTriggerContent;
        private getComputedError;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectmany/ml-popover-multi-select.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-popover-multi-select\n\n# Objective\nA multi-select control that opens a popover listbox. The value is a comma-separated string of selected values. Supports optional search, grouped options, min/max selection limits, validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Parse Item/Group slots, optionally filter by search, and toggle selection on click/keyboard.\n- Show selected items as chips in the trigger (with a +N overflow indicator).\n- Enforce max-selection (disabling unselected items when full) and compute min/required validation.\n- Dispatch change/focus/blur with { value } and support arrow/Enter/Space/Escape keyboard navigation.\n\n# Constraints\n- No changes while disabled, readonly or loading; disabled items cannot be toggled.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent trigger with frosted chips; popover panel uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupselectmany/ml-popover-multi-select" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlPopoverMultiSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private activeIndex;
        private labelId;
        private errorId;
        private panelId;
        private hasFocus;
        updated(changed: Map<string, unknown>): void;
        private handleTriggerClick;
        private handleTriggerFocus;
        private handleTriggerBlur;
        private handleItemClick;
        private handleSearchInput;
        private handlePanelKeyDown;
        private handleDocumentClick;
        private handleDocumentKeyDown;
        private openPanel;
        private closePanel;
        private focusAfterOpen;
        private dispatchChangeEvent;
        private dispatchFocusEvent;
        private dispatchBlurIfNeeded;
        private parseValue;
        private collectSlotData;
        private createItemData;
        private filterData;
        private getSelectionState;
        private getValidationError;
        private getItemDisabled;
        private getSelectedLabelMap;
        private getVisibleItems;
        private setInitialActiveIndex;
        private moveActiveIndex;
        private toggleActiveItem;
        private focusActiveItem;
        private getTriggerClasses;
        private getItemClasses;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderSelectedTag;
        private renderTriggerContent;
        private renderEmpty;
        private renderGroup;
        private renderItems;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102054_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102054_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox';
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector';
    export class GroupSelectOneIndex extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-card-selector.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-card-selector\n\n# Objective\nA single-select control that opens a popover panel with rich option cards (optionally grouped and searchable). The user picks one card. Supports validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Parse Item/Group slots into cards (HTML content preserved) and optionally filter by a search query.\n- Open/close a popover; support keyboard navigation (arrows/Enter/Escape) and outside-click close.\n- Mark the selected card and dispatch change/focus/blur with { value }.\n- Render label, helper or error, loading state and empty state.\n\n# Constraints\n- No selection while disabled or readonly; disabled cards cannot be chosen.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent trigger; popover panel uses rgba(30,27,75,0.85) + blur(18px); cards are frosted. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupselectone/ml-card-selector" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlCardSelectorMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private focusedIndex;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        constructor();
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private getFilteredItems;
        private findItem;
        private getSelectableItems;
        private handleOutsideClick;
        private handleKeydown;
        private handleTriggerClick;
        private handleSelect;
        private handleSearchInput;
        private handleFocus;
        private handleBlur;
        private openPanel;
        private closePanel;
        private getTriggerClasses;
        private getPanelClasses;
        private getCardClasses;
        private getSearchInputClasses;
        private getGroupLabelClasses;
        private renderLabel;
        private renderTrigger;
        private renderSearch;
        private renderCard;
        private renderCardGrid;
        private renderEmpty;
        private renderPanel;
        private renderHelper;
        private renderError;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-combobox.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-combobox\n\n# Objective\nA single-select combobox with type-to-filter, keyboard navigation, optional grouped options, optional free-text entry, and an optional clear button. Supports validation, disabled/readonly/loading and a read-only view.\n\n# Responsibilities\n- Parse Item/Group slots into options and filter them by the typed query.\n- Open a popover listbox; support ArrowUp/Down/Enter/Escape/Tab and mouse selection.\n- Accept free text as the value when free-text is enabled; clear the value via the clear button.\n- Dispatch input/change/focus/blur with { value } and keep a hidden input in sync for forms.\n\n# Constraints\n- No selection while disabled, readonly or loading; disabled items are skipped.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent input; the popover panel uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupselectone/ml-combobox" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlComboboxMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        placeholder: string;
        name: string;
        error: string;
        /** When true, any typed text is accepted as the value (not just list items). */
        freeText: boolean;
        /** Show a clear (×) button when the field has a value. */
        clearable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private inputText;
        private isOpen;
        private activeIndex;
        private uid;
        private lastValueSynced;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _boundDocClick;
        firstUpdated(): void;
        updated(changedProps: Map<string, unknown>): void;
        private toPlainText;
        private parseItems;
        private getAllItems;
        private filterItems;
        private syncInputFromValue;
        private getFlatVisible;
        private getNextEnabledIndex;
        private handleInputFocus;
        private handleInputInput;
        private handleInputBlur;
        private handleKeyDown;
        private selectItem;
        private commitFreeText;
        private closeAndResolve;
        private handleClear;
        private getInputClasses;
        private getOptionClasses;
        private renderCheckmark;
        private renderOption;
        private renderDropdown;
        private renderLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-radio-group.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-radio-group\n\n# Objective\nA single-selection option group that displays all available choices at once without hiding them behind a dropdown. It allows the user to pick exactly one option from a small set, making every option visible for quick comparison and selection.\n\n# Responsibilities\n- Present all options simultaneously in a visible list; never hide options behind a dropdown or collapsible panel.\n- Provide distinct areas for Label, Helper, Item, Group, and Empty content. Each Item represents one selectable option and shows its label text.\n- When the user chooses an enabled Item, set the value to that Item's value and indicate that the value has changed.\n- Show disabled Items as visible but unavailable for selection; they cannot change the current value.\n- Block selection changes and suppress change indications while readonly is active.\n- Block selection changes and appear fully inactive while disabled is active.\n- Display an error appearance and indicate invalidity when an error message is present; otherwise show helper text if available.\n- When required is true and no value exists, display an error appearance until a selection is made.\n- Display a loading appearance that prevents selection changes while loading is active.\n- In view mode, render only the selected option's label as static text, or a placeholder when nothing is selected. Hide all interactive controls, error indicators, and helper text.\n- Allow moving focus between options with arrow keys, confirm the focused option with Enter, and report when focus enters or leaves. Escape must not change the selection and may remove focus.\n- When a Group area is present, render its label and include its Items as a labeled subsection while enforcing single-selection across all options.\n- If no Items are provided, render the Empty area content if available.\n\n# Constraints\n- Only one option may be selected at any time, including across subgroups.\n- Selection changes are prohibited during loading, readonly, and disabled states.\n- Disabled options must remain visible and clearly distinguishable from enabled options.\n- Error appearance persists until a valid selection is made when required; provided error messages override helper text.\n- View mode must not expose interactive controls or validation feedback.\n- The component must remain readable and usable when presenting 2 to 6 items at once.\n\n# Notes\n- Designed for small option sets where immediate visibility of all choices improves decision speed.\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; options are translucent glass cards. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupselectone/ml-radio-group" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlRadioGroupMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private focusedValue;
        private labelId;
        private errorId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private findItem;
        private getSelectableItems;
        private handleSelect;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private getContainerClasses;
        private getOptionClasses;
        private getRadioClasses;
        private getLabelTextClasses;
        private renderLabel;
        private renderRadioIndicator;
        private renderOption;
        private renderGroup;
        private renderRadioOptions;
        private renderLoading;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-segmented-control.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-segmented-control\n\n# Objective\nA single-selection control that presents multiple options as a connected horizontal group of segments. It allows choosing one option from a compact set, showing the selected label when inactive and displaying all options together when active for editing.\n\n# Responsibilities\n- Integrate with the groupSelectOne contract, supporting Label, Helper, Trigger, Item, Group, and Empty.\n- Render each Item as a selectable segment with a visible label and an associated value.\n- Maintain exactly one selected Item at a time; selecting an Item updates the current value and notifies the system of the change.\n- When not in editing mode, display only the label of the currently selected Item as static text. Do not render segments, error messages, helpers, or emit change notifications.\n- When not in editing mode and no Item is selected, display the configured placeholder or a default fallback if no placeholder is configured.\n- When in editing mode, present all Items simultaneously as a horizontal group without requiring any panel or dropdown to be opened.\n- Render disabled Items visibly but prevent their selection and suppress change notifications when they are activated.\n- Present an error state when the control is required and no value is selected, following the validation rules of the contract.\n- Display an error message and apply an error state when an error is present; otherwise display Helper content when available.\n- Indicate loading and block all interactions, preventing selection and focus.\n- Block all interactions and apply a disabled state to the entire control when disabled.\n- Prevent selection changes while maintaining visible selected content when readonly.\n- Render Empty content when no Items are present; if Empty is not provided, render an explicit empty state.\n- Notify when the control receives and loses focus according to the contract.\n- Support keyboard navigation between segments, confirmation of selection, and dismissal of any open state.\n\n# Constraints\n- Only one Item may be selected at any time.\n- All options must remain visible simultaneously during editing; they must not be hidden behind an additional interaction layer.\n- Disabled Items must never trigger selection or change notifications.\n- The control must not emit change notifications when not in editing mode.\n- Error display takes precedence over Helper display.\n- Loading state must prevent all user interactions including focus.\n- Designed for compact sets of short labels, typically between 2 and 5 options.\n\n# Notes\n- Trigger content serves as a placeholder only when no Item is selected.\n- The selected Item label always takes precedence over Trigger content when a value is present.\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the track is a translucent glass bar and the selected segment is a brighter frosted pill. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupselectone/ml-segmented-control" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class SegmentedControlMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private focusedIndex;
        private parsedItems;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseItems;
        private findItem;
        private handleSelect;
        private handleKeyDown;
        private focusNextItem;
        private focusPreviousItem;
        private focusSegment;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getSegmentClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
        private renderLabel;
        private renderLoading;
        private renderSegments;
        private renderSegment;
        private renderEmpty;
        private renderFeedback;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-select-dropdown.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-dropdown\n\n# Objective\nProvide a single-selection control that displays the current choice in a collapsed field and reveals a list of available options when activated. It must support searching, validation, and distinct display modes for editing and viewing.\n\n# Responsibilities\n- Display the currently selected option's label or a placeholder when no selection exists.\n- Reveal a list of available options when the user activates the control.\n- Hide the list when the user selects an option, activates an area outside the control, or cancels the operation.\n- Update the stored selection to the chosen option's value and report that a change has occurred.\n- Show a waiting indication and block list opening while data is being loaded.\n- Render the current selection as plain text without interactive elements when in view mode.\n- Block interaction but allow text selection when in read-only mode.\n- Display a validation failure when a selection is required but none is present, and clear it once a selection is made.\n- Provide a way to filter the option list by text when search is enabled.\n- Keep unavailable options visible but prevent their selection.\n- Use each option's displayed text as the source for its label, separate from its stored value.\n\n# Constraints\n- The option list must remain closed while the control is in a loading state.\n- Unavailable options must not be selectable and must not trigger change reporting.\n- Closing the list without choosing an option must preserve the existing selection and must not report a change.\n- The control must not respond to user input when disabled.\n- The control must not report changes when in view mode.\n- The label shown for the selected option must always correspond to the chosen option's displayed text.\n- A required but missing selection must keep the control in an error state until a valid choice is made.\n- Filtering must compare the search text against option labels.\n\n# Notes\n- Follows the groupSelectOne contract for single-selection patterns.\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the dropdown is a translucent popover with backdrop-filter. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupselectone/ml-select-dropdown" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlSelectDropdownMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private focusedIndex;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        constructor();
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private findItem;
        private getFilteredItems;
        private getSelectableItems;
        private handleTriggerClick;
        private handleSelect;
        private handleOutsideClick;
        private handleKeydown;
        private handleSearchInput;
        private getTriggerClasses;
        private getDropdownClasses;
        private getItemClasses;
        private getSearchInputClasses;
        private renderLabel;
        private renderTriggerContent;
        private renderChevron;
        private renderTrigger;
        private renderSearchInput;
        private renderItems;
        private renderEmpty;
        private renderDropdown;
        private renderHelper;
        private renderError;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupshowprogress/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress';
    export class GroupShowProgressIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupshowprogress/ml-circular-progress.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-circular-progress\n\n# Objective\nA circular (ring) progress indicator. Shows determinate progress (0\u2013100) via stroke offset or an indeterminate spinning arc when value is null. Supports size (xs/sm/md/lg), an optional centered percentage and an aria label.\n\n# Responsibilities\n- Compute the SVG circle dash offset from the clamped value; spin the arc when indeterminate.\n- Apply size classes and optionally render the rounded percentage in the center.\n- Expose progressbar ARIA attributes when determinate.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent ring track with a glowing arc. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupshowprogress/ml-circular-progress" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class CircularProgressMolecule extends MoleculeAuraElement {
        slotTags: any[];
        value: number | null;
        size: string;
        label: string;
        showValue: boolean;
        render(): any;
        private renderSvg;
        private isDeterminate;
        private getClampedValue;
        private getAriaAttributes;
        private getWrapperClasses;
        private getSvgClasses;
        private getValueTextClasses;
        private getSizeClasses;
        private getResolvedSize;
    }
}
declare module "_102054_/l2/molecules/groupshowprogress/ml-linear-progress.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-linear-progress\n\n# Objective\nA horizontal progress bar. Shows determinate progress (0\u2013100) or an indeterminate animation when value is null. Supports size (xs/sm/md/lg), semantic variant (default/success/warning/danger), an optional percentage readout and an aria label.\n\n# Responsibilities\n- Clamp value to 0\u2013100 and render the fill width; animate when indeterminate.\n- Apply size and variant styling; optionally show the rounded percentage.\n- Expose progressbar ARIA attributes (valuemin/max/now) or omit them when indeterminate.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent track with a luminous gradient fill. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupshowprogress/ml-linear-progress" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class LinearProgressMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: number | null;
        size: 'xs' | 'sm' | 'md' | 'lg';
        label: string;
        showValue: boolean;
        variant: 'default' | 'success' | 'warning' | 'danger';
        private getNormalizedValue;
        private getSizeClasses;
        private getTextSizeClasses;
        private getTrackClasses;
        private getFillClasses;
        private renderValueText;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GroupTriggerActionIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-button-standard.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard\n\n# Objective\nA standard button molecule for the groupTriggerAction group that triggers actions when activated. It supports text labels, icons, multiple sizes, visual styles, loading states with a spinner indicator, and disabled states. Designed for corporate interfaces such as ERP, CRM, HR, Financial, and Logistics systems.\n\n# Responsibilities\n- Display a text label and/or an icon provided through the designated Label and Icon content areas.\n- Arrange the icon either before or after the text label based on configuration.\n- Adjust overall dimensions and icon scale according to the selected size.\n- Behave as a standard button, a submit button, or a reset button based on configuration.\n- Ignore activation attempts and present a disabled state when configured as disabled.\n- Ignore activation attempts and present a busy state when configured as loading.\n- Show a loading spinner in place of the icon or text during loading, keeping the button size unchanged.\n- Trigger an action event when activated by pointer or keyboard (Enter or Space), unless disabled or loading.\n- Expose an accessible name for icon-only buttons using the Label content when available.\n- Support rich content within the Label and Icon areas.\n- Provide distinct visual feedback for Normal, Hover, Active, and Focused states, with a visible focus indicator for keyboard users.\n- Reduce opacity and remove interactive feedback when disabled.\n- Support visual variations for primary, secondary, danger, ghost, and link styles through theming.\n\n# Constraints\n- Must compose content using only the Label and Icon areas.\n- Icon position must be either 'start' or 'end'.\n- Size must be one of 'xs', 'sm', 'md', or 'lg'.\n- Type must be one of 'button', 'submit', or 'reset'.\n- When disabled, the action event must not trigger.\n- When loading, the action event must not trigger, and the button must expose busy and disabled states for accessibility.\n- During loading, the spinner replaces the icon if present; otherwise, it replaces the text label.\n- The action event must contain no detail and must propagate normally.\n- For icon-only buttons, the accessible name must come from the Label content if provided; otherwise, it must be empty.\n- Visual style variations must not require additional configuration properties.\n\n# Notes\n- Designed for corporate contexts such as ERP forms, CRM proposals, HR approvals, financial payments, and logistics operations.\n- The button must preserve its dimensions during loading to prevent layout shifts.\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-button-standard" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class ButtonStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private isDisabled;
        private getVariant;
        private getSizeKey;
        private getSizeClasses;
        private getButtonClasses;
        private getIconClasses;
        private renderSpinner;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-icon-button.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-icon-button\n\n# Objective\nAn icon-only button that triggers an action. It shows an icon (custom or default), supports multiple sizes, disabled and loading states, and exposes an accessible label derived from the Label slot for assistive technologies.\n\n# Responsibilities\n- Render an icon-only button using the Icon slot, or a default icon when none is provided.\n- Expose an accessible name from the Label slot (stripped of markup); fall back to a default label.\n- Adjust size according to the size property (xs, sm, md, lg).\n- Behave as button, submit, or reset based on type.\n- Show a spinner and busy state during loading; block activation while loading or disabled.\n- Dispatch an action event (bubbling, composed) when activated, unless disabled or loading.\n\n# Constraints\n- The visible content is icon-only; the label exists for accessibility (sr-only).\n- The action event must not fire while disabled or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the button is a translucent glass square. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-icon-button" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class IconButtonMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        render(): any;
        private renderIcon;
        private renderLoadingIcon;
        private getAccessibleLabel;
        private getButtonClasses;
        private getIconClasses;
        private getSizeClasses;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-split-button.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-split-button\n\n# Objective\nA split button combining a primary action with a dropdown of secondary actions. The main button triggers the default action; the chevron opens a menu of additional options. Supports sizes, icon, disabled and loading states.\n\n# Responsibilities\n- Render a primary button (Label + optional Icon) and a chevron button that toggles a secondary menu.\n- Collect secondary options from child elements that carry a value attribute; hide them from normal flow.\n- Dispatch an action event (bubbling, composed) with the chosen value: the primary value for the main button, or the option value from the menu.\n- Close the menu after an option is selected.\n- Support sizes (xs, sm, md, lg), icon position (start/end), button/submit/reset types.\n- Show a spinner and busy state while loading; block activation while loading or disabled.\n- Expose an accessible label for the primary action and a \"more options\" label for the chevron.\n\n# Constraints\n- Only child elements with a value attribute become menu options.\n- Disabled options must not trigger actions.\n- Action events must not fire while disabled or loading.\n- The component must not contain business logic; slot/option content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Appearance lives in the scoped .less; the buttons are translucent glass and the menu is a translucent popover. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-split-button" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlSplitButtonMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private handlePrimaryClick;
        private handleToggleMenu;
        private handleOptionClick;
        private getPrimaryValue;
        private getPrimaryLabelText;
        private collectSecondaryItems;
        private getAriaLabel;
        private getPrimaryClasses;
        private getChevronClasses;
        private getSizeClasses;
        private getOptionClasses;
        private renderIcon;
        private renderLabel;
        private renderSpinner;
        private renderChevron;
        private renderMenuOptions;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupviewcard/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class GroupViewCardIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupviewcard/ml-profile-card.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-profile-card\n\n# Objective\nA profile/content card that groups related information into header, content, footer and action regions. Supports clickable, selected, disabled and loading states, and an editing mode that propagates to nested molecules.\n\n# Responsibilities\n- Render content from named regions: CardHeader, CardTitle, CardDescription, CardContent, CardFooter, CardAction.\n- When clickable and enabled, behave as a button: dispatch a cardClick event on click or Enter/Space; expose role/tabindex.\n- Apply selected, disabled and loading appearances; show a loading skeleton when loading.\n- In editing mode, set is-editing on nested custom elements so child molecules switch to edit mode.\n\n# Constraints\n- cardClick must not fire while disabled or loading, or when not clickable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). The card is a translucent glass panel. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupviewcard/ml-profile-card" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlProfileCardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private handleCardClick;
        private handleCardKeydown;
        private isInteractive;
        private getCardClasses;
        private syncEditingAttribute;
        private renderHeader;
        private renderContent;
        private renderFooter;
        private renderAction;
        private renderLoadingSkeleton;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupviewcard/ml-vertical-card.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-vertical-card\n\n# Objective\nA vertically stacked content card with header, content, footer and a separated action region. Supports clickable, selected, disabled and loading states, and an editing mode that propagates to nested molecules.\n\n# Responsibilities\n- Render content from named regions: CardHeader, CardTitle, CardDescription, CardContent, CardFooter, CardAction, stacked vertically.\n- When clickable and enabled, behave as a button: dispatch a cardClick event on click or Enter/Space; expose role/tabindex.\n- Apply selected, disabled and loading appearances; show a loading skeleton when loading.\n- Separate the action region with a divider.\n- In editing mode, set is-editing on nested custom elements so child molecules switch to edit mode.\n\n# Constraints\n- cardClick must not fire while disabled or loading, or when not clickable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). The card is a translucent glass panel. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102054_/l2/molecules/groupviewcard/ml-vertical-card" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlVerticalCardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        updated(changed: Map<string, unknown>): void;
        private handleCardClick;
        private handleKeyDown;
        private isInteractive;
        private applyEditingAttribute;
        private getRootClasses;
        private renderHeader;
        private renderContent;
        private renderFooter;
        private renderAction;
        private renderLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupviewmetric/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number';
    export class GroupViewMetricIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupviewmetric/ml-metric-big-number.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-big-number\n\n# Objective\nA single prominent metric: an oversized value with an optional icon, label, trend (up/down/neutral) and helper line. Supports a loading skeleton.\n\n# Responsibilities\n- Render Label/Value/Icon/Trend/Helper slots, with the Value rendered at large size.\n- Color the trend by its direction attribute; expose an accessible figure label.\n- Show a skeleton while loading; render nothing if no Value is provided.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent surface with light text. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupviewmetric/ml-metric-big-number" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MlMetricBigNumberMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        render(): TemplateResult;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderLoadingSkeleton;
        private getContainerClasses;
        private getTrendClasses;
        private getTrendDirection;
        private getAriaLabel;
    }
}
declare module "_102054_/l2/molecules/groupviewmetric/ml-metric-card.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-card\n\n# Objective\nA compact KPI card showing a label, a large value, an optional icon, an optional trend badge (up/down/neutral) and an optional helper line. Supports a loading skeleton.\n\n# Responsibilities\n- Render Label/Value/Icon/Trend/Helper slots; color the trend badge by its direction attribute.\n- Show a skeleton placeholder while loading.\n- Expose an accessible figure label derived from the Label slot text.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102054). Translucent card with light text; trend badge uses semantic colors. Assumes a rich/dark background (container contract).";
}
declare module "_102054_/l2/molecules/groupviewmetric/ml-metric-card" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export class MetricCardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        private getBaseClasses;
        private getLabelClasses;
        private getValueClasses;
        private getHelperClasses;
        private getTrendClasses;
        private getAriaLabelFromHtml;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderSkeleton;
        render(): any;
    }
}
