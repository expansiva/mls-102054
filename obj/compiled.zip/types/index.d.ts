declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102054_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102054_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal';
    export class GroupEnterBooleanIndex extends StateLitElement {
        private notif;
        private news;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal" {
    import { ToggleSwitchMolecule } from '_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    export class ToggleSwitchBrutal extends ToggleSwitchMolecule {
        private gMsg;
        private gUid;
        private get internals();
        private brutalLabel;
        private brutalHelper;
        private brutalError;
        private brutalTrackClasses;
        private brutalThumbClasses;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenterdate/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterdate/ml-date-picker-brutal';
    export class GroupEnterDateIndex extends StateLitElement {
        private date;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterdate/ml-date-picker-brutal" {
    import { TemplateResult } from 'lit';
    import { MlDatePickerMolecule } from '_102040_/l2/molecules/groupenterdate/ml-date-picker';
    export class MlDatePickerBrutal extends MlDatePickerMolecule {
        protected portalClassName: string;
        private bMsg;
        private bFieldId;
        private get x();
        private fmtDate;
        private getTriggerText;
        private brutalTriggerClasses;
        private brutalDayClasses;
        private brutalLabel;
        private brutalHelperOrError;
        protected getPortalTemplate(): TemplateResult;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenterdatetime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal';
    export class GroupEnterDatetimeIndex extends StateLitElement {
        private dt;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal" {
    import { TemplateResult } from 'lit';
    import { MlDatetimePickerMolecule } from '_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    export class DatetimePickerBrutal extends MlDatetimePickerMolecule {
        protected portalClassName: string;
        private bMsg;
        private get x();
        private brutalFormatDisplay;
        private brutalTriggerClasses;
        private brutalLabelClasses;
        private brutalDayClasses;
        private brutalTimeClasses;
        private brutalLabel;
        private brutalHiddenInput;
        private brutalHelperOrError;
        private brutalTrigger;
        private brutalCalendar;
        private brutalTime;
        protected getPortalTemplate(): TemplateResult;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentermoney/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal';
    export class GroupEnterMoneyIndex extends StateLitElement {
        private price;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentermoney/ml-currency-input-brutal" {
    import { GroupEnterMoneyMlCurrencyInputMolecule } from '_102040_/l2/molecules/groupentermoney/ml-currency-input';
    export class CurrencyInputBrutal extends GroupEnterMoneyMlCurrencyInputMolecule {
        private gMsg;
        private gUid;
        private get x();
        private brutalInputClasses;
        private brutalContainerClasses;
        private brutalLabel;
        private brutalHelperOrError;
        private brutalInput;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenternumber/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal';
    import '/_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal';
    export class GroupEnterNumberIndex extends StateLitElement {
        private qty;
        private priceLow;
        private priceHigh;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupenternumber/ml-number-stepper-brutal" {
    import { NumberStepperMolecule } from '_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    export class NumberStepperBrutal extends NumberStepperMolecule {
        private gMsg;
        private gUid;
        private get gLabelId();
        private get gHelperId();
        private get gErrorId();
        private get gInputId();
        private get x();
        private brutalInputClasses;
        private brutalButtonClasses;
        private brutalContainerClasses;
        private brutalLabel;
        private brutalHelperOrError;
        private brutalPrefix;
        private brutalSuffix;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupenternumber/ml-range-slider-brutal" {
    import { RangeSliderMolecule } from '_102040_/l2/molecules/groupenternumber/ml-range-slider';
    export class RangeSliderBrutal extends RangeSliderMolecule {
        private gMsg;
        private gUid;
        private get gLabelId();
        private get gErrorId();
        private get gHelperId();
        private get x();
        private brutalInputClasses;
        private brutalLabel;
        private brutalPrefixSuffix;
        private brutalHelperOrError;
        private brutalLoading;
        private brutalEditMode;
        private brutalViewMode;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal';
    import '/_102054_/l2/molecules/groupentertext/ml-tag-input-brutal';
    export class GroupEnterTextIndex extends StateLitElement {
        private fullName;
        private password;
        private tags;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentertext/ml-floating-text-input-brutal" {
    import { MlFloatingTextInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    export class MlFloatingTextInputBrutal extends MlFloatingTextInputMolecule {
        private gUid;
        private get x();
        private brutalPrefix;
        private brutalSuffix;
        private brutalFeedback;
        private brutalInlineLabel;
        private brutalFloatingLabel;
        private brutalContainerClasses;
        private brutalInputClasses;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal" {
    import { PasswordStrengthInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    export class PasswordStrengthInputBrutal extends PasswordStrengthInputMolecule {
        private gMsg;
        private get x();
        private strengthLabel;
        private brutalContainerClasses;
        private brutalWrapperClasses;
        private brutalInputClasses;
        private brutalToggleClasses;
        private brutalBarClasses;
        private brutalTextClasses;
        private brutalCriteriaClasses;
        private brutalLabel;
        private brutalPrefix;
        private brutalSuffix;
        private brutalToggleButton;
        private brutalInput;
        private brutalStrengthIndicator;
        private brutalCriteriaItem;
        private brutalHelper;
        private brutalErrorMsg;
        private brutalLoading;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentertext/ml-tag-input-brutal" {
    import { MlTagInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-tag-input';
    export class MlTagInputBrutal extends MlTagInputMolecule {
        private gMsg;
        private get x();
        private brutalContainerClasses;
        private brutalInputClasses;
        private brutalRemoveClasses;
        private brutalLabel;
        private brutalPrefix;
        private brutalSuffix;
        private brutalTag;
        private brutalTags;
        private brutalInput;
        private brutalTextarea;
        private brutalEditMode;
        private brutalViewMode;
        private brutalHelper;
        private brutalLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupentertime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal';
    export class GroupEnterTimeIndex extends StateLitElement {
        private time;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupentertime/ml-clock-time-picker-brutal" {
    import { ClockTimePickerMolecule } from '_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class ClockTimePickerBrutal extends ClockTimePickerMolecule {
        private bMsg;
        private get x();
        private brutalFormatTime;
        private brutalStepLabel;
        private brutalInputClasses;
        private brutalOptionClasses;
        private brutalLabel;
        private brutalHelperOrError;
        private brutalClockOptions;
        private brutalAmPm;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal';
    import '/_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal';
    export class GroupExpandContentIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-accordion-brutal" {
    import { MlAccordionMolecule } from '_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    export class MlAccordionBrutal extends MlAccordionMolecule {
        private gMsg;
        private get x();
        private brutalHeaderClasses;
        private brutalContentClasses;
        private brutalChevronClasses;
        render(): any;
        private brutalLabel;
        private brutalLoading;
        private brutalSections;
        private brutalSection;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal" {
    import { MlCollapsiblePanelMolecule } from '_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    export class MlCollapsiblePanelBrutal extends MlCollapsiblePanelMolecule {
        private gMsg;
        private get x();
        render(): any;
        private brutalLabel;
        private brutalLoading;
        private brutalSections;
        private brutalHeaderClasses;
        private brutalChevronClasses;
        private brutalContentClasses;
    }
}
declare module "_102054_/l2/molecules/groupexpandcontent/ml-reveal-overlay-brutal" {
    import { RevealOverlayMolecule } from '_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    export class MlRevealOverlayBrutal extends RevealOverlayMolecule {
        private gMsg;
        private get x();
        private brutalHeaderClasses;
        private brutalContainerClasses;
        private brutalOverlayClasses;
        private brutalActionButtonClasses;
        private brutalRenderLoading;
        private brutalRenderSectionContent;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatemain/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal';
    export class GroupNavigateMainIndex extends StateLitElement {
        private navItem;
        private collapsed;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnavigatemain/ml-sidebar-nav-brutal" {
    import { MlSidebarNavMolecule } from '_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class MlSidebarNavBrutal extends MlSidebarNavMolecule {
        private gMsg;
        private get x();
        private brutalItemClasses;
        private brutalIconClasses;
        private brutalItemIcon;
        private brutalNavItem;
        private brutalGroup;
        private brutalCollapseToggle;
        private brutalLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal';
    import '/_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-brutal';
    export class GroupNavigateSectionIndex extends StateLitElement {
        private bc;
        private pill;
        private tab;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-brutal" {
    import { BreadcrumbTrailMolecule } from '_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    export class BreadcrumbTrailBrutal extends BreadcrumbTrailMolecule {
        private gMsg;
        private get x();
        private brutalTabClasses;
        private brutalDelimiterClasses;
        private brutalOverflowButtonClasses;
        private brutalPanelClasses;
        private brutalLabelClasses;
        private brutalErrorClasses;
        private brutalRenderTab;
        private brutalRenderOverflowMenu;
        private brutalRenderTrail;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal" {
    import { NavigatePillsMolecule } from '_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    export class NavigatePillsBrutal extends NavigatePillsMolecule {
        private gMsg;
        private get x();
        private brutalTabClasses;
        private brutalLabel;
        private brutalLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal" {
    import { MlTabsMolecule } from '_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class MlTabsBrutal extends MlTabsMolecule {
        private gMsg;
        private get x();
        private brutalTabClasses;
        private brutalTabListClasses;
        private brutalPanelClasses;
        private brutalLabel;
        private brutalLoading;
        private brutalError;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesteps/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal';
    import '/_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal';
    export class GroupNavigateStepsIndex extends StateLitElement {
        private stepperValue;
        private wizardValue;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal" {
    import { MlHorizontalStepperMolecule } from '_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    export class MlHorizontalStepperBrutal extends MlHorizontalStepperMolecule {
        private gMsg;
        private get x();
        private brutalIndicatorClasses;
        private brutalTitleClasses;
        private brutalDescriptionClasses;
        private brutalContainerClasses;
        private brutalLoading;
        private brutalStep;
        private brutalConnector;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnavigatesteps/ml-wizard-steps-brutal" {
    import { MlWizardStepsMolecule } from '_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    export class MlWizardStepsBrutal extends MlWizardStepsMolecule {
        private gMsg;
        private get x();
        private brutalLabelText;
        private brutalStepClasses;
        private brutalLoading;
        private brutalLabel;
        private brutalStep;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-notify-banner-brutal';
    import '/_102054_/l2/molecules/groupnotifyuser/ml-toast-notification-brutal';
    export class GroupNotifyUserIndex extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-alert-modal-brutal" {
    import { MlAlertModalMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    export class MlAlertModalBrutal extends MlAlertModalMolecule {
        private gMsg;
        private get x();
        private brutalHandleDismiss;
        private brutalHandleActionClick;
        private brutalContainerClasses;
        private brutalIconWrapperClasses;
        private brutalDefaultIcon;
        private brutalIcon;
        private brutalTitle;
        private brutalMessage;
        private brutalActions;
        private brutalDismiss;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-notify-banner-brutal" {
    import { NotifyBannerMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class MlNotifyBannerBrutal extends NotifyBannerMolecule {
        private gLocalMsg;
        private get x();
        private brutalDismiss;
        private brutalActionClick;
        private brutalContainerClasses;
        private brutalDefaultIcon;
        private brutalIcon;
        private brutalTitle;
        private brutalMessage;
        private brutalAction;
        private brutalDismissButton;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupnotifyuser/ml-toast-notification-brutal" {
    import { ToastNotificationMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class MlToastNotificationBrutal extends ToastNotificationMolecule {
        private gMsg;
        private get x();
        private gHandleDismiss;
        private gHandleActionClick;
        private brutalContainerClasses;
        private brutalPositionClasses;
        private brutalAriaRole;
        private brutalAriaLive;
        private brutalRenderIcon;
        private brutalRenderDefaultIcon;
        private brutalRenderTitle;
        private brutalRenderMessage;
        private brutalRenderAction;
        private brutalRenderCloseButton;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouprateitem/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouprateitem/ml-star-rating-brutal';
    import '/_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal';
    export class GroupRateItemIndex extends StateLitElement {
        private rating;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/grouprateitem/ml-emoji-mood-scale-brutal" {
    import { EmojiMoodScaleMolecule } from '_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    export class EmojiMoodScaleBrutal extends EmojiMoodScaleMolecule {
        private gMsg;
        private get internals();
        private brutalLabel;
        private brutalHelperOrError;
        private brutalContainerClasses;
        private brutalOptionClasses;
        private brutalOption;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouprateitem/ml-star-rating-brutal" {
    import { MlStarRatingMolecule } from '_102040_/l2/molecules/grouprateitem/ml-star-rating';
    export class StarRatingBrutal extends MlStarRatingMolecule {
        private get internals();
        private brutalLabel;
        private brutalHelperOrError;
        private brutalHiddenInput;
        private brutalStarIcon;
        private brutalOption;
        private brutalEditMode;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupsearchcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupsearchcontent/ml-search-bar-brutal';
    export class GroupSearchContentIndex extends StateLitElement {
        private query;
        private lastSearch;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupsearchcontent/ml-search-bar-brutal" {
    import { TemplateResult } from 'lit';
    import { MlSearchBarMolecule } from '_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    export class MlSearchBarBrutal extends MlSearchBarMolecule {
        protected portalClassName: string;
        private bMsg;
        private bComponentId;
        private portalContainer;
        private get x();
        private createPortal;
        private destroyPortal;
        private positionPortal;
        private renderPortal;
        disconnectedCallback(): void;
        private brutalInputClasses;
        private brutalSuggestionClasses;
        private brutalLabel;
        private brutalHelperOrError;
        protected getPortalTemplate(): TemplateResult;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectfileforupload/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal';
    export class GroupSelectFileForUploadIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-brutal" {
    import { MlFileUploadDropzoneMolecule } from '_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class MlFileUploadDropzoneBrutal extends MlFileUploadDropzoneMolecule {
        private gMsg;
        private gLabelId;
        private gErrorId;
        private get x();
        private brutalTriggerContent;
        private brutalFileList;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectmany/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectmany/ml-popover-multi-select-brutal';
    export class GroupSelectManyIndex extends StateLitElement {
        private skills;
        private langs;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectmany/ml-multi-select-dropdown-brutal" {
    import { TemplateResult } from 'lit';
    import { MultiSelectDropdownMolecule } from '_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    export class MlMultiSelectDropdownBrutal extends MultiSelectDropdownMolecule {
        protected portalClassName: string;
        private bMsg;
        private bUid;
        private bLabelId;
        private bHelperId;
        private bErrorId;
        private bPanelId;
        private get x();
        private brutalTriggerClasses;
        private brutalItemClasses;
        private brutalLabel;
        private brutalHelperOrError;
        private brutalSelectedTags;
        private brutalTriggerContent;
        private brutalOptionButton;
        private brutalOptionList;
        protected getPortalTemplate(): TemplateResult;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectmany/ml-popover-multi-select-brutal" {
    import { TemplateResult } from 'lit';
    import { MlPopoverMultiSelectMolecule } from '_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
    export class MlPopoverMultiSelectBrutal extends MlPopoverMultiSelectMolecule {
        protected portalClassName: string;
        private bMsg;
        private bUid;
        private bLabelId;
        private bErrorId;
        private bPanelId;
        private get x();
        private brutalTriggerClasses;
        private brutalItemClasses;
        private brutalLabel;
        private brutalHelper;
        private brutalError;
        private brutalSelectedTag;
        private brutalTriggerContent;
        private brutalEmpty;
        private brutalOptionButton;
        private brutalGroup;
        private brutalItems;
        protected getPortalTemplate(): TemplateResult;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupselectone/ml-card-selector-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-select-dropdown-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-combobox-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-radio-group-brutal';
    import '/_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal';
    export class GroupSelectOneIndex extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-card-selector-brutal" {
    import { TemplateResult } from 'lit';
    import { MlCardSelectorMolecule } from '_102040_/l2/molecules/groupselectone/ml-card-selector';
    export class MlCardSelectorBrutal extends MlCardSelectorMolecule {
        protected portalClassName: string;
        private bMsg;
        private get x();
        private brutalTriggerClasses;
        private brutalCardClasses;
        private brutalSearchInputClasses;
        private brutalGroupLabelClasses;
        private brutalLabel;
        private brutalTrigger;
        private brutalSearch;
        private brutalCard;
        private brutalCardGrid;
        private brutalEmpty;
        protected getPortalTemplate(): TemplateResult;
        private brutalHelper;
        private brutalError;
        private brutalFeedback;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-combobox-brutal" {
    import { TemplateResult } from 'lit';
    import { MlComboboxMolecule } from '_102040_/l2/molecules/groupselectone/ml-combobox';
    export class MlComboboxBrutal extends MlComboboxMolecule {
        protected portalClassName: string;
        private bMsg;
        private get x();
        private brutalInputClasses;
        private brutalOptionClasses;
        private brutalCheckmark;
        private brutalOption;
        protected getPortalTemplate(): TemplateResult;
        private brutalLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-radio-group-brutal" {
    import { MlRadioGroupMolecule } from '_102040_/l2/molecules/groupselectone/ml-radio-group';
    export class MlRadioGroupBrutal extends MlRadioGroupMolecule {
        private bMsg;
        private bLabelId;
        private bErrorId;
        private get x();
        private brutalContainerClasses;
        private brutalOptionClasses;
        private brutalRadioClasses;
        private brutalTextClasses;
        private brutalLabel;
        private brutalRadioIndicator;
        private brutalOption;
        private brutalGroup;
        private brutalRadioOptions;
        private brutalLoading;
        private brutalFeedback;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-segmented-control-brutal" {
    import { SegmentedControlMolecule } from '_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SegmentedControlBrutal extends SegmentedControlMolecule {
        private bMsg;
        private get x();
        private brutalContainerClasses;
        private brutalSegmentClasses;
        private brutalLabelClasses;
        private brutalHelperClasses;
        private brutalErrorClasses;
        private brutalViewModeClasses;
        private brutalViewMode;
        private brutalEditMode;
        private brutalLabel;
        private brutalLoading;
        private brutalSegments;
        private brutalSegment;
        private brutalEmpty;
        private brutalFeedback;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupselectone/ml-select-dropdown-brutal" {
    import { TemplateResult } from 'lit';
    import { MlSelectDropdownMolecule } from '_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    export class MlSelectDropdownBrutal extends MlSelectDropdownMolecule {
        protected portalClassName: string;
        private bMsg;
        private get x();
        private brutalTriggerClasses;
        private brutalDropdownClasses;
        private brutalItemClasses;
        private brutalSearchClasses;
        private brutalLabel;
        private brutalTriggerContent;
        private brutalChevron;
        private brutalTrigger;
        private brutalSearchInput;
        private brutalItems;
        private brutalEmpty;
        protected getPortalTemplate(): TemplateResult;
        private brutalHelper;
        private brutalError;
        private brutalFeedback;
        private brutalViewMode;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupshowprogress/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal';
    import '/_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal';
    export class GroupShowProgressIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal" {
    import { CircularProgressMolecule } from '_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    export class CircularProgressBrutal extends CircularProgressMolecule {
        private get x();
        render(): any;
        private brutalRenderSvg;
        private brutalWrapperClasses;
        private brutalSvgClasses;
        private brutalValueTextClasses;
        private brutalSizeClasses;
    }
}
declare module "_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal" {
    import { LinearProgressMolecule } from '_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    export class LinearProgressBrutal extends LinearProgressMolecule {
        private get x();
        private brutalSizeClasses;
        private brutalTrackClasses;
        private brutalFillClasses;
        private brutalValueText;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal';
    export class GroupTriggerActionIndex extends StateLitElement {
        private lastAction;
        private onAction;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal" {
    import { ButtonStandardMolecule } from '_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class ButtonStandardBrutal extends ButtonStandardMolecule {
        private get x();
        private brutalButtonClasses;
        private brutalSpinner;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal" {
    import { IconButtonMolecule } from '_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    export class IconButtonBrutal extends IconButtonMolecule {
        private gMsg;
        private get x();
        private brutalButtonClasses;
        private brutalIconClasses;
        private brutalRenderIcon;
        private brutalRenderLoadingIcon;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal" {
    import { MlSplitButtonMolecule } from '_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    export class MlSplitButtonBrutal extends MlSplitButtonMolecule {
        private gMsg;
        private get x();
        private brutalPrimaryClasses;
        private brutalChevronClasses;
        private brutalOptionClasses;
        private brutalRenderIcon;
        private brutalRenderLabel;
        private brutalRenderSpinner;
        private brutalRenderChevron;
        private brutalRenderMenuOptions;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupviewcard/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal';
    import '/_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal';
    import '/_102054_/l2/molecules/grouptriggeraction/ml-button-standard-brutal';
    export class GroupViewCardIndex extends StateLitElement {
        private selectedPlan;
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupviewcard/ml-profile-card-brutal" {
    import { MlProfileCardMolecule } from '_102040_/l2/molecules/groupviewcard/ml-profile-card';
    export class MlProfileCardBrutal extends MlProfileCardMolecule {
        private get x();
        private brutalCardClasses;
        private brutalHeader;
        private brutalContent;
        private brutalFooter;
        private brutalAction;
        private brutalLoadingSkeleton;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal" {
    import { MlVerticalCardMolecule } from '_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    export class MlVerticalCardBrutal extends MlVerticalCardMolecule {
        private get x();
        private brutalRootClasses;
        private brutalHeader;
        private brutalContent;
        private brutalFooter;
        private brutalAction;
        private brutalLoading;
        render(): any;
    }
}
declare module "_102054_/l2/molecules/groupviewmetric/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal';
    import '/_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal';
    export class GroupViewMetricIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal" {
    import { TemplateResult } from 'lit';
    import { MlMetricBigNumberMolecule } from '_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    export class MlMetricBigNumberBrutal extends MlMetricBigNumberMolecule {
        render(): TemplateResult;
        private brutalIcon;
        private brutalLabel;
        private brutalValue;
        private brutalTrend;
        private brutalHelper;
        private brutalLoadingSkeleton;
        private brutalContainerClasses;
        private brutalTrendClasses;
        private brutalTrendDirection;
        private brutalAriaLabel;
    }
}
declare module "_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal" {
    import { MetricCardMolecule } from '_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    export class MetricCardBrutal extends MetricCardMolecule {
        private brutalBaseClasses;
        private brutalLabelClasses;
        private brutalValueClasses;
        private brutalHelperClasses;
        private brutalTrendClasses;
        private brutalAriaLabelFromHtml;
        private brutalIcon;
        private brutalLabel;
        private brutalValue;
        private brutalTrend;
        private brutalHelper;
        private brutalSkeleton;
        render(): any;
    }
}
